#!/bin/bash
# Escudo Infinity Guard - abre o menu (dois cliques no Finder)
cd "$(dirname "$0")" || exit 1
xattr -d com.apple.quarantine escudo-mac.sh 2>/dev/null
exec /bin/bash ./escudo-mac.sh menu
