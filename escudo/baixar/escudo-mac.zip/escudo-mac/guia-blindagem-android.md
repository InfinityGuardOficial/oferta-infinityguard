# Blindagem do Android em 10 minutos

Escudo Infinity Guard · Segurança onde você estiver

Os nomes dos menus mudam um pouco de marca para marca (Samsung, Motorola, Xiaomi). Se não achar, use a lupa dentro de Configurações e digite a palavra em **negrito**.

## 1. Os 3 itens que mais evitam golpe de Pix

1. **Acessibilidade.** Configurações → **Acessibilidade** → Apps instalados (ou Serviços). Só deveria aparecer o que você usa de propósito (ex.: leitor de tela). App de "atualização", "segurança", "lanterna", "cartão" ou nome estranho com acesso ligado: **desligue e desinstale**. É assim que o golpe lê a tela e faz Pix por você.
2. **Apps de administração.** Configurações → Segurança → **Apps de administração do dispositivo**. Deixe só o "Encontre meu dispositivo" do Google (e o da empresa, se for celular corporativo).
3. **Instalar apps desconhecidos.** Configurações → Apps → Acesso especial → **Instalar apps desconhecidos**. Deixe tudo como **Não permitido**. Golpe chega como link no WhatsApp/SMS pedindo para instalar um "APK".

## 2. Proteção básica

4. **Play Protect.** Play Store → foto do perfil → **Play Protect** → engrenagem → ligue *Verificar apps com o Play Protect*. Toque em *Verificar*.
5. **Atualização.** Configurações → Sistema → **Atualização**. Instale tudo. Em Configurações → Sobre o telefone, veja o *Nível do patch de segurança*: mais de 6 meses atrás é sinal de que o aparelho não recebe mais correção (evite banco nele).
6. **Bloqueio de tela.** PIN de 6 dígitos ou senha + digital/rosto. Nunca deslizar ou padrão simples.
7. **Acesso a notificações.** Configurações → Apps → Acesso especial → **Acesso a notificações**. App que você não reconhece lendo notificação consegue ler código do banco: desligue.

## 3. Contas

8. **Google:** myaccount.google.com → Segurança → *Verificação em duas etapas* ligada e *Check-up de segurança*.
9. **WhatsApp:** Configurações → Conta → **Confirmação em duas etapas** (PIN). Evita clonagem.
10. **Banco:** ative o limite de Pix noturno e o cadastro de aparelho no app do banco.

## Sinais de que o celular já foi invadido

- Tela que acende ou digita sozinha, bateria acabando rápido sem motivo, app que você não instalou, ícone que sumiu depois de instalar algo.
- O que fazer: tire o chip do aparelho, troque a senha do banco **por outro aparelho**, ligue para o banco, e restaure o celular de fábrica (faça backup só de fotos e contatos).

## Checagem automática pelo PC

Com o Escudo no PC: menu **7 → Checar meu celular Android**. Ele faz os itens 1 a 7 sozinho e gera um relatório com nota. Ao terminar, desligue a **Depuração USB** em Opções do desenvolvedor.
