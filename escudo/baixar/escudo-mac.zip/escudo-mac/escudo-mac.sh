#!/bin/bash
# Escudo Infinity Guard para Mac - "Segurança onde você estiver"
#
# Não é um antivírus novo: o macOS já tem o XProtect (antivírus da Apple), o Gatekeeper
# e a Proteção da Integridade do Sistema. O Escudo confere se está tudo ligado e atualizado,
# liga o que estiver desligado (com backup), procura sinais de invasão e vigia todo dia.
# Nunca apaga arquivo.
#
# Uso:  bash escudo-mac.sh [corrigir|verificar|reforcar|desfazer|varrer|vigiar|instalar|desinstalar|menu]
#   corrigir = varre e tampa os buracos sozinho (com backup e desfazer)
#
# Compatível com o bash 3.2 que vem no macOS.

ESCUDO_VERSAO="1.1.0"
MAC_MINIMO=15            # macOS abaixo disso não recebe mais correção de segurança (out/2026)

# Para testes: ESCUDO_MOCK=pasta com as respostas dos comandos; ESCUDO_RAIZ=prefixo das pastas do sistema
RAIZ="${ESCUDO_RAIZ:-}"
CASA="${ESCUDO_CASA:-$HOME}"
DADOS="${ESCUDO_DADOS:-$CASA/Library/Application Support/EscudoInfinityGuard}"

ACHADOS=""               # linhas: nivel|area|titulo|detalhe|o que fazer
CORR=""                  # o que o Escudo sabe corrigir sozinho: tipo|alvo
SEP=$'\x1f'

# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------

saida() {
    # saida NOME comando...  -> roda o comando (ou lê a resposta gravada, nos testes)
    local nome="$1"; shift
    if [ -n "${ESCUDO_MOCK:-}" ]; then
        if [ -f "$ESCUDO_MOCK/$nome" ]; then cat "$ESCUDO_MOCK/$nome"; return 0; fi
        return 1
    fi
    "$@" 2>&1
}

achado() {
    # achado NIVEL AREA TITULO DETALHE OQUEFAZER
    ACHADOS="${ACHADOS}${1}${SEP}${2}${SEP}${3}${SEP}${4}${SEP}${5}"$'\n'
}

corrigivel() {
    # corrigivel TIPO ALVO  -> entra na lista do "corrigir"
    CORR="${CORR}${1}${SEP}${2}"$'\n'
}

executa() {
    # executa comando...  -> roda de verdade; nos testes só registra o que faria
    if [ -n "${ESCUDO_MOCK:-}" ]; then
        mkdir -p "$DADOS" && printf '%s\n' "$*" >> "$DADOS/.mock-acoes"
        return 0
    fi
    "$@"
}

dono_cron() {
    # De quem é o crontab a ler/corrigir (rodando como administrador, é o da pessoa, não o do root)
    if [ "$(id -u)" -eq 0 ]; then echo "${SUDO_USER:-${ESCUDO_DONO:-}}"; fi
}

ler_crontab() {
    local u
    u=$(dono_cron)
    if [ -n "$u" ]; then saida crontab crontab -u "$u" -l; else saida crontab crontab -l; fi
}

log() {
    mkdir -p "$DADOS/logs" 2>/dev/null
    printf '%s  %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$DADOS/logs/escudo.log" 2>/dev/null
}

peso() { case "$1" in Critico) echo 25 ;; Alto) echo 12 ;; Medio) echo 4 ;; *) echo 0 ;; esac; }

nota() {
    local n=100 nivel
    while IFS="$SEP" read -r nivel _; do
        [ -z "$nivel" ] && continue
        n=$((n - $(peso "$nivel")))
    done <<EOF
$ACHADOS
EOF
    [ "$n" -lt 0 ] && n=0
    echo "$n"
}

contar() {
    printf '%s' "$ACHADOS" | grep -c "^$1${SEP}" || true
}

caminho_suspeito() {
    # Lugares onde programa legítimo quase nunca roda, mas vírus de Mac adora.
    case "$1" in
        /tmp/*|/private/tmp/*|/var/tmp/*|/private/var/tmp/*|/Users/Shared/*|*/Downloads/*|*/.Trash/*) return 0 ;;
        */Library/Application\ Support/.*|*/Library/.[!.]*|*/.[!.]*/*) return 0 ;;
    esac
    return 1
}

comando_suspeito() {
    # Devolve o motivo se o comando parece de vírus.
    local c="$1"
    if printf '%s' "$c" | grep -Eqi '(curl|wget)[^|]*\|[[:space:]]*(ba|z)?sh'; then echo "baixa e executa script da internet"; return 0; fi
    if printf '%s' "$c" | grep -Eqi 'base64[[:space:]]+(-d|--decode|-D)'; then echo "decodifica conteúdo escondido (base64)"; return 0; fi
    if printf '%s' "$c" | grep -Eqi 'osascript[[:space:]]+-e'; then echo "roda AppleScript escondido"; return 0; fi
    if printf '%s' "$c" | grep -Eqi '(python3?|perl|ruby)[[:space:]]+-(c|e)[[:space:]]'; then echo "roda código escondido na linha de comando"; return 0; fi
    if printf '%s' "$c" | grep -Eqi '(^|[[:space:]/])(eval|exec)[[:space:]]'; then echo "executa texto como código"; return 0; fi
    if printf '%s' "$c" | grep -Eqi '(nc|ncat|netcat)[[:space:]].*-e[[:space:]]|/dev/tcp/'; then echo "abre conexão de controle remoto"; return 0; fi
    return 1
}

programa_do_plist() {
    # Extrai Program/ProgramArguments de um .plist (XML ou binário).
    local f="$1" xml
    if command -v plutil >/dev/null 2>&1 && [ -z "${ESCUDO_MOCK:-}" ]; then
        xml=$(plutil -convert xml1 -o - "$f" 2>/dev/null)
    else
        xml=$(cat "$f" 2>/dev/null)
    fi
    printf '%s\n' "$xml" | awk '
        /<key>Program<\/key>/ { pegar=1; next }
        /<key>ProgramArguments<\/key>/ { args=1; next }
        pegar && /<string>/ { gsub(/.*<string>|<\/string>.*/, ""); printf "%s ", $0; pegar=0; next }
        args && /<\/array>/ { args=0; next }
        args && /<string>/ { gsub(/.*<string>|<\/string>.*/, ""); printf "%s ", $0 }
    ' | sed 's/ *$//'
}

mtime() {
    # Data de modificação em segundos (macOS usa stat -f, Linux stat -c).
    local m
    m=$(stat -f %m "$1" 2>/dev/null)
    case "$m" in ''|*[!0-9]*) m=$(stat -c %Y "$1" 2>/dev/null) ;; esac
    case "$m" in ''|*[!0-9]*) m=$(date +%s) ;; esac
    echo "$m"
}

html_esc() { printf '%s' "$1" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g' -e 's/"/\&quot;/g'; }

# ---------------------------------------------------------------------------
# Verificações
# ---------------------------------------------------------------------------

checar_sistema() {
    local ver maior
    ver=$(saida sw_vers sw_vers -productVersion | head -1 | tr -d ' ')
    maior=${ver%%.*}
    if [ -n "$maior" ] && [ "$maior" -eq "$maior" ] 2>/dev/null && [ "$maior" -lt "$MAC_MINIMO" ]; then
        achado Alto "Atualizações" "macOS $ver não recebe mais correção de segurança" "A Apple só corrige as 3 versões mais novas." "Ajustes do Sistema > Geral > Atualização de Software. Se o Mac não aceita versão nova, evite usar banco nele."
    fi
    MACOS="$ver"

    local plist="$RAIZ/Library/Preferences/com.apple.SoftwareUpdate" chave valor
    for chave in AutomaticCheckEnabled CriticalUpdateInstall ConfigDataInstall; do
        valor=$(saida "su-$chave" defaults read "$plist" "$chave" | head -1)
        if [ "$valor" = "0" ]; then
            case "$chave" in
                AutomaticCheckEnabled) achado Alto "Atualizações" "Busca automática de atualizações desligada" "" "O Escudo liga sozinho ao corrigir." ;;
                CriticalUpdateInstall) achado Alto "Antivírus" "Correções de segurança urgentes não instalam sozinhas" "São as 'Respostas de Segurança Rápida' da Apple." "O Escudo liga sozinho ao corrigir." ;;
                ConfigDataInstall) achado Critico "Antivírus" "As vacinas do antivírus da Apple (XProtect) não atualizam" "Sem isso, o Mac não reconhece os vírus novos." "O Escudo liga sozinho ao corrigir." ;;
            esac
            corrigivel reforco "$chave"
        fi
    done

    local xp="$RAIZ/Library/Apple/System/Library/CoreServices/XProtect.bundle"
    if [ -d "$xp" ]; then
        local dias
        dias=$(( ( $(date +%s) - $(mtime "$xp") ) / 86400 ))
        if [ "$dias" -gt 45 ]; then
            achado Medio "Antivírus" "Vacinas do XProtect com $dias dias" "" "O Escudo manda o Mac buscar as vacinas novas agora."
            corrigivel xprotect "$dias"
        fi
    fi
}

checar_protecoes() {
    local s
    s=$(saida spctl spctl --status)
    if [ -n "$s" ] && ! printf '%s' "$s" | grep -qi 'enabled'; then
        achado Critico "Antivírus" "Gatekeeper desligado" "O Mac abre qualquer programa baixado, sem checar se é de desenvolvedor conhecido." "O Escudo liga sozinho ao corrigir."
        corrigivel reforco gatekeeper
    fi
    s=$(saida csrutil csrutil status)
    if [ -n "$s" ] && ! printf '%s' "$s" | grep -qi 'status: enabled'; then
        achado Critico "Anti-hacker" "Proteção da Integridade do Sistema (SIP) desligada" "Programas conseguem alterar arquivos do próprio macOS." "Ligue no modo de recuperação: reinicie segurando o botão liga (Apple Silicon) ou Cmd+R (Intel) > Utilitários > Terminal > csrutil enable."
    fi
    s=$(saida fdesetup fdesetup status)
    if [ -n "$s" ] && ! printf '%s' "$s" | grep -qi 'FileVault is On'; then
        achado Medio "Privacidade" "Disco sem criptografia (FileVault desligado)" "Se o Mac for roubado, os arquivos podem ser lidos." "Ajustes do Sistema > Privacidade e Segurança > FileVault > Ativar. Guarde a chave de recuperação."
    fi
    local fw="$RAIZ/usr/libexec/ApplicationFirewall/socketfilterfw"
    s=$(saida firewall "$fw" --getglobalstate)
    if [ -n "$s" ] && ! printf '%s' "$s" | grep -Eqi 'enabled|State = [12]'; then
        achado Alto "Anti-hacker" "Firewall desligado" "Qualquer um na mesma rede (Wi-Fi de café, hotel) pode tentar entrar no Mac." "O Escudo liga sozinho ao corrigir."
        corrigivel reforco firewall
    fi
    s=$(saida stealth "$fw" --getstealthmode)
    if [ -n "$s" ] && ! printf '%s' "$s" | grep -Eqi 'mode is on|stealth mode enabled|State = 1'; then
        achado Medio "Anti-hacker" "Modo invisível do firewall desligado" "O Mac responde a quem procura computadores na rede." "O Escudo liga sozinho ao corrigir."
        corrigivel reforco stealth
    fi
    s=$(saida remotelogin systemsetup -getremotelogin)
    if printf '%s' "$s" | grep -qi 'Remote Login: On'; then
        achado Medio "Anti-hacker" "Acesso remoto (SSH) ligado" "Porta muito atacada por robôs." "O Escudo desliga (dá para desfazer). Se você usa, religue em Ajustes do Sistema > Geral > Compartilhamento."
        corrigivel servico com.openssh.sshd
    fi
    if saida screensharing launchctl list com.apple.screensharing >/dev/null 2>&1; then
        achado Medio "Anti-hacker" "Compartilhamento de tela ligado" "Alguém com a senha consegue ver e controlar o Mac pela rede." "O Escudo desliga (dá para desfazer). Se você usa, religue em Ajustes do Sistema > Geral > Compartilhamento."
        corrigivel servico com.apple.screensharing
    fi
    s=$(saida autologin defaults read "$RAIZ/Library/Preferences/com.apple.loginwindow" autoLoginUser)
    if [ -n "$s" ] && ! printf '%s' "$s" | grep -qi 'does not exist'; then
        achado Alto "Privacidade" "O Mac entra sozinho, sem senha" "Usuário: $s" "O Escudo desliga a entrada automática (dá para desfazer)."
        corrigivel autologin "$s"
    fi
    s=$(saida guest defaults read "$RAIZ/Library/Preferences/com.apple.loginwindow" GuestEnabled)
    if [ "$s" = "1" ]; then
        achado Medio "Anti-hacker" "Usuário Convidado ativo" "" "O Escudo desliga sozinho ao corrigir."
        corrigivel reforco guest
    fi
    s=$(saida screenlock sysadminctl -screenLock status)
    if printf '%s' "$s" | grep -qi 'screenLock is off'; then
        achado Medio "Privacidade" "O Mac não pede senha ao acordar" "" "Ajustes do Sistema > Tela Bloqueada > Exigir senha: Imediatamente."
    fi
}

checar_contas() {
    local s membros n
    s=$(saida admins dscl . -read /Groups/admin GroupMembership)
    membros=$(printf '%s' "$s" | sed -e 's/^GroupMembership://' | tr ' ' '\n' | grep -v -E '^(root)?$' | tr '\n' ' ' | sed 's/ *$//')
    ADMINS="$membros"
    n=$(printf '%s' "$membros" | wc -w | tr -d ' ')
    if [ "${n:-0}" -gt 2 ]; then
        achado Medio "Anti-hacker" "$n contas com poder de administrador" "$membros" "Confira se reconhece todas. Conta de administrador desconhecida é sinal de invasão."
    fi
    s=$(saida profiles profiles list)
    if [ -n "$s" ] && ! printf '%s' "$s" | grep -Eqi 'no configuration profiles|There are no'; then
        local nomes
        nomes=$(printf '%s' "$s" | grep -Ei 'attribute: name|profileIdentifier' | sed 's/.*: //' | tr '\n' ' ')
        achado Alto "Invasão" "Perfil de configuração instalado" "${nomes:-veja em Ajustes do Sistema}" "Perfis podem controlar navegador, VPN e certificados (adware usa isso). Se não é do trabalho/escola, remova em Ajustes do Sistema > Privacidade e Segurança > Perfis."
    fi
}

checar_hosts() {
    local f="$RAIZ/etc/hosts" linha ip nome
    [ -f "$f" ] || return 0
    while read -r linha; do
        linha=${linha%%#*}
        [ -z "$linha" ] && continue
        set -- $linha
        ip="$1"; shift
        for nome in "$@"; do
            case "$nome" in localhost|broadcasthost|ip6-localhost|ip6-loopback) continue ;; esac
            if printf '%s' "$nome" | grep -Eqi 'apple|icloud|google|microsoft|bb\.com|bancobrasil|itau|bradesco|caixa|santander|nubank|inter\.co|mercadopago|paypal|nuvemshop|gov\.br|receita|whatsapp|instagram|facebook'; then
                case "$ip" in
                    0.0.0.0|127.0.0.1|::1|255.255.255.255)
                        if printf '%s' "$nome" | grep -Eqi 'swscan\.apple|swdist\.apple|xp\.apple|mesu\.apple|updates?\.'; then
                            achado Critico "Anti-hacker" "Atualizações da Apple bloqueadas no arquivo hosts" "$nome" "Vírus faz isso para o Mac não se atualizar. O Escudo desativa a linha (guarda cópia)."
                            corrigivel hosts "$nome"
                        fi ;;
                    *) achado Critico "Anti-hacker" "Site importante desviado no arquivo hosts" "$nome -> $ip" "Golpe para mandar você a um site falso. O Escudo desativa a linha (guarda cópia)."
                       corrigivel hosts "$nome" ;;
                esac
            fi
        done
    done < "$f"
}

INICIO=""   # lista para a vigia: tipo|nome|comando

checar_persistencia() {
    local pasta f prog motivo nome
    for pasta in "$RAIZ/Library/LaunchAgents" "$RAIZ/Library/LaunchDaemons" "$CASA/Library/LaunchAgents"; do
        [ -d "$pasta" ] || continue
        for f in "$pasta"/*.plist "$pasta"/.*.plist; do  # inclui os escondidos
            [ -f "$f" ] || continue
            nome=$(basename "$f")
            prog=$(programa_do_plist "$f")
            INICIO="${INICIO}inicialização${SEP}${nome}${SEP}${prog}"$'\n'
            motivo=$(comando_suspeito "$prog")
            if [ -z "$motivo" ] && caminho_suspeito "${prog%% *}"; then
                motivo="programa rodando de pasta temporária, escondida ou de downloads"
            fi
            case "$nome" in .*) motivo="${motivo:-arquivo de inicialização escondido}" ;; esac
            if [ -n "$motivo" ]; then
                achado Alto "Invasão" "Item suspeito liga junto com o Mac: $nome" "$motivo. Programa: $prog" "O Escudo desliga e move para a quarentena (dá para desfazer)."
                corrigivel plist "$f"
            fi
        done
    done
    local cron
    cron=$(ler_crontab)
    if [ -n "$cron" ]; then
        while IFS= read -r linha; do
            case "$linha" in ''|\#*) continue ;; esac
            INICIO="${INICIO}agendamento${SEP}cron${SEP}${linha}"$'\n'
            motivo=$(comando_suspeito "$linha")
            if [ -n "$motivo" ]; then
                achado Alto "Invasão" "Agendamento suspeito (crontab)" "$motivo: $linha" "O Escudo desativa a linha (guarda cópia)."
                corrigivel cron "$linha"
            fi
        done <<EOF
$cron
EOF
    fi
    local itens
    itens=$(saida loginitems osascript -e 'tell application "System Events" to get the name of every login item' | tr ',' '\n' | sed 's/^ *//')
    while IFS= read -r nome; do
        [ -n "$nome" ] && INICIO="${INICIO}itens de login${SEP}${nome}${SEP}"$'\n'
    done <<EOF
$itens
EOF
    local u
    for u in $ADMINS; do INICIO="${INICIO}administrador${SEP}${u}${SEP}"$'\n'; done
}

checar_novidades() {
    # Compara a lista de agora com a da última vigia e avisa o que é novo.
    local base="$DADOS/linha-de-base.txt" agora tipo nome cmd
    agora=$(printf '%s' "$INICIO" | grep -v '^$' | sort -u)
    if [ -f "$base" ]; then
        printf '%s\n' "$agora" | while IFS="$SEP" read -r tipo nome cmd; do
            [ -z "$tipo" ] && continue
            if ! grep -Fqx -- "${tipo}${SEP}${nome}${SEP}${cmd}" "$base"; then
                printf '%s\n' "Medio${SEP}Vigia${SEP}Novo desde a última vigia ($tipo): $nome${SEP}${cmd}${SEP}Se foi você que instalou, tudo certo. Se não reconhece, investigue: pode ser invasão."
            fi
        done > "$DADOS/.novidades.tmp"
        ACHADOS="${ACHADOS}$(cat "$DADOS/.novidades.tmp")"$'\n'
        rm -f "$DADOS/.novidades.tmp"
    fi
    printf '%s\n' "$agora" > "$base"
}

verificar_tudo() {
    ACHADOS=""; INICIO=""; ADMINS=""; MACOS=""; CORR=""
    mkdir -p "$DADOS/relatorios" "$DADOS/logs" "$DADOS/backup"
    checar_sistema
    checar_protecoes
    checar_contas
    checar_hosts
    checar_persistencia
    [ "${1:-}" = "novidades" ] && checar_novidades
    ACHADOS=$(printf '%s' "$ACHADOS" | grep -v '^$' | awk -F"$SEP" '{ o = ($1=="Critico")?0:($1=="Alto")?1:($1=="Medio")?2:3; print o "\t" $0 }' | sort -t"$(printf '\t')" -k1,1n -s | cut -f2-)
    [ -n "$ACHADOS" ] && ACHADOS="${ACHADOS}"$'\n'
}

# ---------------------------------------------------------------------------
# Relatório
# ---------------------------------------------------------------------------

gerar_html() {
    local arq="$1" n cor nivel area titulo det faz rot
    n=$(nota)
    if [ "$n" -ge 85 ]; then cor="#1f9d55"; elif [ "$n" -ge 60 ]; then cor="#d69e2e"; else cor="#c53030"; fi
    {
        cat <<EOF
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Escudo Infinity Guard: Mac</title><style>
:root{--fundo:#f5f7fa;--cartao:#fff;--texto:#1a202c;--suave:#5a6577;--borda:#e2e8f0;--marca:#0b3d91}
@media (prefers-color-scheme:dark){:root{--fundo:#0f141b;--cartao:#18202b;--texto:#e8edf3;--suave:#9aa7b8;--borda:#2a3443;--marca:#6ea8ff}}
body{margin:0;background:var(--fundo);color:var(--texto);font:15px/1.5 -apple-system,system-ui,sans-serif}
.topo{background:var(--marca);color:#fff;padding:20px 16px}.topo h1{margin:0;font-size:22px}.topo p{margin:4px 0 0;opacity:.85}
main{max-width:920px;margin:0 auto;padding:16px}.nota{display:flex;gap:16px;align-items:center;background:var(--cartao);border:1px solid var(--borda);border-radius:12px;padding:16px;margin-bottom:16px}
.nota b{font-size:44px;color:$cor;min-width:90px;text-align:center}.nota ul{margin:0;padding-left:18px;color:var(--suave)}
.item{background:var(--cartao);border:1px solid var(--borda);border-left:6px solid #a0aec0;border-radius:10px;padding:12px 14px;margin:10px 0}
.Critico{border-left-color:#c53030}.Alto{border-left-color:#dd6b20}.Medio{border-left-color:#d69e2e}.Info{border-left-color:#3182ce}
.tag{font-size:11px;font-weight:700;padding:2px 8px;border-radius:99px;background:var(--borda);margin-right:6px}.area{color:var(--suave);font-size:13px}
.det{color:var(--suave);margin:6px 0 0;word-break:break-word}.faz{margin:6px 0 0}footer{color:var(--suave);font-size:12px;text-align:center;padding:24px 16px}
</style></head><body><div class="topo"><h1>Escudo Infinity Guard: saúde do Mac</h1><p>$(date '+%d/%m/%Y %H:%M')</p></div><main>
<div class="nota"><b>$n</b><div><strong>Nota de segurança (0 a 100)</strong><ul>
<li>macOS $(html_esc "${MACOS:-?}") · $(hostname -s 2>/dev/null | sed 's/[<>&]//g')</li>
<li>Problemas: $(contar Critico) crítico(s), $(contar Alto) alto(s), $(contar Medio) médio(s)</li>
<li>O Escudo só leu o Mac; nada foi apagado.</li></ul></div></div>
EOF
        if [ -z "$(printf '%s' "$ACHADOS" | tr -d '\n')" ]; then
            echo '<div class="item Info"><strong>Nenhum problema encontrado.</strong></div>'
        fi
        printf '%s' "$ACHADOS" | while IFS="$SEP" read -r nivel area titulo det faz; do
            [ -z "$nivel" ] && continue
            case "$nivel" in Critico) rot="CRÍTICO" ;; Alto) rot="ALTO" ;; Medio) rot="MÉDIO" ;; *) rot="INFO" ;; esac
            printf '<div class="item %s"><span class="tag">%s</span><span class="area">%s</span><div><strong>%s</strong></div>' "$nivel" "$rot" "$(html_esc "$area")" "$(html_esc "$titulo")"
            [ -n "$det" ] && printf '<p class="det">%s</p>' "$(html_esc "$det")"
            [ -n "$faz" ] && printf '<p class="faz"><b>O que fazer:</b> %s</p>' "$(html_esc "$faz")"
            echo '</div>'
        done
        echo "</main><footer>Escudo Infinity Guard $ESCUDO_VERSAO · Segurança onde você estiver · O Escudo nunca apaga arquivos.</footer></body></html>"
    } > "$arq"
    cp "$arq" "$DADOS/relatorios/ultimo-mac.html"
}

mostrar() {
    local nivel area titulo det faz
    printf '%s' "$ACHADOS" | while IFS="$SEP" read -r nivel area titulo det faz; do
        [ -z "$nivel" ] && continue
        printf '[%-7s] %s\n' "$nivel" "$titulo"
    done
    echo ""
    echo "Nota do Mac: $(nota)/100 · $(contar Critico) crítico(s), $(contar Alto) alto(s), $(contar Medio) médio(s)"
}

avisar() {
    [ -n "${ESCUDO_MOCK:-}" ] && return 0
    osascript -e "display notification \"$2\" with title \"$1\"" >/dev/null 2>&1 || true
}

# ---------------------------------------------------------------------------
# Ações
# ---------------------------------------------------------------------------

acao_verificar() {
    verificar_tudo "${1:-}"
    local arq
    arq="$DADOS/relatorios/mac-$(date '+%Y-%m-%d-%H%M').html"
    gerar_html "$arq"
    mostrar
    echo "Relatório: $arq"
    log "Verificação: nota $(nota)"
    if [ -z "${ESCUDO_MOCK:-}" ] && [ "${1:-}" != "novidades" ]; then open "$arq" 2>/dev/null || true; fi
}

devolver_dono() {
    # Rodou como administrador: devolve a pasta do Escudo ao usuário (a vigia diária roda como ele).
    local dono="${SUDO_USER:-${ESCUDO_DONO:-}}"
    if [ -n "$dono" ] && [ "$(id -u)" -eq 0 ] && [ -d "$DADOS" ]; then chown -R "$dono" "$DADOS" 2>/dev/null || true; fi
}

precisa_sudo() {
    # Reabre a mesma ação como administrador (pede a senha do Mac).
    if [ "$(id -u)" -ne 0 ] && [ -z "${ESCUDO_MOCK:-}" ]; then
        echo "Esta opção precisa da sua senha de administrador do Mac."
        sudo ESCUDO_CASA="$CASA" ESCUDO_DADOS="$DADOS" /bin/bash "$0" "$@"
        return 1
    fi
    return 0
}

confirmar() {
    [ "${ESCUDO_SIM:-}" = "1" ] && return 0
    printf '%s (s/n) ' "$1"
    read -r r
    case "$r" in s|S|sim|Sim|y|Y) return 0 ;; esac
    return 1
}

acao_reforcar() {
    precisa_sudo reforcar || return 0
    local fw="$RAIZ/usr/libexec/ApplicationFirewall/socketfilterfw"
    local su="$RAIZ/Library/Preferences/com.apple.SoftwareUpdate"
    local lw="$RAIZ/Library/Preferences/com.apple.loginwindow"
    echo "O Escudo vai (tudo pode ser desfeito):"
    echo "  - ligar o firewall e o modo invisível"
    echo "  - ligar o Gatekeeper"
    echo "  - ligar atualizações automáticas, correções urgentes e vacinas do XProtect"
    echo "  - desligar o usuário Convidado"
    confirmar "Confirmar?" || { echo "Nada foi mudado."; return 0; }
    mkdir -p "$DADOS/backup"
    local bk
    bk="$DADOS/backup/antes-do-reforco-$(date '+%Y-%m-%d-%H%M%S').txt"
    {
        echo "firewall=$(saida firewall "$fw" --getglobalstate | grep -Eqi 'enabled|State = [12]' && echo on || echo off)"
        echo "stealth=$(saida stealth "$fw" --getstealthmode | grep -Eqi 'mode is on|enabled|State = 1' && echo on || echo off)"
        echo "gatekeeper=$(saida spctl spctl --status | grep -qi enabled && echo on || echo off)"
        for k in AutomaticCheckEnabled AutomaticDownload CriticalUpdateInstall ConfigDataInstall; do
            echo "$k=$(saida "su-$k" defaults read "$su" "$k" 2>/dev/null | head -1)"
        done
        echo "GuestEnabled=$(saida guest defaults read "$lw" GuestEnabled 2>/dev/null | head -1)"
    } > "$bk"
    log "Reforço: backup em $bk"
    if [ -n "${ESCUDO_MOCK:-}" ]; then echo "(teste: nenhuma mudança real)"; echo "$bk"; return 0; fi
    "$fw" --setglobalstate on && echo "  [ok] firewall"
    "$fw" --setstealthmode on && echo "  [ok] modo invisível"
    if spctl --master-enable 2>/dev/null || spctl --global-enable 2>/dev/null; then echo "  [ok] Gatekeeper"; else echo "  [confira] Gatekeeper: Ajustes do Sistema > Privacidade e Segurança > permitir apps da App Store e desenvolvedores identificados"; fi
    for k in AutomaticCheckEnabled AutomaticDownload CriticalUpdateInstall ConfigDataInstall; do
        defaults write "$su" "$k" -bool true && echo "  [ok] $k"
    done
    defaults write "$lw" GuestEnabled -bool false && echo "  [ok] Convidado desligado"
    echo ""
    echo "Backup do estado anterior: $bk"
    echo "Falta só você ligar o FileVault (precisa guardar a chave): Ajustes do Sistema > Privacidade e Segurança > FileVault."
    devolver_dono
}

hosts_limpo() {
    # hosts_limpo ARQUIVO NOMES...  -> imprime o hosts com as linhas desses nomes desativadas
    local f="$1"; shift
    awk -v nomes=" $* " '
        { linha=$0; t=$0; sub(/#.*/, "", t); n=split(t, p, /[ \t]+/); achou=0; resto=""
          k=0; for (i=1;i<=n;i++) if (p[i]!="") { k++; q[k]=p[i] }
          if (k>=2) { for (i=2;i<=k;i++) { if (index(nomes, " " q[i] " ")) achou=1; else resto=resto " " q[i] } }
          if (achou) { print "# [Escudo desativou] " linha; if (resto!="") print q[1] resto } else print linha }' "$f"
}

acao_corrigir() {
    # Varre o Mac e tampa sozinho os buracos que achou. Tudo com backup; "desfazer" volta.
    precisa_sudo corrigir || return 0
    verificar_tudo
    local nota_antes carimbo desf q tipo alvo feitos=0 falhas=0 reforco=0 nomes_hosts=""
    nota_antes=$(nota)
    carimbo=$(date '+%Y-%m-%d-%H%M%S')
    desf="$DADOS/backup/correcoes-$carimbo.txt"
    q="$DADOS/quarentena/$carimbo"
    if [ -z "$CORR" ]; then
        echo "Nota do Mac: $nota_antes/100. Nada que o Escudo corrija sozinho."
    else
        echo "Nota do Mac agora: $nota_antes/100. O Escudo vai corrigir:"
        printf '%s' "$ACHADOS" | while IFS="$SEP" read -r nivel area titulo det faz; do
            case "$faz" in "O Escudo"*) echo "  - $titulo" ;; esac
        done
        confirmar "Corrigir agora? Tudo pode ser desfeito depois." || { echo "Nada foi mudado."; return 0; }
    fi
    mkdir -p "$DADOS/backup"
    : > "$desf"
    while IFS="$SEP" read -r tipo alvo; do
        [ -z "$tipo" ] && continue
        case "$tipo" in
            reforco) reforco=1 ;;
            hosts) nomes_hosts="$nomes_hosts $alvo" ;;
            plist)
                if [ -f "$alvo" ]; then
                    mkdir -p "$q"
                    executa launchctl unload "$alvo" 2>/dev/null
                    if mv "$alvo" "$q/$(basename "$alvo")"; then
                        printf 'plist%s%s%s%s\n' "$SEP" "$q/$(basename "$alvo")" "$SEP" "$alvo" >> "$desf"
                        echo "  [corrigido] desligado e na quarentena: $alvo"; feitos=$((feitos + 1))
                    else echo "  [não deu] $alvo"; falhas=$((falhas + 1)); fi
                fi ;;
            cron)
                local bkc="$DADOS/backup/crontab-$carimbo.txt" u
                if [ ! -f "$bkc" ]; then
                    ler_crontab > "$bkc"
                    u=$(dono_cron)
                    printf 'cron%s%s%s%s\n' "$SEP" "$bkc" "$SEP" "$u" >> "$desf"
                fi
                ;;
            servico)
                executa launchctl disable "system/$alvo" && executa launchctl bootout "system/$alvo" 2>/dev/null
                printf 'servico%s%s%s\n' "$SEP" "$alvo" "$SEP" >> "$desf"
                echo "  [corrigido] desligado: $alvo"; feitos=$((feitos + 1)) ;;
            autologin)
                local lw="$RAIZ/Library/Preferences/com.apple.loginwindow"
                executa defaults delete "$lw" autoLoginUser
                if [ -f "$RAIZ/etc/kcpassword" ]; then mkdir -p "$q"; mv "$RAIZ/etc/kcpassword" "$q/kcpassword"; fi
                printf 'autologin%s%s%s%s\n' "$SEP" "$alvo" "$SEP" "$q/kcpassword" >> "$desf"
                echo "  [corrigido] entrada automática sem senha desligada"; feitos=$((feitos + 1)) ;;
            xprotect)
                if [ -z "${ESCUDO_MOCK:-}" ] && command -v xprotect >/dev/null 2>&1; then xprotect update >/dev/null 2>&1 || true
                else executa softwareupdate --background-critical >/dev/null 2>&1 || true; fi
                echo "  [corrigido] pedi as vacinas novas do XProtect à Apple"; feitos=$((feitos + 1)) ;;
        esac
    done <<EOF
$CORR
EOF
    # crontab: desativa as linhas suspeitas de uma vez
    if grep -q "^cron${SEP}" "$desf" 2>/dev/null; then
        local bkc u novo="$DADOS/backup/crontab-novo-$carimbo.txt"
        bkc=$(grep "^cron${SEP}" "$desf" | head -1 | cut -d"$SEP" -f2)
        u=$(dono_cron)
        cp "$bkc" "$novo"
        printf '%s' "$CORR" | grep "^cron${SEP}" | cut -d"$SEP" -f2- | while IFS= read -r linha; do
            awk -v l="$linha" '$0==l { print "# [Escudo desativou] " $0; next } { print }' "$novo" > "$novo.tmp" && mv "$novo.tmp" "$novo"
        done
        if executa crontab ${u:+-u "$u"} "$novo"; then echo "  [corrigido] agendamento suspeito desativado no crontab"; feitos=$((feitos + 1)); else falhas=$((falhas + 1)); fi
    fi
    # hosts: desativa as linhas dos desvios (guarda cópia)
    if [ -n "$nomes_hosts" ] && [ -f "$RAIZ/etc/hosts" ]; then
        local bkh="$DADOS/backup/hosts-$carimbo.txt"
        cp "$RAIZ/etc/hosts" "$bkh"
        # shellcheck disable=SC2086
        hosts_limpo "$bkh" $nomes_hosts > "$RAIZ/etc/hosts"
        printf 'hosts%s%s%s\n' "$SEP" "$bkh" "$SEP" >> "$desf"
        executa dscacheutil -flushcache 2>/dev/null; executa killall -HUP mDNSResponder 2>/dev/null
        echo "  [corrigido] desvios desativados no /etc/hosts:$nomes_hosts"; feitos=$((feitos + 1))
    fi
    # sempre reforça: liga o que estiver desligado (firewall, Gatekeeper, atualizações, vacinas, convidado)
    ESCUDO_SIM=1 acao_reforcar >/dev/null 2>&1 && { echo "  [corrigido] proteções do Mac ligadas (firewall, Gatekeeper, atualizações, vacinas)"; feitos=$((feitos + 1)); }
    [ "$reforco" = "1" ] && log "Correção: proteções desligadas foram religadas"
    [ -s "$desf" ] || rm -f "$desf"
    verificar_tudo
    local arq
    arq="$DADOS/relatorios/mac-correcao-$(date '+%Y-%m-%d-%H%M').html"
    gerar_html "$arq"
    cp "$arq" "$DADOS/relatorios/ultimo-mac.html" 2>/dev/null || true
    log "Correção: nota $nota_antes -> $(nota), $feitos corrigido(s), $falhas falha(s)"
    echo ""
    echo "Nota do Mac: $nota_antes -> $(nota)/100. $feitos correção(ões)."
    if [ -n "$ACHADOS" ]; then
        echo "O que falta (o macOS só deixa você mesmo mudar):"
        mostrar | grep '^\[' | sed 's/^/  /'
    fi
    [ -f "$desf" ] && echo "Para voltar como estava: bash escudo-mac.sh desfazer"
    echo "Relatório: $arq"
    date '+%s' > "$DADOS/.ultima-correcao" 2>/dev/null
    printf '%s -> %s, %s\n' "$nota_antes" "$(nota)" "$feitos" >> "$DADOS/.ultima-correcao"
    devolver_dono
    if [ -z "${ESCUDO_MOCK:-}" ] && [ -t 1 ]; then open "$arq" 2>/dev/null || true; fi
}

desfazer_correcoes() {
    local desf tipo a b
    desf=$(ls -1t "$DADOS/backup"/correcoes-*.txt 2>/dev/null | head -1)
    [ -z "$desf" ] && return 1
    while IFS="$SEP" read -r tipo a b; do
        case "$tipo" in
            plist) mkdir -p "$(dirname "$b")"; mv "$a" "$b" && executa launchctl load "$b" 2>/dev/null ;;
            cron) executa crontab ${b:+-u "$b"} "$a" ;;
            hosts) cat "$a" > "$RAIZ/etc/hosts" ;;
            servico) executa launchctl enable "system/$a" ;;
            autologin) executa defaults write "$RAIZ/Library/Preferences/com.apple.loginwindow" autoLoginUser "$a"; [ -f "$b" ] && mv "$b" "$RAIZ/etc/kcpassword" ;;
        esac
    done < "$desf"
    mv "$desf" "${desf%.txt}.desfeito.txt"
    echo "Correções desfeitas ($desf)."
    log "Correções desfeitas: $desf"
    return 0
}

acao_desfazer() {
    precisa_sudo desfazer || return 0
    local bk
    desfazer_correcoes || true
    bk=$(ls -1t "$DADOS/backup"/antes-do-reforco-*.txt 2>/dev/null | head -1)
    [ -z "$bk" ] && { echo "Não achei backup do reforço."; return 0; }
    echo "Vou voltar as configurações salvas em $bk"
    confirmar "Confirmar?" || return 0
    [ -n "${ESCUDO_MOCK:-}" ] && { echo "(teste) desfeito a partir de $bk"; return 0; }
    local fw="$RAIZ/usr/libexec/ApplicationFirewall/socketfilterfw" k v
    while IFS='=' read -r k v; do
        case "$k" in
            firewall) "$fw" --setglobalstate "$v" ;;
            stealth) "$fw" --setstealthmode "$v" ;;
            gatekeeper) [ "$v" = "off" ] && echo "  Gatekeeper: o Escudo não desliga o Gatekeeper sozinho (é perigoso). Se precisar, faça em Ajustes." ;;
            GuestEnabled) [ -n "$v" ] && defaults write "$RAIZ/Library/Preferences/com.apple.loginwindow" GuestEnabled -bool "$([ "$v" = 1 ] && echo true || echo false)" ;;
            *) [ -n "$v" ] && defaults write "$RAIZ/Library/Preferences/com.apple.SoftwareUpdate" "$k" -bool "$([ "$v" = 1 ] && echo true || echo false)" ;;
        esac
    done < "$bk"
    log "Desfeito a partir de $bk"
    devolver_dono
    echo "Pronto: configurações voltaram ao que eram."
}

acao_varrer() {
    local alvo="${1:-$CASA}"
    echo "O macOS já varre sozinho com o XProtect (antivírus da Apple), sem botão de varredura manual."
    if command -v clamscan >/dev/null 2>&1; then
        echo "Achei o ClamAV instalado. Varrendo $alvo (pode demorar)..."
        freshclam >/dev/null 2>&1 || true
        clamscan -r -i --exclude-dir='\.Trash' "$alvo" | tee "$DADOS/logs/ultima-varredura.txt"
        log "Varredura ClamAV em $alvo"
    else
        echo "Para varrer pastas ou pendrive na hora, instale um varredor gratuito:"
        echo "  - Malwarebytes para Mac (gratuito para varrer): https://www.malwarebytes.com/mac"
        echo "  - ou ClamAV pelo Homebrew: brew install clamav  (depois rode o Escudo de novo com 'varrer')"
    fi
}

acao_vigiar() {
    verificar_tudo novidades
    local arq graves novas
    arq="$DADOS/relatorios/mac-$(date '+%Y-%m-%d-%H%M').html"
    gerar_html "$arq"
    graves=$(( $(contar Critico) + $(contar Alto) ))
    novas=$(printf '%s' "$ACHADOS" | grep -c "${SEP}Vigia${SEP}" || true)
    # A correção automática roda como administrador (serviço do Escudo); a vigia, como você, só conta o que ela fez.
    if [ -f "$DADOS/.ultima-correcao" ] && [ "$(mtime "$DADOS/.ultima-correcao")" -gt "$(cat "$DADOS/.ultima-vigia" 2>/dev/null || echo 0)" ]; then
        local resumo
        resumo=$(sed -n 2p "$DADOS/.ultima-correcao")
        case "$resumo" in *", 0") ;; *) avisar "Escudo Infinity Guard corrigiu o Mac" "Nota ${resumo%,*}/100. Dá para desfazer no menu." ;; esac
    fi
    date '+%s' > "$DADOS/.ultima-vigia" 2>/dev/null
    log "Vigia: nota $(nota), graves $graves, novidades $novas"
    if [ "$graves" -gt 0 ]; then
        avisar "Escudo Infinity Guard: $graves alerta(s)" "Nota $(nota)/100. Abra o último relatório."
    elif [ "$novas" -gt 0 ]; then
        avisar "Escudo Infinity Guard" "Algo novo passou a ligar com o Mac. Confira o relatório."
    fi
    # guarda só os 60 relatórios mais novos
    ls -1t "$DADOS/relatorios"/mac-*.html 2>/dev/null | tail -n +61 | while IFS= read -r velho; do rm -f "$velho"; done
}

PLIST_ID="br.com.infinityguard.escudo"

acao_instalar() {
    precisa_sudo instalar || return 0
    local destino="$DADOS/escudo-mac.sh" agente="$CASA/Library/LaunchAgents/$PLIST_ID.plist"
    # cópia que roda como administrador fica numa pasta só do sistema (ninguém sem senha consegue alterar)
    local pasta_root="$RAIZ/Library/Application Support/EscudoInfinityGuard"
    local daemon="$RAIZ/Library/LaunchDaemons/$PLIST_ID.corrige.plist"
    local dono="${SUDO_USER:-${ESCUDO_DONO:-}}"
    mkdir -p "$DADOS" "$CASA/Library/LaunchAgents" "$pasta_root" "$(dirname "$daemon")"
    cp "$0" "$destino" && chmod 755 "$destino"
    cp "$0" "$pasta_root/escudo-mac.sh" && chmod 755 "$pasta_root/escudo-mac.sh"
    [ -z "${ESCUDO_MOCK:-}" ] && chown -R root:wheel "$pasta_root" 2>/dev/null
    xattr -d com.apple.quarantine "$destino" "$pasta_root/escudo-mac.sh" 2>/dev/null || true
    cat > "$daemon" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$PLIST_ID.corrige</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$pasta_root/escudo-mac.sh</string><string>corrigir</string></array>
  <key>EnvironmentVariables</key><dict>
    <key>ESCUDO_SIM</key><string>1</string>
    <key>ESCUDO_CASA</key><string>$CASA</string>
    <key>ESCUDO_DADOS</key><string>$DADOS</string>
    <key>ESCUDO_DONO</key><string>$dono</string>
  </dict>
  <key>StartCalendarInterval</key><dict><key>Hour</key><integer>12</integer><key>Minute</key><integer>20</integer></dict>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>/var/log/escudo-corrige.log</string>
  <key>StandardErrorPath</key><string>/var/log/escudo-corrige.log</string>
</dict></plist>
EOF
    cat > "$agente" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$PLIST_ID</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$destino</string><string>vigiar</string></array>
  <key>StartCalendarInterval</key><dict><key>Hour</key><integer>12</integer><key>Minute</key><integer>30</integer></dict>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>$DADOS/logs/vigia.out</string>
  <key>StandardErrorPath</key><string>$DADOS/logs/vigia.err</string>
</dict></plist>
EOF
    if [ -z "${ESCUDO_MOCK:-}" ]; then
        chown root:wheel "$daemon"; chmod 644 "$daemon"
        launchctl unload "$daemon" 2>/dev/null || true
        launchctl load -w "$daemon"
        if [ -n "$dono" ]; then
            chown "$dono" "$agente" "$destino"
            launchctl asuser "$(id -u "$dono")" launchctl unload "$agente" 2>/dev/null || true
            launchctl asuser "$(id -u "$dono")" launchctl load "$agente"
        else
            launchctl unload "$agente" 2>/dev/null || true
            launchctl load "$agente"
        fi
    fi
    devolver_dono
    log "Instalado"
    echo "Instalado! Todo dia às 12:20 o Escudo varre e corrige sozinho; às 12:30 (e ao entrar no Mac) ele avisa o que achou e o que corrigiu."
    echo "Relatório mais recente: $DADOS/relatorios/ultimo-mac.html"
    echo "Recomendado agora: rode 'corrigir' (opção 1 do menu)."
}

acao_desinstalar() {
    precisa_sudo desinstalar || return 0
    local agente="$CASA/Library/LaunchAgents/$PLIST_ID.plist" daemon="$RAIZ/Library/LaunchDaemons/$PLIST_ID.corrige.plist"
    confirmar "Remover a vigia do Escudo? (as configurações do Mac continuam como estão)" || return 0
    if [ -z "${ESCUDO_MOCK:-}" ]; then
        launchctl unload "$daemon" 2>/dev/null
        local dono="${SUDO_USER:-}"
        if [ -n "$dono" ]; then launchctl asuser "$(id -u "$dono")" launchctl unload "$agente" 2>/dev/null; else launchctl unload "$agente" 2>/dev/null; fi
    fi
    rm -f "$agente" "$daemon" "$DADOS/escudo-mac.sh"
    rm -rf "$RAIZ/Library/Application Support/EscudoInfinityGuard"
    log "Desinstalado"
    echo "Escudo removido. Relatórios ficaram em $DADOS (pode apagar se quiser)."
}

menu() {
    while true; do
        clear 2>/dev/null
        echo "=============================================="
        echo "   ESCUDO INFINITY GUARD · Mac"
        echo "   Segurança onde você estiver"
        echo "=============================================="
        echo ""
        echo "  1  VARRER E CORRIGIR TUDO (recomendado)"
        echo "  2  Só verificar, sem mudar nada (relatório com nota)"
        echo "  3  Varrer uma pasta ou pendrive"
        echo "  4  Instalar a vigia diária"
        echo "  5  Desfazer (volta o que o Escudo corrigiu e reforçou)"
        echo "  6  Desinstalar"
        echo "  0  Sair"
        echo ""
        printf 'Escolha: '
        read -r op
        case "$op" in
            1) acao_corrigir ;;
            2) acao_verificar ;;
            3) printf 'Pasta (ENTER = sua pasta pessoal; pendrive = /Volumes/NOME): '; read -r p; acao_varrer "${p:-$CASA}" ;;
            4) acao_instalar ;;
            5) acao_desfazer ;;
            6) acao_desinstalar ;;
            0) exit 0 ;;
        esac
        printf '\nENTER para voltar ao menu'; read -r _
    done
}

principal() {
    case "${1:-menu}" in
        corrigir) acao_corrigir ;;
        verificar) acao_verificar ;;
        reforcar) acao_reforcar ;;
        desfazer) acao_desfazer ;;
        varrer) acao_varrer "${2:-}" ;;
        vigiar) acao_vigiar ;;
        instalar) acao_instalar ;;
        desinstalar) acao_desinstalar ;;
        menu) menu ;;
        *) echo "Uso: bash escudo-mac.sh [corrigir|verificar|reforcar|desfazer|varrer|vigiar|instalar|desinstalar]"; return 3 ;;
    esac
}

if [ "${ESCUDO_FONTE:-}" != "1" ]; then
    principal "$@"
fi
