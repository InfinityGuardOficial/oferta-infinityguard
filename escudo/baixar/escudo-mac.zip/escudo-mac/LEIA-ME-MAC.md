# Escudo Infinity Guard para Mac

**Segurança onde você estiver.**

O Mac já vem com antivírus (XProtect), com o Gatekeeper, que barra programa de origem desconhecida, e com a Proteção da Integridade do Sistema. O Escudo **não instala outro antivírus**. Ele confere se tudo isso está ligado e atualizado, liga o que estiver desligado (com backup para desfazer), procura sinais de invasão e vigia o Mac todo dia. Ele nunca apaga arquivo.

## Instalar

1. Descompacte a pasta `escudo-mac`.
2. **Clique com o botão direito** em `Abrir Escudo.command` → **Abrir** → **Abrir** de novo. O Mac pede essa confirmação na primeira vez porque o arquivo veio da internet.
   - Se preferir o Terminal: `bash escudo-mac.sh`
3. No menu:
   - **1** Verificar (relatório com nota de 0 a 100, abre no navegador)
   - **2** Reforçar (pede a senha do Mac): liga firewall e modo invisível, Gatekeeper, atualizações automáticas, correções urgentes e vacinas do XProtect, desliga o Convidado
   - **4** Instalar a vigia: todo dia às 12:30 e ao entrar no Mac, com aviso na tela se algo grave aparecer
4. Ligue à mão o **FileVault** (Ajustes do Sistema → Privacidade e Segurança → FileVault) e guarde a chave de recuperação.

## O que ele verifica

| Área | Itens |
|---|---|
| Antivírus da Apple | XProtect atualizando, Gatekeeper, correções de segurança urgentes |
| Atualizações | macOS com suporte (15 ou mais novo em out/2026), busca automática |
| Anti-hacker | Firewall e modo invisível, SIP, acesso remoto (SSH), compartilhamento de tela, Convidado, administradores |
| Privacidade | FileVault, login automático sem senha, senha ao acordar |
| Invasão | LaunchAgents/LaunchDaemons suspeitos (inclusive escondidos), crontab que baixa script, perfis de configuração (usados por adware), sites de banco desviados no `/etc/hosts`, atualizações da Apple bloqueadas |
| Vigia | Avisa quando aparece item novo na inicialização, nos itens de login ou administrador novo |

## Varrer uma pasta ou pendrive

O macOS não tem botão de "varrer agora". A opção **3** usa o ClamAV se estiver instalado (`brew install clamav`). Sem ele, o Escudo indica o Malwarebytes para Mac, que varre de graça.

## Desfazer e desinstalar

Menu **5** volta as configurações ao que eram antes do Reforçar. O Escudo não desliga o Gatekeeper sozinho, por segurança. Menu **6** remove a vigia. Relatórios e backups ficam em `~/Library/Application Support/EscudoInfinityGuard`.

## Testes

`bash testes/testar-escudo-mac.sh`: 58 testes com um Mac saudável e um Mac invadido simulados. Não mexe no seu Mac.
