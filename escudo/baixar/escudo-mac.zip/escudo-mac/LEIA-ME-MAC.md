# Escudo Infinity Guard para Mac

**Segurança onde você estiver.**

O Mac já vem com antivírus (XProtect), com o Gatekeeper, que barra programa de origem desconhecida, e com a Proteção da Integridade do Sistema. O Escudo **não instala outro antivírus**. Ele **varre e corrige**: procura sinais de invasão e tampa os buracos na hora, liga o que estiver desligado (com backup para desfazer) e vigia o Mac todo dia, corrigindo sozinho o que for grave. Ele nunca apaga arquivo: o que desliga vai para a quarentena dele.

## Instalar

1. Descompacte a pasta `escudo-mac`.
2. **Clique com o botão direito** em `Abrir Escudo.command` → **Abrir** → **Abrir** de novo. O Mac pede essa confirmação na primeira vez porque o arquivo veio da internet.
   - Se preferir o Terminal: `bash escudo-mac.sh`
3. No menu:
   - **1 Varrer e corrigir tudo** (pede a senha do Mac): tira da inicialização o item suspeito (LaunchAgent/LaunchDaemon vai para a quarentena), desliga o crontab que baixa script, limpa o `/etc/hosts` sequestrado, desliga o login automático sem senha, atualiza as vacinas do XProtect e liga firewall e modo invisível, Gatekeeper, atualizações automáticas e correções urgentes, desliga o Convidado. No fim mostra a nota antes e depois.
   - **2** Só verificar (relatório com nota de 0 a 100, não muda nada)
   - **4** Instalar a vigia: todo dia às 12:20 corrige sozinho o que for grave, às 12:30 e ao entrar no Mac confere e avisa na tela
4. O que a Apple só deixa você fazer: ligue à mão o **FileVault** (Ajustes do Sistema → Privacidade e Segurança → FileVault) e guarde a chave de recuperação.

## O que ele verifica

| Área | Itens |
|---|---|
| Antivírus da Apple | XProtect atualizando, Gatekeeper, correções de segurança urgentes |
| Atualizações | macOS com suporte (15 ou mais novo em out/2026), busca automática |
| Anti-hacker | Firewall e modo invisível, SIP, acesso remoto (SSH), compartilhamento de tela, Convidado, administradores |
| Privacidade | FileVault, login automático sem senha, senha ao acordar |
| Invasão | LaunchAgents/LaunchDaemons suspeitos (inclusive escondidos), crontab que baixa script, perfis de configuração (usados por adware), sites de banco desviados no `/etc/hosts`, atualizações da Apple bloqueadas |
| Vigia | Avisa quando aparece item novo na inicialização, nos itens de login ou administrador novo |

## Varrer uma pasta ou pendrive

O macOS não tem botão de "varrer agora". A opção **3** usa o ClamAV se estiver instalado (`brew install clamav`). Sem ele, o Escudo indica o Malwarebytes para Mac, que varre de graça.

## Desfazer e desinstalar

Menu **5** desfaz tudo o que o Escudo corrigiu e reforçou (devolve da quarentena, restaura o crontab e o `/etc/hosts`). O Escudo não desliga o Gatekeeper sozinho, por segurança. Menu **6** remove a vigia. Relatórios e backups ficam em `~/Library/Application Support/EscudoInfinityGuard`.

## Testes

`bash testes/testar-escudo-mac.sh`: 91 testes com um Mac saudável e um Mac invadido simulados. Não mexe no seu Mac.
