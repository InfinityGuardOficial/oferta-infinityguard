﻿<#
  Escudo Infinity Guard - "Segurança onde você estiver"

  Sem parâmetros: abre o menu.
  Exemplos:
    .\Escudo.ps1 -Acao Diagnostico
    .\Escudo.ps1 -Acao Reforcar
    .\Escudo.ps1 -Acao Varrer -Tipo Completa
    .\Escudo.ps1 -Acao Varrer -Tipo Pasta -Caminho D:\
    .\Escudo.ps1 -Acao Site -Url https://meusite.com.br -EuSouDono
#>
[CmdletBinding()]
param(
    [ValidateSet('Menu', 'Diagnostico', 'Reforcar', 'Desfazer', 'Varrer', 'VarreduraOffline', 'Vigiar', 'PermitirPrograma', 'Android', 'Site', 'Instalar', 'Desinstalar')]
    [string]$Acao = 'Menu',
    [ValidateSet('Rapida', 'Completa', 'Pasta')][string]$Tipo = 'Rapida',
    [string]$Caminho,
    [string]$Url,
    [switch]$EuSouDono,
    [switch]$Sim
)

$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'modulo\EscudoInfinityGuard.psm1') -Force -DisableNameChecking

$precisaAdmin = @('Diagnostico', 'Reforcar', 'Desfazer', 'Varrer', 'VarreduraOffline', 'Vigiar', 'PermitirPrograma', 'Instalar', 'Desinstalar', 'Menu')
if (($precisaAdmin -contains $Acao) -and -not (Test-EscudoAdmin)) {
    # Reabre pedindo permissão de administrador (a janela azul do Windows)
    $args2 = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"", '-Acao', $Acao, '-Tipo', $Tipo)
    if ($Caminho) { $args2 += @('-Caminho', "`"$Caminho`"") }
    if ($Sim) { $args2 += '-Sim' }
    try {
        Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -ArgumentList $args2 -Verb RunAs
        return
    } catch {
        Write-Host 'Sem permissão de administrador. Vou rodar o que der sem ela.' -ForegroundColor Yellow
    }
}

function Pausar { if ($Acao -eq 'Menu') { Read-Host 'ENTER para voltar ao menu' | Out-Null } }

function Executar([string]$Qual) {
    try {
        switch ($Qual) {
            'Diagnostico' { $r = Invoke-EscudoDiagnostico; Write-Host "Nota do PC: $($r.Nota)/100. Relatório: $($r.Relatorio)" -ForegroundColor Cyan }
            'Reforcar' { Invoke-EscudoReforco -Sim:$Sim | Out-Null }
            'Desfazer' { Invoke-EscudoDesfazer -Sim:$Sim }
            'Varrer' { Invoke-EscudoVarredura -Tipo $Tipo -Caminho $Caminho | Out-Null }
            'VarreduraOffline' { Invoke-EscudoVarreduraOffline -Sim:$Sim }
            'Vigiar' { Invoke-EscudoVigia | Out-Null }
            'PermitirPrograma' { Add-EscudoProgramaPermitido -Caminho $Caminho }
            'Android' { Invoke-EscudoAndroid | Out-Null }
            'Site' { Invoke-EscudoSite -Url $Url -EuSouDono:$EuSouDono | Out-Null }
            'Instalar' { Install-Escudo -Sim:$Sim }
            'Desinstalar' { Uninstall-Escudo -Sim:$Sim }
        }
    } catch {
        Write-Host "Erro: $($_.Exception.Message)" -ForegroundColor Red
        Write-EscudoLog "Erro em $Qual : $($_.Exception.Message)"
        if ($Acao -ne 'Menu') { exit 1 }
    }
}

if ($Acao -ne 'Menu') { Executar $Acao; return }

while ($true) {
    Clear-Host
    Write-Host '==============================================' -ForegroundColor Blue
    Write-Host '   ESCUDO INFINITY GUARD' -ForegroundColor White
    Write-Host '   Segurança onde você estiver' -ForegroundColor Gray
    Write-Host '==============================================' -ForegroundColor Blue
    Write-Host ''
    Write-Host '  1  Verificar o PC agora (relatório com nota)'
    Write-Host '  2  Reforçar todas as proteções'
    Write-Host '  3  Varredura rápida'
    Write-Host '  4  Varredura completa'
    Write-Host '  5  Varrer um pendrive ou pasta'
    Write-Host '  6  Varredura offline (reinicia o PC, pega vírus escondido)'
    Write-Host '  7  Checar meu celular Android (pelo cabo)'
    Write-Host '  8  Checar meus sites'
    Write-Host '  9  Permitir um programa nas pastas protegidas'
    Write-Host ' 10  Instalar o Escudo (vigia diária e varredura semanal)'
    Write-Host ' 11  Desfazer o reforço'
    Write-Host ' 12  Desinstalar'
    Write-Host '  0  Sair'
    Write-Host ''
    $op = Read-Host 'Escolha'
    switch ($op) {
        '1' { Executar 'Diagnostico' }
        '2' { Executar 'Reforcar' }
        '3' { $Tipo = 'Rapida'; Executar 'Varrer' }
        '4' { $Tipo = 'Completa'; Executar 'Varrer' }
        '5' { $Tipo = 'Pasta'; $Caminho = Read-Host 'Caminho (ex.: E:\ ou C:\Users\voce\Downloads)'; Executar 'Varrer' }
        '6' { Executar 'VarreduraOffline' }
        '7' { Executar 'Android' }
        '8' {
            $Url = Read-Host 'Endereço do site (ENTER = sites da Infinity Guard)'
            if ($Url) { $EuSouDono = ((Read-Host 'Este site é seu ou você tem autorização por escrito do dono? (S/N)') -match '^(s|sim)$') }
            Executar 'Site'
        }
        '9' { $Caminho = Read-Host 'Caminho do programa (.exe)'; Executar 'PermitirPrograma' }
        '10' { Executar 'Instalar' }
        '11' { Executar 'Desfazer' }
        '12' { Executar 'Desinstalar' }
        '0' { return }
        default { continue }
    }
    Pausar
}
