# Escudo Infinity Guard para Windows

> Outras versões: **Mac** (`escudo-mac.zip`) e **celular Android e iPhone** (app em https://oferta.infinityguard.com.br/escudo/app/). Página de downloads: https://oferta.infinityguard.com.br/escudo/

**Segurança onde você estiver.** Proteção para o PC com Windows, checagem do celular Android e verificação de sites, num pacote só.

## A verdade antes de tudo

- O Escudo **não é mais um antivírus**. Ele usa o antivírus que já vem no Windows (Microsoft Defender), que está entre os mais bem avaliados nos testes independentes, e **liga tudo o que vem desligado de fábrica**: proteção contra ransomware, regras anti-ataque, proteção de rede, bloqueio de programas indesejados, proteção na nuvem no nível alto.
- **Ele varre e corrige sozinho** (menu 1): procura sinais de invasão e **tampa os buracos** na hora. Programa escondido na inicialização é desligado, tarefa agendada suspeita é desativada, processo rodando de pasta estranha é encerrado e mandado para varredura, arquivo hosts sequestrado (banco desviado, atualização bloqueada) é limpo, pasta que mandaram o antivírus ignorar volta a ser vigiada, ameaça encontrada é removida pelo Defender, UAC/Área de Trabalho Remota/conta Convidado são corrigidos e as atualizações do Windows são instaladas. No fim mostra a nota **antes e depois** e o que ainda falta.
- Depois ele **vigia todo dia** e, se algo grave voltar, **corrige sozinho** e avisa na tela (dá para desligar em `config/escudo.config.json`, `vigia_corrige_sozinha`).
- **Nada é apagado** pelo Escudo: o que ele desliga fica guardado e o que é vírus vai para a quarentena do próprio Defender.
- **Toda correção pode ser desfeita** (menu 11). Antes de mudar, ele salva como estava.
- Nenhum sistema no mundo garante 100% de proteção. O Escudo fecha as portas mais usadas e avisa rápido quando algo muda.

## Instalar no PC (Windows 10 ou 11)

1. Baixe e descompacte a pasta `escudo-infinity-guard`.
2. Dê dois cliques em **`Iniciar-Escudo.cmd`**. O Windows pergunta se pode rodar como administrador: clique em **Sim**.
   - Se aparecer "O Windows protegeu o computador", clique em *Mais informações* → *Executar assim mesmo* (acontece com qualquer arquivo baixado da internet).
3. No menu, escolha:
   - **1 Varrer e corrigir tudo**: mostra o que achou, pede um "S" e corrige; no fim abre o relatório com a nota antes e depois;
   - **10** para Instalar (vigia diária às 12:30 e 5 min depois de ligar o PC, varredura completa todo domingo às 3h; se o PC estiver desligado, roda quando ligar).
4. Faça à mão a única coisa que o Windows não deixa nenhum programa fazer: **Segurança do Windows → Proteção contra vírus e ameaças → Gerenciar configurações → ligar "Proteção contra adulteração"**.

Depois de instalado, tudo fica no **Menu Iniciar → Escudo Infinity Guard**.

### Se um programa seu for bloqueado
A proteção contra ransomware só deixa programas confiáveis mexerem em Documentos, Imagens e Área de Trabalho. Se um programa legítimo (jogo, editor) avisar que não consegue salvar, use o menu **9 → Permitir um programa** e cole o caminho do `.exe`.

### O que tem no menu

| Opção | O que faz |
|---|---|
| 1 Varrer e corrigir tudo | Varre, corrige o que achou (inicialização, tarefas, hosts, exclusões do antivírus, ameaças, UAC, Remota, Convidado, atualizações), liga as proteções que vêm desligadas e mostra a nota antes e depois. Salva backup antes. |
| 2 Só verificar | Relatório com nota de 0 a 100 e o que falta. Não muda nada. |
| 3 / 4 Varredura | Rápida (minutos) ou completa (pode passar de 1 hora). Atualiza as vacinas antes. |
| 5 Pendrive/pasta | Varre só o que você escolher. |
| 6 Varredura offline | Reinicia o PC e varre antes do Windows carregar (pega vírus que se esconde). Pede confirmação. |
| 7 Celular Android | Varre e corrige o celular pelo cabo USB. Veja abaixo. |
| 8 Meus sites | Checa os sites de fora, como um visitante veria. |
| 9 Permitir programa | Libera um programa confiável nas pastas protegidas. |
| 10 Instalar | Cria a vigia diária e a varredura semanal. |
| 11 Desfazer | Volta tudo o que o Escudo corrigiu e reforçou ao que era antes. |
| 12 Desinstalar | Remove o Escudo (rode Desfazer antes, se quiser voltar tudo). |

Relatórios, histórico e backups ficam em `C:\ProgramData\EscudoInfinityGuard`.

## Celular Android

Não existe "antivírus mágico" para Android: o Google Play Protect já faz a varredura de apps. O que mais rouba dinheiro no Brasil são **apps de golpe que pedem "acessibilidade"** para ler a tela e fazer Pix por você. O Escudo procura exatamente isso:

- app de fora da Play Store com acessibilidade, administrador do aparelho ou leitura de notificações (lê código de SMS);
- apps autorizados a instalar outros apps;
- celular sem atualização de segurança, Play Protect desligado, sem senha de tela, com root.

Como usar: menu **7**, siga as instruções na tela (ligar a Depuração USB no celular). Depois de varrer ele **corrige pelo cabo**: tira a acessibilidade, a leitura de notificações e o poder de instalar apps de quem não deve ter, desativa o app suspeito (e desinstala só se você disser sim), liga a verificação de apps do Play Protect e abre no celular a tela do que só você pode fazer (senha de tela, atualização). No fim ele mesmo desliga a Depuração USB. Desfazer: `Escudo.ps1 -Acao AndroidDesfazer`.

Sem PC por perto? O **app Escudo para Android** (`escudo-android.apk` na página de downloads) varre o celular sozinho, tem o botão "Corrigir tudo" que leva você direto a cada tela de correção (o Android exige o seu toque em cada uma) e vigia a cada 15 minutos, avisando se aparecer app perigoso. Ele não usa internet.

## Sites

- **De fora (menu 8):** confere cadeado, validade do certificado, cabeçalhos de segurança, se o site anuncia a versão do PHP (e se ela ainda recebe correção), cookies de login, código escondido típico de invasão e arquivos secretos esquecidos (`.env`, `.git`, `phpinfo`, backup `.sql`). Só verifica os sites da lista em `config/escudo.config.json` ou os que você declarar que são seus.
- **Por dentro do servidor:** o **Escudo PHP** (pacote separado `escudo-php.zip`, serviço da Infinity Guard) procura webshell, porta dos fundos e configuração fraca nos arquivos do site.

Sobre as lojas da Infinity Guard: `infinityguard.com.br` roda na Nuvemshop (o servidor e o PHP são da plataforma) e `oferta.infinityguard.com.br` é uma página estática no GitHub Pages (não tem PHP). O que é responsabilidade sua nelas é senha forte com verificação em 2 etapas no painel e no GitHub.

## Testes

```
powershell -ExecutionPolicy Bypass -File testes\Testar-Escudo.ps1
```

Os testes usam fotos de um PC saudável e de um PC invadido (em `testes/fixtures`), não mexem no seu PC.
