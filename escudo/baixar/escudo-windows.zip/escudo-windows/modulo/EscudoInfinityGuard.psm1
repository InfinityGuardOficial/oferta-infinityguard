﻿# Escudo Infinity Guard - modulo principal
# "Segurança onde você estiver"
#
# Regras de projeto:
#  - Não reinventa antivírus: usa e reforça o Microsoft Defender que já vem no Windows.
#  - Nunca apaga arquivo. Quem coloca vírus em quarentena é o Defender.
#  - Toda mudança de configuração é salva antes (backup) e pode ser desfeita.
#  - Funções "puras" (sem acesso ao Windows) ficam separadas para poderem ser testadas.
#  - Compatível com Windows PowerShell 5.1 (o que já vem no Windows) e PowerShell 7.

Set-StrictMode -Version 2.0

$script:Raiz = Split-Path -Parent $PSScriptRoot
$script:Versao = '1.0.0'

# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------

function Get-EscudoPastaDados {
    $base = $env:ProgramData
    if (-not $base) { $base = [System.IO.Path]::GetTempPath() }
    $pasta = Join-Path $base 'EscudoInfinityGuard'
    foreach ($sub in @('', 'relatorios', 'logs', 'backup')) {
        $p = if ($sub) { Join-Path $pasta $sub } else { $pasta }
        if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
    }
    return $pasta
}

function Get-EscudoConfig {
    param([string]$Caminho)
    if (-not $Caminho) { $Caminho = Join-Path (Join-Path $script:Raiz 'config') 'escudo.config.json' }
    $texto = [System.IO.File]::ReadAllText($Caminho, [System.Text.Encoding]::UTF8)
    return ($texto | ConvertFrom-Json)
}

function Write-EscudoLog {
    param([string]$Mensagem)
    try {
        $arq = Join-Path (Join-Path (Get-EscudoPastaDados) 'logs') 'escudo.log'
        $linha = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Mensagem
        Add-Content -Path $arq -Value $linha -Encoding UTF8
    } catch { }
}

function Test-EscudoAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function New-EscudoAchado {
    param(
        [Parameter(Mandatory)][string]$Id,
        [Parameter(Mandatory)][string]$Area,
        [Parameter(Mandatory)][ValidateSet('Critico', 'Alto', 'Medio', 'Info')][string]$Nivel,
        [Parameter(Mandatory)][string]$Titulo,
        [string]$Detalhe = '',
        [string]$OQueFazer = '',
        [bool]$Corrigivel = $false,
        # Como o Escudo corrige sozinho: @{ Tipo = 'reforco' | 'remover-exclusao' | 'limpar-hosts' | ... }
        [hashtable]$Correcao = $null
    )
    if ($Corrigivel -and -not $Correcao) { $Correcao = @{ Tipo = 'reforco' } }
    [pscustomobject]@{
        Id         = $Id
        Area       = $Area
        Nivel      = $Nivel
        Titulo     = $Titulo
        Detalhe    = $Detalhe
        OQueFazer  = $OQueFazer
        Corrigivel = [bool]($Corrigivel -or $Correcao)
        Correcao   = $Correcao
    }
}

function Get-EscudoPeso {
    param([string]$Nivel)
    switch ($Nivel) { 'Critico' { 25 } 'Alto' { 12 } 'Medio' { 4 } default { 0 } }
}

function Get-EscudoNota {
    <# Nota de 0 a 100. Cada problema crítico tira 25, alto 12, médio 4. #>
    param([object[]]$Achados)
    $nota = 100
    foreach ($a in @($Achados)) { if ($a) { $nota -= (Get-EscudoPeso $a.Nivel) } }
    if ($nota -lt 0) { $nota = 0 }
    return $nota
}

function Get-EscudoOrdem {
    param([string]$Nivel)
    switch ($Nivel) { 'Critico' { 0 } 'Alto' { 1 } 'Medio' { 2 } default { 3 } }
}

function Get-EscudoValor {
    # Lê propriedade de objeto sem quebrar no StrictMode quando ela não existe.
    param($Objeto, [string]$Nome)
    if ($null -eq $Objeto) { return $null }
    if ($Objeto -is [hashtable]) { if ($Objeto.ContainsKey($Nome)) { return $Objeto[$Nome] } else { return $null } }
    $p = $Objeto.PSObject.Properties[$Nome]
    if ($p) { return $p.Value }
    return $null
}

# ---------------------------------------------------------------------------
# Regras puras: caminhos e comandos suspeitos
# ---------------------------------------------------------------------------

$script:PadroesCaminho = @(
    '\\AppData\\Local\\Temp\\',
    '\\Windows\\Temp\\',
    '\\Users\\Public\\',
    '\\Downloads\\',
    '\\\$Recycle\.Bin\\',
    '\\PerfLogs\\',
    '\\AppData\\Roaming\\[^\\]+\.(exe|scr|com|pif|bat|cmd|vbs|js|ps1|hta)$',
    '\\ProgramData\\[^\\]+\.(exe|scr|com|pif|bat|cmd|vbs|js|ps1|hta)$',
    '\\AppData\\Local\\[^\\]+\.(exe|scr|com|pif|bat|cmd|vbs|js|ps1|hta)$',
    '\.(scr|pif|hta)$'
)

function Test-EscudoCaminhoSuspeito {
    <# Lugares onde programa legítimo quase nunca fica, mas vírus adora ficar. #>
    param([string]$Caminho)
    if (-not $Caminho) { return $false }
    foreach ($p in $script:PadroesCaminho) {
        if ($Caminho -match $p) { return $true }
    }
    return $false
}

$script:PadroesComando = @(
    @{ P = '(?i)powershell(\.exe)?[^|]*\s-(e|ec|enc|encodedcommand)\s'; M = 'PowerShell com comando escondido (codificado)' },
    @{ P = '(?i)powershell(\.exe)?[^|]*-w(indowstyle)?\s+hidden'; M = 'PowerShell rodando em janela escondida' },
    @{ P = '(?i)(iex|invoke-expression)\b'; M = 'executa texto como código (IEX)' },
    @{ P = '(?i)downloadstring|downloadfile|invoke-webrequest|\biwr\b|net\.webclient|start-bitstransfer'; M = 'baixa algo da internet ao iniciar' },
    @{ P = '(?i)frombase64string'; M = 'decodifica conteúdo escondido (base64)' },
    @{ P = '(?i)mshta(\.exe)?["'']?\s+["'']?(https?|javascript|vbscript):'; M = 'mshta abrindo script da internet' },
    @{ P = '(?i)regsvr32(\.exe)?.*\/i:\s*https?:'; M = 'regsvr32 carregando código da internet' },
    @{ P = '(?i)rundll32(\.exe)?.*javascript:'; M = 'rundll32 executando javascript' },
    @{ P = '(?i)certutil(\.exe)?.*-urlcache'; M = 'certutil usado para baixar arquivo' },
    @{ P = '(?i)bitsadmin(\.exe)?.*\/transfer'; M = 'bitsadmin baixando arquivo' },
    @{ P = '(?i)(wscript|cscript)(\.exe)?.*\\(temp|appdata|users\\public)\\'; M = 'script VBS/JS rodando de pasta temporária' }
)

function Get-EscudoMotivoComando {
    <# Devolve o motivo (texto) se o comando parece de vírus, ou $null. #>
    param([string]$Comando)
    if (-not $Comando) { return $null }
    foreach ($r in $script:PadroesComando) {
        if ($Comando -match $r.P) { return $r.M }
    }
    return $null
}

function Get-EscudoCaminhoDoComando {
    <# Extrai o executável de uma linha de comando ("C:\x\a.exe" -arg  ou  C:\x\a.exe /arg). #>
    param([string]$Comando)
    if (-not $Comando) { return $null }
    $c = [Environment]::ExpandEnvironmentVariables($Comando.Trim())
    if ($c.StartsWith('"')) {
        $fim = $c.IndexOf('"', 1)
        if ($fim -gt 1) { return $c.Substring(1, $fim - 1) }
    }
    $m = [regex]::Match($c, '(?i)^(.+?\.(exe|com|scr|bat|cmd|vbs|js|ps1|hta|pif|lnk|dll))(\s|,|$)')
    if ($m.Success) { return $m.Groups[1].Value }
    return ($c -split '\s+')[0]
}

function Test-EscudoExclusaoPerigosa {
    <# Exclusões do antivírus que um vírus colocaria para se esconder. #>
    param([string]$Valor, [ValidateSet('Caminho', 'Extensao', 'Processo')][string]$Tipo)
    if (-not $Valor) { return $false }
    switch ($Tipo) {
        'Caminho' {
            if ($Valor -match '^[A-Za-z]:\\?$') { return $true }
            if ($Valor -match '(?i)\\(temp|tmp)(\\|$)|\\appdata(\\|$)|\\downloads(\\|$)|\\users\\public(\\|$)|\\windows(\\|$)|\\system32(\\|$)|\\programdata\\?$|\\users\\?$') { return $true }
            return $false
        }
        'Extensao' { return ($Valor.TrimStart('.') -match '(?i)^(exe|dll|scr|com|bat|cmd|ps1|vbs|js|hta|msi|lnk)$') }
        'Processo' { return ($Valor -match '(?i)(^|\\)(powershell|pwsh|cmd|wscript|cscript|mshta|rundll32|regsvr32|explorer|svchost)\.exe$') }
    }
    return $false
}

$script:DominiosSensiveis = '(?i)microsoft|windowsupdate|google|gstatic|youtube|facebook|instagram|whatsapp|bb\.com|bancobrasil|itau|bradesco|caixa|santander|nubank|inter\.co|mercadopago|paypal|nuvemshop|gov\.br|receita'

function Test-EscudoAtualizacaoDoWindows {
    <# true para atualização do Windows; false para vacina diária do Defender e outras definições. #>
    param([string]$Titulo)
    if (-not $Titulo) { return $false }
    return ($Titulo -notmatch '(?i)KB2267602|KB4052623|KB2461484|Intelig[eê]ncia de Seguran[cç]a|Security Intelligence|Definition Update|Atualiza[cç][aã]o de Defini[cç][aã]o|Defender Antivirus|Antimalware Platform|Malicious Software Removal|Ferramenta de Remo[cç][aã]o de Software Mal')
}

function Get-EscudoHostsSuspeitos {
    <# Recebe as linhas do arquivo hosts e devolve as entradas que redirecionam endereços. #>
    param([string[]]$Linhas)
    $saida = @()
    foreach ($l in @($Linhas)) {
        if (-not $l) { continue }
        $t = ($l -replace '#.*$', '').Trim()
        if (-not $t) { continue }
        $partes = $t -split '\s+'
        if ($partes.Count -lt 2) { continue }
        $ip = $partes[0]
        foreach ($nome in $partes[1..($partes.Count - 1)]) {
            if ($nome -match '^(localhost|localhost\.localdomain|ip6-localhost|ip6-loopback)$') { continue }
            $bloqueio = $ip -in @('0.0.0.0', '127.0.0.1', '::1', '::')
            $saida += [pscustomobject]@{
                Ip        = $ip
                Nome      = $nome
                Bloqueio  = $bloqueio
                Sensivel  = ($nome -match $script:DominiosSensiveis)
            }
        }
    }
    return $saida
}

# ---------------------------------------------------------------------------
# Regras puras: estado do PC -> achados
# ---------------------------------------------------------------------------

function Get-EscudoAchados {
    <#
      Recebe o estado do PC (objeto gerado por Get-EscudoEstado, ou um arquivo de teste)
      e devolve a lista de problemas encontrados, do mais grave para o mais leve.
    #>
    param([Parameter(Mandatory)]$Estado, $Config)

    $A = New-Object System.Collections.ArrayList
    $def = Get-EscudoValor $Estado 'Defender'
    $pref = Get-EscudoValor $Estado 'Preferencias'
    $guiaSeg = 'Abra "Segurança do Windows" > "Proteção contra vírus e ameaças" > "Gerenciar configurações".'

    # --- Antivírus (Defender) ---
    if (-not $def) {
        [void]$A.Add((New-EscudoAchado -Id 'def-ilegivel' -Area 'Antivírus' -Nivel 'Alto' -Titulo 'Não consegui ler o antivírus do Windows' -Detalhe 'O Defender pode estar desligado, ou outro antivírus assumiu o controle.' -OQueFazer 'Rode o Escudo como administrador. Se você instalou outro antivírus, confira se ele está ativo e atualizado.'))
    } else {
        $modo = [string](Get-EscudoValor $def 'AMRunningMode')
        if ($modo -match '(?i)passive|passivo|sidebyside') {
            [void]$A.Add((New-EscudoAchado -Id 'def-passivo' -Area 'Antivírus' -Nivel 'Info' -Titulo 'Outro antivírus é o principal neste PC' -Detalhe "O Defender está em modo '$modo'." -OQueFazer 'Tudo bem, desde que o outro antivírus esteja pago, ativo e atualizado. Nunca rode dois antivírus completos ao mesmo tempo.'))
        }
        if ((Get-EscudoValor $def 'AntivirusEnabled') -eq $false -or (Get-EscudoValor $def 'RealTimeProtectionEnabled') -eq $false) {
            [void]$A.Add((New-EscudoAchado -Id 'def-tempo-real' -Area 'Antivírus' -Nivel 'Critico' -Titulo 'A proteção em tempo real está DESLIGADA' -Detalhe 'Sem ela, um vírus baixado roda sem ninguém barrar.' -OQueFazer 'O Escudo religa sozinho ao corrigir.' -Corrigivel $true))
        }
        if ((Get-EscudoValor $def 'BehaviorMonitorEnabled') -eq $false) {
            [void]$A.Add((New-EscudoAchado -Id 'def-comportamento' -Area 'Antivírus' -Nivel 'Alto' -Titulo 'Monitor de comportamento desligado' -Detalhe 'É ele que pega vírus novo pelo que o programa faz (não só pelo nome).' -OQueFazer 'O Escudo liga sozinho ao corrigir.' -Corrigivel $true))
        }
        if ((Get-EscudoValor $def 'IsTamperProtected') -eq $false) {
            [void]$A.Add((New-EscudoAchado -Id 'def-adulteracao' -Area 'Antivírus' -Nivel 'Alto' -Titulo 'Proteção contra adulteração desligada' -Detalhe 'Sem ela, um vírus consegue desligar o antivírus sozinho.' -OQueFazer "$guiaSeg Ligue 'Proteção contra adulteração'. (O Windows não deixa script nenhum ligar isso, só você, de propósito.)"))
        }
        $idade = Get-EscudoValor $def 'AntivirusSignatureAge'
        if ($null -ne $idade) {
            if ([int]$idade -gt 3) {
                [void]$A.Add((New-EscudoAchado -Id 'def-vacinas' -Area 'Antivírus' -Nivel 'Alto' -Titulo "Vacinas do antivírus com $idade dias" -Detalhe 'O antivírus não conhece os vírus mais novos.' -OQueFazer 'Use "Varrer" (atualiza antes) ou "Reforçar". Confira se o Windows Update está funcionando.' -Correcao @{ Tipo = 'varredura' }))
            } elseif ([int]$idade -gt 1) {
                [void]$A.Add((New-EscudoAchado -Id 'def-vacinas' -Area 'Antivírus' -Nivel 'Medio' -Titulo "Vacinas do antivírus com $idade dias" -OQueFazer 'O Escudo atualiza todo dia na vigia. Se continuar, rode "Varrer".' -Correcao @{ Tipo = 'varredura' }))
            }
        }
        $rapida = Get-EscudoValor $def 'QuickScanAge'
        if ($null -ne $rapida -and [int64]$rapida -gt 7) {
            [void]$A.Add((New-EscudoAchado -Id 'def-varredura-rapida' -Area 'Antivírus' -Nivel 'Medio' -Titulo 'Faz mais de 7 dias sem varredura rápida' -OQueFazer 'Rode "Varrer". Com o Escudo instalado, isso passa a ser diário.' -Correcao @{ Tipo = 'varredura' }))
        }
        $completa = Get-EscudoValor $def 'FullScanAge'
        if ($null -ne $completa -and [int64]$completa -gt 30) {
            $txt = if ([int64]$completa -gt 100000) { 'Nunca foi feita uma varredura completa' } else { "Faz $completa dias sem varredura completa" }
            [void]$A.Add((New-EscudoAchado -Id 'def-varredura-completa' -Area 'Antivírus' -Nivel 'Medio' -Titulo $txt -OQueFazer 'Rode "Varrer completa" numa hora em que não for usar o PC (pode levar mais de 1 hora). Com o Escudo instalado, é semanal.' -Correcao @{ Tipo = 'instalar-vigia' }))
        }
    }

    if ($pref) {
        if ((Get-EscudoValor $pref 'DisableRealtimeMonitoring') -eq $true -and -not ($A | Where-Object Id -eq 'def-tempo-real')) {
            [void]$A.Add((New-EscudoAchado -Id 'def-tempo-real' -Area 'Antivírus' -Nivel 'Critico' -Titulo 'A proteção em tempo real está DESLIGADA' -OQueFazer 'O Escudo liga sozinho ao corrigir.' -Corrigivel $true))
        }
        if ([int](Get-EscudoValor $pref 'MAPSReporting') -eq 0) {
            [void]$A.Add((New-EscudoAchado -Id 'def-nuvem' -Area 'Antivírus' -Nivel 'Alto' -Titulo 'Proteção na nuvem desligada' -Detalhe 'A nuvem da Microsoft reconhece vírus novos em segundos. Desligada, o PC só conhece o que já está nas vacinas.' -OQueFazer 'O Escudo liga sozinho ao corrigir.' -Corrigivel $true))
        }
        if ([int](Get-EscudoValor $pref 'PUAProtection') -ne 1) {
            [void]$A.Add((New-EscudoAchado -Id 'def-pua' -Area 'Antivírus' -Nivel 'Medio' -Titulo 'Bloqueio de programas indesejados desligado' -Detalhe 'Barra "brindes" de instaladores: barras de navegador, mineradores, adware.' -OQueFazer 'O Escudo liga sozinho ao corrigir.' -Corrigivel $true))
        }
        if ([int](Get-EscudoValor $pref 'EnableNetworkProtection') -ne 1) {
            [void]$A.Add((New-EscudoAchado -Id 'def-rede' -Area 'Anti-hacker' -Nivel 'Medio' -Titulo 'Proteção de rede desligada' -Detalhe 'Bloqueia o PC de conversar com sites de golpe e servidores de hacker, em qualquer programa.' -OQueFazer 'O Escudo liga sozinho ao corrigir.' -Corrigivel $true))
        }
        if ([int](Get-EscudoValor $pref 'EnableControlledFolderAccess') -ne 1) {
            [void]$A.Add((New-EscudoAchado -Id 'def-ransomware' -Area 'Ransomware' -Nivel 'Alto' -Titulo 'Pastas protegidas contra ransomware desligadas' -Detalhe 'Ransomware é o vírus que tranca seus arquivos e pede resgate. Com as pastas protegidas, só programas confiáveis mexem em Documentos, Imagens e Área de Trabalho.' -OQueFazer 'O Escudo liga sozinho ao corrigir. Se um programa seu for bloqueado, use "Permitir programa".' -Corrigivel $true))
        }

        # Regras contra ataques (ASR)
        if ($Config) {
            $ids = @(Get-EscudoValor $pref 'AttackSurfaceReductionRules_Ids')
            $acoes = @(Get-EscudoValor $pref 'AttackSurfaceReductionRules_Actions')
            $ativas = @{}
            for ($i = 0; $i -lt $ids.Count; $i++) {
                if ($ids[$i]) { $ativas[([string]$ids[$i]).ToUpper()] = [int]$acoes[$i] }
            }
            $faltando = @()
            foreach ($r in @($Config.regras_asr)) {
                $esperado = if ($r.acao -eq 'Enabled') { 1 } else { 2 }
                $atual = $ativas[$r.id.ToUpper()]
                if ($null -eq $atual -or ($esperado -eq 1 -and $atual -ne 1) -or ($esperado -eq 2 -and $atual -eq 0)) { $faltando += $r.nome }
            }
            if ($faltando.Count -gt 0) {
                [void]$A.Add((New-EscudoAchado -Id 'def-asr' -Area 'Anti-hacker' -Nivel 'Medio' -Titulo "$($faltando.Count) regras anti-ataque desligadas" -Detalhe ($faltando -join '; ') -OQueFazer 'O Escudo liga sozinho ao corrigir. (No Windows Home algumas regras podem não ter efeito.)' -Corrigivel $true))
            }
        }

        # Exclusões do antivírus
        $exc = @()
        foreach ($x in @(Get-EscudoValor $pref 'ExclusionPath')) { if ($x) { $exc += [pscustomobject]@{ V = $x; T = 'Caminho' } } }
        foreach ($x in @(Get-EscudoValor $pref 'ExclusionExtension')) { if ($x) { $exc += [pscustomobject]@{ V = $x; T = 'Extensao' } } }
        foreach ($x in @(Get-EscudoValor $pref 'ExclusionProcess')) { if ($x) { $exc += [pscustomobject]@{ V = $x; T = 'Processo' } } }
        $perigosas = @($exc | Where-Object { Test-EscudoExclusaoPerigosa -Valor $_.V -Tipo $_.T })
        if ($perigosas.Count -gt 0) {
            [void]$A.Add((New-EscudoAchado -Id 'def-exclusao-perigosa' -Area 'Antivírus' -Nivel 'Critico' -Titulo 'O antivírus foi mandado ignorar lugares perigosos' -Detalhe ('Exclusões: ' + (($perigosas | ForEach-Object { $_.V }) -join ', ')) -OQueFazer 'Vírus costuma criar exclusão para se esconder. O Escudo remove essas exclusões (dá para desfazer) e varre de novo.' -Correcao @{ Tipo = 'remover-exclusao'; Itens = @($perigosas | ForEach-Object { @{ V = [string]$_.V; T = [string]$_.T } }) }))
        } elseif ($exc.Count -gt 0) {
            [void]$A.Add((New-EscudoAchado -Id 'def-exclusoes' -Area 'Antivírus' -Nivel 'Info' -Titulo "$($exc.Count) exclusões no antivírus" -Detalhe (($exc | ForEach-Object { $_.V }) -join ', ') -OQueFazer 'Confira se você reconhece todas.'))
        }
    }

    # --- Firewall ---
    $fw = @(Get-EscudoValor $Estado 'Firewall')
    foreach ($perfil in $fw) {
        if (-not $perfil) { continue }
        $nome = Get-EscudoValor $perfil 'Name'
        if ((Get-EscudoValor $perfil 'Enabled') -eq $false) {
            [void]$A.Add((New-EscudoAchado -Id "fw-$nome" -Area 'Anti-hacker' -Nivel 'Critico' -Titulo "Firewall desligado na rede '$nome'" -Detalhe 'Qualquer um na mesma rede (Wi-Fi de café, hotel) pode tentar entrar no PC.' -OQueFazer 'O Escudo liga sozinho ao corrigir.' -Corrigivel $true))
        } elseif ([string](Get-EscudoValor $perfil 'DefaultInboundAction') -match '(?i)^allow') {
            [void]$A.Add((New-EscudoAchado -Id "fw-entrada-$nome" -Area 'Anti-hacker' -Nivel 'Alto' -Titulo "Firewall deixando tudo entrar na rede '$nome'" -OQueFazer 'O Escudo liga sozinho ao corrigir.' -Corrigivel $true))
        }
    }

    # --- Atualizações ---
    $dias = Get-EscudoValor $Estado 'DiasSemAtualizacao'
    if ($null -ne $dias) {
        if ([int]$dias -gt 45) {
            [void]$A.Add((New-EscudoAchado -Id 'win-update' -Area 'Atualizações' -Nivel 'Alto' -Titulo "Windows sem atualização há $dias dias" -Detalhe 'Hacker entra pelas falhas que a Microsoft já corrigiu, mas o PC ainda não instalou.' -OQueFazer 'O Escudo manda o Windows Update baixar e instalar agora. Reinicie quando pedir.' -Correcao @{ Tipo = 'atualizar-windows' }))
        } elseif ([int]$dias -gt 20) {
            [void]$A.Add((New-EscudoAchado -Id 'win-update' -Area 'Atualizações' -Nivel 'Medio' -Titulo "Windows sem atualização há $dias dias" -OQueFazer 'O Escudo manda o Windows Update baixar e instalar agora.' -Correcao @{ Tipo = 'atualizar-windows' }))
        }
    }
    if ((Get-EscudoValor $Estado 'ReinicioPendente') -eq $true) {
        [void]$A.Add((New-EscudoAchado -Id 'win-reinicio' -Area 'Atualizações' -Nivel 'Medio' -Titulo 'Tem atualização esperando o PC reiniciar' -Detalhe 'A correção só vale depois de reiniciar.' -OQueFazer 'Salve tudo e reinicie o PC hoje.'))
    }

    # --- Windows ---
    $uac = Get-EscudoValor $Estado 'UAC'
    if ($uac) {
        if ([int](Get-EscudoValor $uac 'EnableLUA') -eq 0) {
            [void]$A.Add((New-EscudoAchado -Id 'win-uac' -Area 'Anti-hacker' -Nivel 'Critico' -Titulo 'Controle de Conta de Usuário (UAC) desligado' -Detalhe 'Qualquer programa vira administrador sem perguntar.' -OQueFazer 'O Escudo religa o UAC no nível padrão (vale depois de reiniciar).' -Correcao @{ Tipo = 'ligar-uac' }))
        } elseif ([int](Get-EscudoValor $uac 'ConsentPromptBehaviorAdmin') -eq 0) {
            [void]$A.Add((New-EscudoAchado -Id 'win-uac-mudo' -Area 'Anti-hacker' -Nivel 'Alto' -Titulo 'UAC no modo "nunca avisar"' -OQueFazer 'O Escudo volta o UAC para o nível padrão.' -Correcao @{ Tipo = 'ligar-uac' }))
        }
    }
    if ((Get-EscudoValor $Estado 'SMB1') -eq $true) {
        [void]$A.Add((New-EscudoAchado -Id 'win-smb1' -Area 'Anti-hacker' -Nivel 'Alto' -Titulo 'Compartilhamento antigo SMB1 ligado' -Detalhe 'Foi a porta usada pelo ransomware WannaCry.' -OQueFazer 'O Escudo liga sozinho ao corrigir.' -Corrigivel $true))
    }
    if ((Get-EscudoValor $Estado 'RDPLigado') -eq $true) {
        [void]$A.Add((New-EscudoAchado -Id 'win-rdp' -Area 'Anti-hacker' -Nivel 'Medio' -Titulo 'Área de Trabalho Remota ligada' -Detalhe 'É uma das portas mais atacadas por hackers.' -OQueFazer 'O Escudo desliga (dá para desfazer). Se você acessa este PC de longe, use "Desfazer" ou religue em Configurações > Sistema > Área de Trabalho Remota.' -Correcao $(if ($Config -and (Get-EscudoValor $Config 'corrigir_rdp') -eq $false) { $null } else { @{ Tipo = 'desligar-rdp' } })))
    }
    if ((Get-EscudoValor $Estado 'SecureBoot') -eq $false) {
        [void]$A.Add((New-EscudoAchado -Id 'win-secureboot' -Area 'Anti-hacker' -Nivel 'Medio' -Titulo 'Inicialização segura (Secure Boot) desligada' -Detalhe 'Deixa o PC exposto a vírus que carregam antes do Windows (rootkit).' -OQueFazer 'Pode ser ligada na BIOS/UEFI do PC. Se não souber, peça a um técnico.'))
    }
    if ((Get-EscudoValor $Estado 'Criptografia') -eq 'Desligada') {
        [void]$A.Add((New-EscudoAchado -Id 'win-bitlocker' -Area 'Privacidade' -Nivel 'Medio' -Titulo 'Disco sem criptografia' -Detalhe 'Se o PC for roubado, os arquivos podem ser lidos tirando o disco.' -OQueFazer 'Configurações > Privacidade e segurança > Criptografia do dispositivo (ou BitLocker no Windows Pro). Guarde a chave de recuperação.'))
    }
    if ((Get-EscudoValor $Estado 'ConvidadoAtivo') -eq $true) {
        [void]$A.Add((New-EscudoAchado -Id 'win-convidado' -Area 'Anti-hacker' -Nivel 'Alto' -Titulo 'Conta de Convidado ativa' -OQueFazer 'O Escudo desativa a conta de Convidado.' -Correcao @{ Tipo = 'desligar-convidado' }))
    }
    $admins = @(Get-EscudoValor $Estado 'Administradores')
    if ($admins.Count -gt 2) {
        [void]$A.Add((New-EscudoAchado -Id 'win-admins' -Area 'Anti-hacker' -Nivel 'Medio' -Titulo "$($admins.Count) contas com poder de administrador" -Detalhe ($admins -join ', ') -OQueFazer 'Confira se reconhece todas. Conta de administrador desconhecida é sinal de invasão.'))
    }

    # --- Arquivo hosts ---
    $hosts = @(Get-EscudoHostsSuspeitos -Linhas @(Get-EscudoValor $Estado 'HostsLinhas'))
    $sequestro = @($hosts | Where-Object { $_.Sensivel -and -not $_.Bloqueio })
    if ($sequestro.Count -gt 0) {
        [void]$A.Add((New-EscudoAchado -Id 'hosts-sequestro' -Area 'Anti-hacker' -Nivel 'Critico' -Titulo 'Sites importantes desviados no arquivo hosts' -Detalhe (($sequestro | ForEach-Object { "$($_.Nome) -> $($_.Ip)" }) -join ', ') -OQueFazer 'Golpe clássico para mandar você a um banco falso. O Escudo desativa essas linhas do arquivo hosts (guarda cópia) e varre o PC.' -Correcao @{ Tipo = 'limpar-hosts'; Nomes = @($sequestro | ForEach-Object { [string]$_.Nome }) }))
    }
    $bloqueioSeg = @($hosts | Where-Object { $_.Bloqueio -and $_.Nome -match '(?i)windowsupdate|update\.microsoft|wdcp\.microsoft|definitionupdates|go\.microsoft' })
    if ($bloqueioSeg.Count -gt 0) {
        [void]$A.Add((New-EscudoAchado -Id 'hosts-bloqueia-update' -Area 'Anti-hacker' -Nivel 'Critico' -Titulo 'Atualizações de segurança bloqueadas no arquivo hosts' -Detalhe (($bloqueioSeg | ForEach-Object Nome) -join ', ') -OQueFazer 'Vírus faz isso para o antivírus não se atualizar. O Escudo desativa essas linhas do hosts (guarda cópia) e varre o PC.' -Correcao @{ Tipo = 'limpar-hosts'; Nomes = @($bloqueioSeg | ForEach-Object { [string]$_.Nome }) }))
    }

    # --- Ameaças encontradas pelo antivírus ---
    foreach ($t in @(Get-EscudoValor $Estado 'Ameacas')) {
        if (-not $t) { continue }
        $nome = Get-EscudoValor $t 'Nome'
        $quando = Get-EscudoValor $t 'Data'
        if ((Get-EscudoValor $t 'Removida') -eq $false) {
            [void]$A.Add((New-EscudoAchado -Id "ameaca-$nome" -Area 'Antivírus' -Nivel 'Critico' -Titulo "Vírus encontrado e AINDA NÃO removido: $nome" -Detalhe "Detectado em $quando. Local: $(Get-EscudoValor $t 'Local')" -OQueFazer 'O Escudo manda o antivírus remover agora. Se voltar, rode "Varredura offline".' -Correcao @{ Tipo = 'remover-ameacas' }))
        } else {
            [void]$A.Add((New-EscudoAchado -Id "ameaca-$nome" -Area 'Antivírus' -Nivel 'Info' -Titulo "Vírus barrado: $nome" -Detalhe "Em $quando o antivírus bloqueou e removeu." -OQueFazer 'Nada a fazer. Se repetir muito, descubra de onde vem (pendrive, site, e-mail).'))
        }
    }

    # --- Inicialização, tarefas e processos ---
    $wl = Get-EscudoValor $Estado 'Winlogon'
    if ($wl) {
        $shell = [string](Get-EscudoValor $wl 'Shell')
        $userinit = [string](Get-EscudoValor $wl 'Userinit')
        if ($shell -and $shell.Trim().ToLower() -ne 'explorer.exe') {
            [void]$A.Add((New-EscudoAchado -Id 'winlogon-shell' -Area 'Invasão' -Nivel 'Critico' -Titulo 'O Windows foi mandado abrir outro programa no lugar da área de trabalho' -Detalhe "Shell = $shell" -OQueFazer 'Sinal forte de vírus. O Escudo volta o valor original (explorer.exe) e varre o PC. Depois rode "Varredura offline".' -Correcao @{ Tipo = 'restaurar-winlogon'; Valor = 'Shell'; Padrao = 'explorer.exe' }))
        }
        if ($userinit -and ($userinit.TrimEnd(',', ' ').ToLower() -notmatch '^c:\\windows\\system32\\userinit\.exe$')) {
            [void]$A.Add((New-EscudoAchado -Id 'winlogon-userinit' -Area 'Invasão' -Nivel 'Critico' -Titulo 'Programa extra pendurado no login do Windows' -Detalhe "Userinit = $userinit" -OQueFazer 'Sinal forte de vírus. O Escudo volta o valor original e varre o PC. Depois rode "Varredura offline".' -Correcao @{ Tipo = 'restaurar-winlogon'; Valor = 'Userinit'; Padrao = 'C:\Windows\system32\userinit.exe,' }))
        }
    }
    foreach ($i in @(Get-EscudoValor $Estado 'Inicializacao')) {
        if (-not $i) { continue }
        $cmd = [string](Get-EscudoValor $i 'Comando')
        $motivo = Get-EscudoMotivoComando $cmd
        $caminho = Get-EscudoCaminhoDoComando $cmd
        if (-not $motivo -and (Test-EscudoCaminhoSuspeito $caminho) -and (Get-EscudoValor $i 'Assinado') -ne $true) { $motivo = 'programa sem assinatura rodando de pasta temporária/downloads' }
        if ($motivo) {
            [void]$A.Add((New-EscudoAchado -Id "inicio-$(Get-EscudoValor $i 'Nome')" -Area 'Invasão' -Nivel 'Alto' -Titulo "Item suspeito liga junto com o Windows: $(Get-EscudoValor $i 'Nome')" -Detalhe "$motivo. Origem: $(Get-EscudoValor $i 'Origem'). Comando: $cmd" -OQueFazer 'O Escudo tira da inicialização (guarda para poder desfazer) e manda o antivírus examinar o arquivo.' -Correcao @{ Tipo = 'desativar-inicio'; Origem = [string](Get-EscudoValor $i 'Origem'); Nome = [string](Get-EscudoValor $i 'Nome'); Comando = $cmd; Arquivo = [string]$caminho }))
        }
    }
    foreach ($t in @(Get-EscudoValor $Estado 'Tarefas')) {
        if (-not $t) { continue }
        $cmd = [string](Get-EscudoValor $t 'Comando')
        $motivo = Get-EscudoMotivoComando $cmd
        if (-not $motivo -and (Test-EscudoCaminhoSuspeito (Get-EscudoCaminhoDoComando $cmd))) { $motivo = 'roda programa de pasta temporária/downloads' }
        if ($motivo) {
            [void]$A.Add((New-EscudoAchado -Id "tarefa-$(Get-EscudoValor $t 'Nome')" -Area 'Invasão' -Nivel 'Alto' -Titulo "Tarefa agendada suspeita: $(Get-EscudoValor $t 'Nome')" -Detalhe "$motivo. Comando: $cmd" -OQueFazer 'O Escudo desativa a tarefa (dá para desfazer) e manda o antivírus examinar o arquivo.' -Correcao @{ Tipo = 'desativar-tarefa'; Nome = [string](Get-EscudoValor $t 'Nome'); Arquivo = [string](Get-EscudoCaminhoDoComando $cmd) }))
        }
    }
    foreach ($p in @(Get-EscudoValor $Estado 'Processos')) {
        if (-not $p) { continue }
        $cam = [string](Get-EscudoValor $p 'Caminho')
        $cmd = [string](Get-EscudoValor $p 'Comando')
        $motivo = Get-EscudoMotivoComando $cmd
        $forte = [bool]$motivo
        if (-not $motivo -and (Test-EscudoCaminhoSuspeito $cam) -and (Get-EscudoValor $p 'Assinado') -ne $true) { $motivo = 'programa sem assinatura rodando de pasta temporária/downloads' }
        if ($motivo) {
            [void]$A.Add((New-EscudoAchado -Id "processo-$(Get-EscudoValor $p 'Pid')" -Area 'Invasão' -Nivel 'Alto' -Titulo "Programa suspeito rodando agora: $(Get-EscudoValor $p 'Nome')" -Detalhe "$motivo. Caminho: $cam" -OQueFazer $(if ($forte) { 'O Escudo encerra esse processo e manda o antivírus examinar o arquivo.' } else { 'O Escudo manda o antivírus examinar o arquivo. Se for algo que você acabou de baixar e confia, pode ignorar.' }) -Correcao @{ Tipo = 'processo'; Pid = (Get-EscudoValor $p 'Pid'); Arquivo = $cam; Encerrar = $forte }))
        }
    }

    # --- Novidades desde a última vigia ---
    foreach ($n in @(Get-EscudoValor $Estado 'Novidades')) {
        if (-not $n) { continue }
        [void]$A.Add((New-EscudoAchado -Id "novo-$($n.Tipo)-$($n.Chave)" -Area 'Vigia' -Nivel 'Medio' -Titulo "Novo desde a última vigia ($($n.Tipo)): $($n.Nome)" -Detalhe $n.Detalhe -OQueFazer 'Se foi você que instalou, tudo certo. Se não reconhece, investigue: pode ser invasão.'))
    }

    return @($A | Sort-Object @{ Expression = { Get-EscudoOrdem $_.Nivel } }, Area, Titulo)
}

# ---------------------------------------------------------------------------
# Linha de base (o que mudou desde a última vez)
# ---------------------------------------------------------------------------

function Get-EscudoFotografia {
    <# Resumo do que liga com o PC, para comparar depois. #>
    param($Estado)
    $itens = @()
    foreach ($i in @(Get-EscudoValor $Estado 'Inicializacao')) {
        if ($i) { $itens += [pscustomobject]@{ Tipo = 'inicialização'; Chave = "$($i.Origem)|$($i.Nome)|$($i.Comando)"; Nome = $i.Nome; Detalhe = $i.Comando } }
    }
    foreach ($t in @(Get-EscudoValor $Estado 'Tarefas')) {
        if ($t) { $itens += [pscustomobject]@{ Tipo = 'tarefa agendada'; Chave = "$($t.Nome)|$($t.Comando)"; Nome = $t.Nome; Detalhe = $t.Comando } }
    }
    foreach ($s in @(Get-EscudoValor $Estado 'Servicos')) {
        if ($s) { $itens += [pscustomobject]@{ Tipo = 'serviço'; Chave = "$($s.Nome)|$($s.Caminho)"; Nome = $s.Nome; Detalhe = $s.Caminho } }
    }
    foreach ($u in @(Get-EscudoValor $Estado 'Administradores')) {
        if ($u) { $itens += [pscustomobject]@{ Tipo = 'administrador'; Chave = "$u"; Nome = "$u"; Detalhe = 'Conta com poder de administrador' } }
    }
    return $itens
}

function Compare-EscudoLinhaDeBase {
    <# Devolve os itens que existem agora e não existiam antes. #>
    param([object[]]$Antes, [object[]]$Agora)
    $vistos = @{}
    foreach ($a in @($Antes)) { if ($a) { $vistos[[string]$a.Chave] = $true } }
    $novos = @()
    foreach ($n in @($Agora)) {
        if ($n -and -not $vistos.ContainsKey([string]$n.Chave)) { $novos += $n }
    }
    return $novos
}

# ---------------------------------------------------------------------------
# Coleta no Windows (só funciona no Windows)
# ---------------------------------------------------------------------------

function Get-EscudoAssinado {
    param([string]$Caminho)
    if (-not $Caminho -or -not (Test-Path -LiteralPath $Caminho -ErrorAction SilentlyContinue)) { return $null }
    try { return ((Get-AuthenticodeSignature -LiteralPath $Caminho -ErrorAction Stop).Status -eq 'Valid') } catch { return $null }
}

function Get-EscudoInicializacao {
    $itens = @()
    $chaves = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
    )
    foreach ($k in $chaves) {
        try {
            $props = Get-ItemProperty -Path $k -ErrorAction Stop
            foreach ($p in $props.PSObject.Properties) {
                if ($p.Name -like 'PS*') { continue }
                $cmd = [string]$p.Value
                $itens += [pscustomobject]@{ Origem = $k; Nome = $p.Name; Comando = $cmd; Assinado = (Get-EscudoAssinado (Get-EscudoCaminhoDoComando $cmd)) }
            }
        } catch { }
    }
    $shell = $null
    foreach ($pasta in @([Environment]::GetFolderPath('Startup'), [Environment]::GetFolderPath('CommonStartup'))) {
        if (-not $pasta -or -not (Test-Path $pasta)) { continue }
        foreach ($f in Get-ChildItem -LiteralPath $pasta -File -ErrorAction SilentlyContinue) {
            if ($f.Name -eq 'desktop.ini') { continue }
            $cmd = $f.FullName
            if ($f.Extension -eq '.lnk') {
                try {
                    if (-not $shell) { $shell = New-Object -ComObject WScript.Shell }
                    $lnk = $shell.CreateShortcut($f.FullName)
                    $cmd = ('"{0}" {1}' -f $lnk.TargetPath, $lnk.Arguments).Trim()
                } catch { }
            }
            $itens += [pscustomobject]@{ Origem = $pasta; Nome = $f.Name; Comando = $cmd; Assinado = (Get-EscudoAssinado (Get-EscudoCaminhoDoComando $cmd)) }
        }
    }
    return $itens
}

function Get-EscudoTarefas {
    $saida = @()
    try {
        foreach ($t in Get-ScheduledTask -ErrorAction Stop) {
            if ($t.State -eq 'Disabled') { continue }
            foreach ($a in @($t.Actions)) {
                $exe = Get-EscudoValor $a 'Execute'
                if (-not $exe) { continue }
                $cmd = ('"{0}" {1}' -f [Environment]::ExpandEnvironmentVariables($exe), (Get-EscudoValor $a 'Arguments')).Trim()
                $saida += [pscustomobject]@{ Nome = ($t.TaskPath + $t.TaskName); Comando = $cmd; Microsoft = ($t.TaskPath -like '\Microsoft\*') }
            }
        }
    } catch { }
    return $saida
}

function Get-EscudoProcessos {
    $saida = @()
    try {
        foreach ($p in Get-CimInstance Win32_Process -ErrorAction Stop) {
            $cam = $p.ExecutablePath
            $cmd = $p.CommandLine
            if (-not ((Test-EscudoCaminhoSuspeito $cam) -or (Get-EscudoMotivoComando $cmd))) { continue }
            $saida += [pscustomobject]@{ Pid = $p.ProcessId; Nome = $p.Name; Caminho = $cam; Comando = $cmd; Assinado = (Get-EscudoAssinado $cam) }
        }
    } catch { }
    return $saida
}

function Get-EscudoEstado {
    <# Lê tudo do Windows. Cada leitura que falhar vira $null (nunca derruba o Escudo). #>
    $e = [ordered]@{
        Computador = $env:COMPUTERNAME
        Data       = (Get-Date).ToString('yyyy-MM-dd HH:mm')
        Windows    = $null
        Admin      = (Test-EscudoAdmin)
    }
    # Toda chave existe desde o início (vale $null se a leitura falhar), para nada quebrar depois.
    foreach ($k in @('Defender', 'Preferencias', 'Firewall', 'DiasSemAtualizacao', 'ReinicioPendente', 'UAC', 'SMB1', 'RDPLigado', 'SecureBoot', 'Criptografia', 'ConvidadoAtivo', 'Administradores', 'HostsLinhas', 'Ameacas', 'Winlogon', 'Inicializacao', 'Tarefas', 'Processos', 'Servicos')) { $e[$k] = $null }
    try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop; $e.Windows = "$($os.Caption) (versão $($os.Version))" } catch { }

    try {
        $s = Get-MpComputerStatus -ErrorAction Stop
        $e.Defender = [pscustomobject]@{
            AMRunningMode             = (Get-EscudoValor $s 'AMRunningMode')
            AntivirusEnabled          = $s.AntivirusEnabled
            RealTimeProtectionEnabled = $s.RealTimeProtectionEnabled
            BehaviorMonitorEnabled    = $s.BehaviorMonitorEnabled
            IsTamperProtected         = (Get-EscudoValor $s 'IsTamperProtected')
            AntivirusSignatureAge     = $s.AntivirusSignatureAge
            AntivirusSignatureVersion = $s.AntivirusSignatureVersion
            QuickScanAge              = $s.QuickScanAge
            FullScanAge               = $s.FullScanAge
        }
    } catch { $e.Defender = $null }

    try {
        $p = Get-MpPreference -ErrorAction Stop
        $e.Preferencias = [pscustomobject]@{
            DisableRealtimeMonitoring         = $p.DisableRealtimeMonitoring
            MAPSReporting                     = [int]$p.MAPSReporting
            SubmitSamplesConsent              = [int]$p.SubmitSamplesConsent
            PUAProtection                     = [int]$p.PUAProtection
            EnableNetworkProtection           = [int]$p.EnableNetworkProtection
            EnableControlledFolderAccess      = [int]$p.EnableControlledFolderAccess
            CloudBlockLevel                   = [int]$p.CloudBlockLevel
            AttackSurfaceReductionRules_Ids     = @($p.AttackSurfaceReductionRules_Ids)
            AttackSurfaceReductionRules_Actions = @($p.AttackSurfaceReductionRules_Actions | ForEach-Object { [int]$_ })
            ExclusionPath                     = @($p.ExclusionPath)
            ExclusionExtension                = @($p.ExclusionExtension)
            ExclusionProcess                  = @($p.ExclusionProcess)
        }
    } catch { $e.Preferencias = $null }

    try {
        $e.Firewall = @(Get-NetFirewallProfile -ErrorAction Stop | ForEach-Object {
                [pscustomobject]@{ Name = [string]$_.Name; Enabled = [bool]($_.Enabled -eq $true -or [string]$_.Enabled -eq 'True'); DefaultInboundAction = [string]$_.DefaultInboundAction }
            })
    } catch { $e.Firewall = @() }

    # Última atualização do Windows: histórico do Windows Update (data em formato de máquina, sem erro de dia/mês
    # do Get-HotFix em português). Vacinas diárias do Defender não contam: elas escondiam o Windows parado.
    try {
        $sessao = New-Object -ComObject Microsoft.Update.Session
        $busca = $sessao.CreateUpdateSearcher()
        $total = $busca.GetTotalHistoryCount()
        if ($total -gt 0) {
            $datas = @($busca.QueryHistory(0, [Math]::Min($total, 200)) | Where-Object {
                    $_.Operation -eq 1 -and $_.ResultCode -in @(2, 3) -and (Test-EscudoAtualizacaoDoWindows $_.Title)
                } | ForEach-Object { [datetime]$_.Date })
            if ($datas.Count -gt 0) { $e.DiasSemAtualizacao = [int]((Get-Date).ToUniversalTime() - ($datas | Sort-Object -Descending | Select-Object -First 1)).TotalDays }
        }
    } catch { }
    if ($null -eq $e.DiasSemAtualizacao) {
        try {
            $ultima = Get-CimInstance Win32_QuickFixEngineering -ErrorAction Stop | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 1
            if ($ultima) { $e.DiasSemAtualizacao = [int]((Get-Date) - [datetime]$ultima.InstalledOn).TotalDays }
        } catch { }
    }
    $e.ReinicioPendente = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')

    try {
        $u = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -ErrorAction Stop
        $e.UAC = [pscustomobject]@{ EnableLUA = (Get-EscudoValor $u 'EnableLUA'); ConsentPromptBehaviorAdmin = (Get-EscudoValor $u 'ConsentPromptBehaviorAdmin') }
    } catch { }
    try { $e.SMB1 = [bool](Get-SmbServerConfiguration -ErrorAction Stop).EnableSMB1Protocol } catch { }
    try { $e.RDPLigado = ((Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -ErrorAction Stop).fDenyTSConnections -eq 0) } catch { }
    try { $e.SecureBoot = [bool](Confirm-SecureBootUEFI -ErrorAction Stop) } catch { }
    try {
        $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
        $e.Criptografia = if ([string]$bl.ProtectionStatus -eq 'On') { 'Ligada' } else { 'Desligada' }
    } catch { }
    try {
        $guest = Get-LocalUser -ErrorAction Stop | Where-Object { $_.SID.Value -like '*-501' }
        $e.ConvidadoAtivo = [bool]($guest -and $guest.Enabled)
    } catch { }
    try { $e.Administradores = @(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | ForEach-Object { [string]$_.Name }) } catch {
        # Get-LocalGroupMember falha quando o grupo tem conta antiga/órfã; o ADSI lê do mesmo jeito.
        try {
            $grupo = (New-Object System.Security.Principal.SecurityIdentifier('S-1-5-32-544')).Translate([System.Security.Principal.NTAccount]).Value.Split('\')[-1]
            $e.Administradores = @(([ADSI]"WinNT://$env:COMPUTERNAME/$grupo,group").psbase.Invoke('Members') | ForEach-Object { $_.GetType().InvokeMember('Name', 'GetProperty', $null, $_, $null) })
        } catch { }
    }

    try { $e.HostsLinhas = @(Get-Content (Join-Path $env:SystemRoot 'System32\drivers\etc\hosts') -ErrorAction Stop) } catch { }

    try {
        $nomes = @{}
        foreach ($t in Get-MpThreat -ErrorAction Stop) { $nomes[[string]$t.ThreatID] = $t.ThreatName }
        $desde = (Get-Date).AddDays(-30)
        $e.Ameacas = @(Get-MpThreatDetection -ErrorAction Stop | Where-Object { $_.InitialDetectionTime -ge $desde } | ForEach-Object {
                [pscustomobject]@{
                    Nome     = $(if ($nomes[[string]$_.ThreatID]) { $nomes[[string]$_.ThreatID] } else { "ID $($_.ThreatID)" })
                    Data     = ([datetime]$_.InitialDetectionTime).ToString('dd/MM/yyyy HH:mm')
                    Removida = [bool]$_.ActionSuccess
                    Local    = (@($_.Resources) -join '; ')
                }
            })
    } catch { $e.Ameacas = @() }

    try {
        $w = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -ErrorAction Stop
        $e.Winlogon = [pscustomobject]@{ Shell = (Get-EscudoValor $w 'Shell'); Userinit = (Get-EscudoValor $w 'Userinit') }
    } catch { }

    $e.Inicializacao = @(Get-EscudoInicializacao)
    $e.Tarefas = @(Get-EscudoTarefas)
    $e.Processos = @(Get-EscudoProcessos)
    try { $e.Servicos = @(Get-CimInstance Win32_Service -ErrorAction Stop | ForEach-Object { [pscustomobject]@{ Nome = $_.Name; Caminho = $_.PathName } }) } catch { $e.Servicos = @() }

    return [pscustomobject]$e
}

# ---------------------------------------------------------------------------
# Relatório HTML
# ---------------------------------------------------------------------------

function ConvertTo-EscudoHtml {
    param(
        [Parameter(Mandatory)][string]$Titulo,
        [string]$Subtitulo = '',
        $Nota,
        [object[]]$Achados,
        [string[]]$Resumo = @(),
        $NotaAntes = $null,
        [object[]]$Corrigidos = @()
    )
    $enc = { param($t) [System.Net.WebUtility]::HtmlEncode([string]$t) }
    $cor = if ($null -eq $Nota) { '#718096' } elseif ($Nota -ge 85) { '#1f9d55' } elseif ($Nota -ge 60) { '#d69e2e' } else { '#c53030' }
    $notaTxt = if ($null -eq $Nota) { '—' } else { [string][int]$Nota }
    $rotulo = @{ Critico = 'CRÍTICO'; Alto = 'ALTO'; Medio = 'MÉDIO'; Info = 'INFO' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append(@"
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>$(& $enc $Titulo)</title>
<style>
:root{--fundo:#f5f7fa;--cartao:#fff;--texto:#1a202c;--suave:#5a6577;--borda:#e2e8f0;--marca:#0b3d91}
@media (prefers-color-scheme:dark){:root{--fundo:#0f141b;--cartao:#18202b;--texto:#e8edf3;--suave:#9aa7b8;--borda:#2a3443;--marca:#6ea8ff}}
body{margin:0;background:var(--fundo);color:var(--texto);font:15px/1.5 Segoe UI,system-ui,sans-serif}
.topo{background:var(--marca);color:#fff;padding:20px 16px}.topo h1{margin:0;font-size:22px}.topo p{margin:4px 0 0;opacity:.85}
main{max-width:920px;margin:0 auto;padding:16px}
.nota{display:flex;gap:16px;align-items:center;background:var(--cartao);border:1px solid var(--borda);border-radius:12px;padding:16px;margin-bottom:16px}
.nota b{font-size:44px;color:$cor;min-width:90px;text-align:center}
.nota ul{margin:0;padding-left:18px;color:var(--suave)}
.item{background:var(--cartao);border:1px solid var(--borda);border-left:6px solid #a0aec0;border-radius:10px;padding:12px 14px;margin:10px 0}
.item.Critico{border-left-color:#c53030}.item.Alto{border-left-color:#dd6b20}.item.Medio{border-left-color:#d69e2e}.item.Info{border-left-color:#3182ce}
.tag{font-size:11px;font-weight:700;letter-spacing:.04em;padding:2px 8px;border-radius:99px;background:var(--borda);margin-right:6px}
.area{color:var(--suave);font-size:13px}.det{color:var(--suave);margin:6px 0 0;word-break:break-word}.faz{margin:6px 0 0}
.sec{font-size:17px;margin:22px 0 6px}.feito{background:var(--cartao);border:1px solid var(--borda);border-left:6px solid #1f9d55;border-radius:10px;padding:10px 14px;margin:8px 0}
.ok{padding:24px;text-align:center;background:var(--cartao);border-radius:12px;border:1px solid var(--borda)}
footer{color:var(--suave);font-size:12px;text-align:center;padding:24px 16px}
</style></head><body>
<div class="topo"><h1>$(& $enc $Titulo)</h1><p>$(& $enc $Subtitulo)</p></div><main>
<div class="nota"><b>$notaTxt</b><div><strong>Nota de segurança (0 a 100)</strong><ul>
"@)
    foreach ($r in $Resumo) { [void]$sb.Append("<li>$(& $enc $r)</li>") }
    [void]$sb.Append('</ul></div></div>')
    $feitos = @($Corrigidos | Where-Object { $_ })
    if ($feitos.Count -gt 0) {
        $tituloFeitos = if ($null -ne $NotaAntes) { "O que o Escudo corrigiu agora (nota $([int]$NotaAntes) → $notaTxt)" } else { 'O que o Escudo corrigiu agora' }
        [void]$sb.Append("<h2 class=""sec"">$(& $enc $tituloFeitos)</h2>")
        foreach ($f in $feitos) {
            $cls = if ($f.Ok) { 'feito' } else { 'item Alto' }
            $marca = if ($f.Ok) { '✓' } else { '✗' }
            $extra = if ($f.Ok) { $f.Obs } else { "Não deu: $($f.Erro)" }
            $pExtra = if ($extra) { '<p class="det">' + (& $enc $extra) + '</p>' } else { '' }
            [void]$sb.Append('<div class="' + $cls + '"><strong>' + $marca + ' ' + (& $enc $f.Texto) + '</strong>' + $pExtra + '</div>')
        }
        [void]$sb.Append('<h2 class="sec">O que ainda falta</h2>')
    }
    $lista = @($Achados | Where-Object { $_ })
    if ($lista.Count -eq 0) {
        [void]$sb.Append('<div class="ok"><strong>Nenhum problema encontrado.</strong><br>Continue com o Escudo ligado.</div>')
    }
    foreach ($a in $lista) {
        [void]$sb.Append("<div class=""item $($a.Nivel)""><span class=""tag"">$($rotulo[$a.Nivel])</span><span class=""area"">$(& $enc $a.Area)</span><div><strong>$(& $enc $a.Titulo)</strong></div>")
        if ($a.Detalhe) { [void]$sb.Append("<p class=""det"">$(& $enc $a.Detalhe)</p>") }
        if ($a.OQueFazer) { [void]$sb.Append("<p class=""faz""><b>O que fazer:</b> $(& $enc $a.OQueFazer)</p>") }
        [void]$sb.Append('</div>')
    }
    [void]$sb.Append("</main><footer>Escudo Infinity Guard $script:Versao · Segurança onde você estiver · O Escudo nunca apaga arquivos: quem remove vírus é o antivírus do Windows, e o que o Escudo tira do caminho vai para a quarentena e pode ser desfeito.</footer></body></html>")
    return $sb.ToString()
}

function Save-EscudoRelatorio {
    param([string]$Html, [string]$Prefixo = 'pc')
    $pasta = Join-Path (Get-EscudoPastaDados) 'relatorios'
    $arq = Join-Path $pasta ('{0}-{1}.html' -f $Prefixo, (Get-Date -Format 'yyyy-MM-dd-HHmm'))
    [System.IO.File]::WriteAllText($arq, $Html, (New-Object System.Text.UTF8Encoding($true)))
    Copy-Item $arq (Join-Path $pasta ("ultimo-$Prefixo.html")) -Force
    # Mantém só os 60 relatórios mais novos de cada tipo
    Get-ChildItem $pasta -Filter "$Prefixo-*.html" | Sort-Object LastWriteTime -Descending | Select-Object -Skip 60 | Remove-Item -Force -ErrorAction SilentlyContinue
    return $arq
}

function Show-EscudoAviso {
    param([string]$Titulo, [string]$Texto, [ValidateSet('Info', 'Warning', 'Error')][string]$Tipo = 'Warning')
    try {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing -ErrorAction Stop
        $n = New-Object System.Windows.Forms.NotifyIcon
        $n.Icon = [System.Drawing.SystemIcons]::Shield
        $n.Visible = $true
        $n.ShowBalloonTip(15000, $Titulo, $Texto, [System.Windows.Forms.ToolTipIcon]::$Tipo)
        Start-Sleep -Seconds 10
        $n.Dispose()
    } catch { }
}

# ---------------------------------------------------------------------------
# Ações
# ---------------------------------------------------------------------------

function Invoke-EscudoDiagnostico {
    <# Lê o PC, gera o relatório HTML e devolve o resultado. Não muda nada. #>
    param([switch]$ComNovidades, [switch]$NaoAbrir)
    $cfg = Get-EscudoConfig
    $estado = Get-EscudoEstado
    if ($ComNovidades) {
        $arqBase = Join-Path (Get-EscudoPastaDados) 'linha-de-base.json'
        $agora = @(Get-EscudoFotografia $estado)
        if (Test-Path $arqBase) {
            # ForEach-Object desenrola a lista (no Windows PowerShell 5.1 o ConvertFrom-Json entrega a lista inteira como 1 item)
            $antes = @([System.IO.File]::ReadAllText($arqBase, [System.Text.Encoding]::UTF8) | ConvertFrom-Json | ForEach-Object { $_ })
            $novos = @(Compare-EscudoLinhaDeBase -Antes $antes -Agora $agora)
            $estado | Add-Member -NotePropertyName Novidades -NotePropertyValue $novos -Force
        }
        [System.IO.File]::WriteAllText($arqBase, (ConvertTo-Json -InputObject $agora -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
    }
    $achados = @(Get-EscudoAchados -Estado $estado -Config $cfg)
    $nota = Get-EscudoNota $achados
    $def = $estado.Defender
    $resumo = @(
        "Computador: $($estado.Computador) · $($estado.Windows)",
        $(if ($def) { "Antivírus: tempo real $(if ($def.RealTimeProtectionEnabled) { 'ligado' } else { 'DESLIGADO' }), vacinas de $($def.AntivirusSignatureAge) dia(s)" } else { 'Antivírus: não consegui ler' }),
        "Problemas: $(@($achados | Where-Object Nivel -eq 'Critico').Count) crítico(s), $(@($achados | Where-Object Nivel -eq 'Alto').Count) alto(s), $(@($achados | Where-Object Nivel -eq 'Medio').Count) médio(s)",
        $(if (-not $estado.Admin) { 'Rodou sem administrador: algumas leituras ficaram de fora.' } else { 'Leitura completa (administrador).' })
    )
    $html = ConvertTo-EscudoHtml -Titulo 'Escudo Infinity Guard: saúde do PC' -Subtitulo $estado.Data -Nota $nota -Achados $achados -Resumo $resumo
    $arq = Save-EscudoRelatorio -Html $html -Prefixo 'pc'
    Write-EscudoLog "Diagnóstico: nota $nota, $($achados.Count) achado(s). Relatório: $arq"
    if (-not $NaoAbrir) { try { Start-Process $arq } catch { } }
    return [pscustomobject]@{ Nota = $nota; Achados = $achados; Relatorio = $arq; Estado = $estado }
}

function Get-EscudoPlanoDeReforco {
    <# Lista o que o "Reforçar" vai mudar, com o valor atual de cada item. Não muda nada. #>
    param($Estado, $Config)
    $plano = @()
    $p = Get-EscudoValor $Estado 'Preferencias'
    $nuvem = @{ Default = 0; Moderate = 1; High = 2; HighPlus = 4; ZeroTolerance = 6 }[$Config.nivel_nuvem]
    $pastasModo = @{ Disabled = 0; Enabled = 1; AuditMode = 2 }[$Config.pastas_protegidas_modo]
    if ($p) {
        if ($p.DisableRealtimeMonitoring -ne $false) { $plano += [pscustomobject]@{ Id = 'tempo-real'; Texto = 'Ligar proteção em tempo real' } }
        if ($p.MAPSReporting -ne 2) { $plano += [pscustomobject]@{ Id = 'nuvem'; Texto = 'Ligar proteção na nuvem (avançada)' } }
        if ($p.SubmitSamplesConsent -ne 1) { $plano += [pscustomobject]@{ Id = 'amostras'; Texto = 'Enviar amostras seguras automaticamente (nunca documentos pessoais)' } }
        if ($p.CloudBlockLevel -lt $nuvem) { $plano += [pscustomobject]@{ Id = 'nivel-nuvem'; Texto = "Nível de bloqueio da nuvem: $($Config.nivel_nuvem)" } }
        if ($p.PUAProtection -ne 1) { $plano += [pscustomobject]@{ Id = 'pua'; Texto = 'Bloquear programas indesejados (adware, mineradores)' } }
        if ($p.EnableNetworkProtection -ne 1) { $plano += [pscustomobject]@{ Id = 'rede'; Texto = 'Ligar proteção de rede (bloqueia sites de golpe e de hacker)' } }
        if ($p.EnableControlledFolderAccess -ne $pastasModo) { $plano += [pscustomobject]@{ Id = 'pastas'; Texto = "Pastas protegidas contra ransomware: $($Config.pastas_protegidas_modo)" } }
        $plano += [pscustomobject]@{ Id = 'asr'; Texto = "Regras anti-ataque: $(@($Config.regras_asr).Count) regras" }
    } else {
        $plano += [pscustomobject]@{ Id = 'tudo-defender'; Texto = 'Configurar o Defender (não consegui ler o estado atual)' }
    }
    foreach ($f in @(Get-EscudoValor $Estado 'Firewall')) {
        if ($f -and (-not $f.Enabled -or $f.DefaultInboundAction -match '(?i)^allow')) { $plano += [pscustomobject]@{ Id = 'firewall'; Texto = 'Ligar o firewall em todas as redes e bloquear entrada não autorizada' }; break }
    }
    if ((Get-EscudoValor $Estado 'SMB1') -eq $true) { $plano += [pscustomobject]@{ Id = 'smb1'; Texto = 'Desligar o compartilhamento antigo SMB1' } }
    $plano += [pscustomobject]@{ Id = 'vacinas'; Texto = 'Atualizar as vacinas do antivírus agora' }
    return $plano
}

function Invoke-EscudoReforco {
    <# Aplica as configurações recomendadas. Salva o estado anterior para "Desfazer". #>
    [CmdletBinding(SupportsShouldProcess)]
    param([switch]$Sim)
    if (-not (Test-EscudoAdmin)) { throw 'Reforçar precisa ser rodado como administrador.' }
    $cfg = Get-EscudoConfig
    $estado = Get-EscudoEstado
    $plano = @(Get-EscudoPlanoDeReforco -Estado $estado -Config $cfg)
    Write-Host ''
    Write-Host 'O Escudo vai fazer estas mudanças (todas podem ser desfeitas):' -ForegroundColor Cyan
    foreach ($i in $plano) { Write-Host "  - $($i.Texto)" }
    if (-not $Sim) {
        $r = Read-Host 'Confirmar? (S/N)'
        if ($r -notmatch '^(s|sim|y|yes)$') { Write-Host 'Nada foi mudado.'; return }
    }

    $backup = [pscustomobject]@{
        Data         = (Get-Date).ToString('s')
        Preferencias = $estado.Preferencias
        Firewall     = $estado.Firewall
        SMB1         = $estado.SMB1
    }
    $arqBackup = Join-Path (Join-Path (Get-EscudoPastaDados) 'backup') ('antes-do-reforco-{0}.json' -f (Get-Date -Format 'yyyy-MM-dd-HHmmss'))
    [System.IO.File]::WriteAllText($arqBackup, (ConvertTo-Json -InputObject $backup -Depth 5), (New-Object System.Text.UTF8Encoding($false)))
    Write-EscudoLog "Reforço: backup salvo em $arqBackup"

    $resultado = @()
    $passo = {
        param($Nome, [scriptblock]$Bloco)
        try {
            if ($PSCmdlet.ShouldProcess($Nome)) { & $Bloco }
            Write-Host "  [ok] $Nome" -ForegroundColor Green
            [pscustomobject]@{ Passo = $Nome; Ok = $true; Erro = $null }
        } catch {
            Write-Host "  [falhou] $Nome : $($_.Exception.Message)" -ForegroundColor Yellow
            [pscustomobject]@{ Passo = $Nome; Ok = $false; Erro = $_.Exception.Message }
        }
    }
    $nuvem = @{ Default = 0; Moderate = 1; High = 2; HighPlus = 4; ZeroTolerance = 6 }[$cfg.nivel_nuvem]
    $resultado += & $passo 'Proteção em tempo real e monitor de comportamento' { Set-MpPreference -DisableRealtimeMonitoring $false -DisableBehaviorMonitoring $false -DisableIOAVProtection $false -DisableScriptScanning $false -ErrorAction Stop }
    $resultado += & $passo 'Proteção na nuvem' { Set-MpPreference -MAPSReporting Advanced -SubmitSamplesConsent SendSafeSamples -CloudBlockLevel $nuvem -CloudExtendedTimeout 50 -ErrorAction Stop }
    $resultado += & $passo 'Bloqueio de programas indesejados' { Set-MpPreference -PUAProtection Enabled -ErrorAction Stop }
    $resultado += & $passo 'Proteção de rede' { Set-MpPreference -EnableNetworkProtection Enabled -ErrorAction Stop }
    $resultado += & $passo 'Pastas protegidas contra ransomware' { Set-MpPreference -EnableControlledFolderAccess $cfg.pastas_protegidas_modo -ErrorAction Stop }
    $resultado += & $passo 'Regras anti-ataque (ASR)' {
        $ids = @($cfg.regras_asr | ForEach-Object { $_.id })
        $acoes = @($cfg.regras_asr | ForEach-Object { $_.acao })
        Add-MpPreference -AttackSurfaceReductionRules_Ids $ids -AttackSurfaceReductionRules_Actions $acoes -ErrorAction Stop
    }
    $resultado += & $passo 'Firewall ligado em todas as redes' { Set-NetFirewallProfile -Profile Domain, Public, Private -Enabled True -DefaultInboundAction Block -ErrorAction Stop }
    if ($estado.SMB1 -eq $true) {
        $resultado += & $passo 'Desligar SMB1' { Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction Stop }
    }
    $resultado += & $passo 'Atualizar vacinas' { Update-MpSignature -ErrorAction Stop }

    Write-Host ''
    Write-Host "Backup do estado anterior: $arqBackup"
    Write-Host 'Para voltar como estava: Escudo -> Desfazer reforço.'
    Write-Host 'Falta só 1 coisa que o Windows não deixa script nenhum fazer: ligar a "Proteção contra adulteração" (Segurança do Windows > Proteção contra vírus e ameaças > Gerenciar configurações).' -ForegroundColor Cyan
    Write-EscudoLog ("Reforço aplicado: " + (($resultado | ForEach-Object { "$($_.Passo)=$(if ($_.Ok) { 'ok' } else { 'falhou' })" }) -join '; '))
    return $resultado
}

function Invoke-EscudoDesfazer {
    <# Volta as configurações para como estavam antes do último "Reforçar". #>
    [CmdletBinding(SupportsShouldProcess)]
    param([string]$Arquivo, [switch]$Sim)
    if (-not (Test-EscudoAdmin)) { throw 'Desfazer precisa ser rodado como administrador.' }
    $pasta = Join-Path (Get-EscudoPastaDados) 'backup'
    if (-not $Arquivo) {
        $ultimo = Get-ChildItem $pasta -Filter 'antes-do-reforco-*.json' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
        if (-not $ultimo) { Write-Host 'Não achei nenhum backup. Nada para desfazer.'; return }
        $Arquivo = $ultimo.FullName
    }
    $b = [System.IO.File]::ReadAllText($Arquivo, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    Write-Host "Vou voltar as configurações salvas em $($b.Data)."
    if (-not $Sim) { if ((Read-Host 'Confirmar? (S/N)') -notmatch '^(s|sim|y|yes)$') { Write-Host 'Nada foi mudado.'; return } }
    $p = $b.Preferencias
    if ($p -and $PSCmdlet.ShouldProcess('Defender')) {
        Set-MpPreference -MAPSReporting $p.MAPSReporting -SubmitSamplesConsent $p.SubmitSamplesConsent -PUAProtection $p.PUAProtection -EnableNetworkProtection $p.EnableNetworkProtection -EnableControlledFolderAccess $p.EnableControlledFolderAccess -CloudBlockLevel $p.CloudBlockLevel -ErrorAction SilentlyContinue
        $cfg = Get-EscudoConfig
        $antes = @{}
        for ($i = 0; $i -lt @($p.AttackSurfaceReductionRules_Ids).Count; $i++) { $antes[([string]$p.AttackSurfaceReductionRules_Ids[$i]).ToUpper()] = $p.AttackSurfaceReductionRules_Actions[$i] }
        foreach ($r in @($cfg.regras_asr)) {
            $id = $r.id.ToUpper()
            if ($antes.ContainsKey($id)) { Add-MpPreference -AttackSurfaceReductionRules_Ids $id -AttackSurfaceReductionRules_Actions $antes[$id] -ErrorAction SilentlyContinue }
            else { Remove-MpPreference -AttackSurfaceReductionRules_Ids $id -ErrorAction SilentlyContinue }
        }
    }
    foreach ($f in @($b.Firewall)) {
        if ($f -and $PSCmdlet.ShouldProcess("Firewall $($f.Name)")) {
            Set-NetFirewallProfile -Profile $f.Name -Enabled ([string]$f.Enabled) -DefaultInboundAction $f.DefaultInboundAction -ErrorAction SilentlyContinue
        }
    }
    if ($b.SMB1 -eq $true -and $PSCmdlet.ShouldProcess('SMB1')) { Set-SmbServerConfiguration -EnableSMB1Protocol $true -Force -ErrorAction SilentlyContinue }
    Write-EscudoLog "Desfeito a partir de $Arquivo"
    Write-Host 'Pronto: configurações voltaram ao que eram antes.' -ForegroundColor Green
}

function Invoke-EscudoVarredura {
    param([ValidateSet('Rapida', 'Completa', 'Pasta')][string]$Tipo = 'Rapida', [string]$Caminho)
    Write-Host 'Atualizando vacinas...'
    try { Update-MpSignature -ErrorAction Stop } catch { Write-Host "Não consegui atualizar agora: $($_.Exception.Message)" -ForegroundColor Yellow }
    Write-EscudoLog "Varredura $Tipo iniciada $Caminho"
    switch ($Tipo) {
        'Rapida' { Start-MpScan -ScanType QuickScan }
        'Completa' { Write-Host 'Varredura completa: pode levar mais de 1 hora. Pode usar o PC enquanto isso.'; Start-MpScan -ScanType FullScan }
        'Pasta' {
            if (-not $Caminho -or -not (Test-Path -LiteralPath $Caminho)) { throw "Pasta ou arquivo não encontrado: $Caminho" }
            Start-MpScan -ScanType CustomScan -ScanPath $Caminho
        }
    }
    $recentes = @(Get-MpThreatDetection -ErrorAction SilentlyContinue | Where-Object { $_.InitialDetectionTime -ge (Get-Date).AddHours(-3) })
    Write-EscudoLog "Varredura $Tipo terminou. Detecções nas últimas 3h: $($recentes.Count)"
    if ($recentes.Count -gt 0) {
        Write-Host "Atenção: $($recentes.Count) ameaça(s) detectada(s). Veja em Segurança do Windows > Histórico de proteção." -ForegroundColor Red
    } else {
        Write-Host 'Varredura terminou sem encontrar vírus.' -ForegroundColor Green
    }
    return $recentes.Count
}

function Invoke-EscudoVarreduraOffline {
    <# Reinicia o PC e varre antes do Windows carregar (pega rootkit). Sempre pergunta antes. #>
    param([switch]$Sim)
    Write-Host 'A varredura offline REINICIA o PC agora e leva uns 15 minutos. Salve e feche tudo antes.' -ForegroundColor Yellow
    if (-not $Sim) { if ((Read-Host 'Reiniciar e varrer agora? (S/N)') -notmatch '^(s|sim|y|yes)$') { Write-Host 'Cancelado.'; return } }
    Write-EscudoLog 'Varredura offline solicitada'
    Start-MpWDOScan
}

function Add-EscudoProgramaPermitido {
    <# Libera um programa confiável para mexer nas pastas protegidas contra ransomware. #>
    param([Parameter(Mandatory)][string]$Caminho)
    if (-not (Test-Path -LiteralPath $Caminho)) { throw "Programa não encontrado: $Caminho" }
    $ass = Get-EscudoAssinado $Caminho
    if ($ass -ne $true) { Write-Host 'Atenção: este programa não tem assinatura digital válida. Só libere se tiver certeza de onde ele veio.' -ForegroundColor Yellow }
    Add-MpPreference -ControlledFolderAccessAllowedApplications $Caminho
    Write-EscudoLog "Programa liberado nas pastas protegidas: $Caminho"
    Write-Host "Liberado: $Caminho" -ForegroundColor Green
}

function Invoke-EscudoVigia {
    <# A rotina diária: atualiza vacinas, varredura rápida, diagnóstico com novidades e aviso se algo grave. #>
    try { Update-MpSignature -ErrorAction Stop } catch { Write-EscudoLog "Vigia: falha ao atualizar vacinas: $($_.Exception.Message)" }
    try { Start-MpScan -ScanType QuickScan -ErrorAction Stop } catch { Write-EscudoLog "Vigia: falha na varredura rápida: $($_.Exception.Message)" }
    $r = Invoke-EscudoDiagnostico -ComNovidades -NaoAbrir
    $cfg = Get-EscudoConfig
    if ((Get-EscudoValor $cfg 'vigia_corrige_sozinha') -ne $false -and (Test-EscudoAdmin)) {
        # Tampa sozinha o que é grave (vírus pendente, antivírus desligado, desvio de banco, porta aberta). Tudo com desfazer.
        $plano = @(Get-EscudoPlanoDeCorrecao -Achados @($r.Achados | Where-Object { $_.Nivel -in @('Critico', 'Alto') }) | Where-Object { $_.Tipo -notin @('atualizar-windows', 'varredura', 'instalar-vigia') })
        if ($plano.Count -gt 0) {
            $c = Invoke-EscudoCorrecoes -Plano $plano
            $feitos = @($c.Resultados | Where-Object Ok)
            $antes = $r.Nota
            $r = Invoke-EscudoDiagnostico -NaoAbrir
            if ($feitos.Count -gt 0) {
                Show-EscudoAviso -Titulo "Escudo Infinity Guard corrigiu $($feitos.Count) problema(s)" -Texto ("Nota $antes -> $($r.Nota)/100. " + $feitos[0].Texto + '. Dá para desfazer no menu.') -Tipo 'Warning'
            }
        }
    }
    $graves = @($r.Achados | Where-Object { $_.Nivel -in @('Critico', 'Alto') })
    if ($graves.Count -gt 0) {
        Show-EscudoAviso -Titulo "Escudo Infinity Guard: $($graves.Count) alerta(s)" -Texto ("Nota $($r.Nota)/100. " + $graves[0].Titulo + '. Abra o Escudo > Último relatório.') -Tipo 'Error'
    } elseif (@($r.Achados | Where-Object { $_.Area -eq 'Vigia' }).Count -gt 0) {
        Show-EscudoAviso -Titulo 'Escudo Infinity Guard' -Texto 'Algo novo passou a ligar com o PC. Confira no último relatório.' -Tipo 'Warning'
    }
    return $r
}

# ---------------------------------------------------------------------------
# Correção automática: varre e tampa os buracos encontrados
# Tudo que o Escudo muda fica registrado em backup\correcoes-*.json e pode ser desfeito.
# Arquivo suspeito nunca é apagado: vai para a quarentena do Escudo (movido) ou para a do Defender.
# ---------------------------------------------------------------------------

function Get-EscudoHostsLimpo {
    <# Devolve o arquivo hosts com as linhas que apontam os nomes informados desativadas (comentadas). #>
    param([string[]]$Linhas, [string[]]$Nomes)
    $alvo = @{}
    foreach ($n in @($Nomes)) { if ($n) { $alvo[$n.ToLower()] = $true } }
    $saida = New-Object System.Collections.ArrayList
    foreach ($l in @($Linhas)) {
        $linha = [string]$l
        $t = ($linha -replace '#.*$', '').Trim()
        $partes = @($t -split '\s+' | Where-Object { $_ })
        if ($partes.Count -lt 2) { [void]$saida.Add($linha); continue }
        $nomesLinha = @($partes[1..($partes.Count - 1)])
        $tirar = @($nomesLinha | Where-Object { $alvo.ContainsKey($_.ToLower()) })
        if ($tirar.Count -eq 0) { [void]$saida.Add($linha); continue }
        [void]$saida.Add("# [Escudo desativou] $linha")
        $ficam = @($nomesLinha | Where-Object { -not $alvo.ContainsKey($_.ToLower()) })
        if ($ficam.Count -gt 0) { [void]$saida.Add(($partes[0] + ' ' + ($ficam -join ' '))) }
    }
    return [string[]]$saida
}

function Get-EscudoPlanoDeCorrecao {
    <# Junta os achados que o Escudo sabe corrigir num plano, sem repetir. Não muda nada. #>
    param([object[]]$Achados)
    $plano = New-Object System.Collections.ArrayList
    $vistos = @{}
    foreach ($a in @($Achados)) {
        if (-not $a) { continue }
        $c = Get-EscudoValor $a 'Correcao'
        if (-not $c) { continue }
        $tipo = [string]$c['Tipo']
        $chave = switch ($tipo) {
            'reforco' { 'reforco' }
            'varredura' { 'varredura' }
            'instalar-vigia' { 'instalar-vigia' }
            'remover-ameacas' { 'remover-ameacas' }
            'atualizar-windows' { 'atualizar-windows' }
            'ligar-uac' { 'ligar-uac' }
            default { "$tipo|$($a.Id)" }
        }
        if ($vistos.ContainsKey($chave)) { continue }
        $vistos[$chave] = $true
        $texto = switch ($tipo) {
            'reforco' { 'Ligar as proteções do Windows que estão desligadas (antivírus, nuvem, ransomware, firewall, regras anti-ataque)' }
            'varredura' { 'Atualizar as vacinas e fazer varredura rápida' }
            'instalar-vigia' { 'Instalar a vigia diária (corrige sozinha) e a varredura completa semanal' }
            'remover-exclusao' { "Remover exclusões perigosas do antivírus: $((@($c['Itens']) | ForEach-Object { $_['V'] }) -join ', ')" }
            'limpar-hosts' { "Desativar desvios no arquivo hosts: $(@($c['Nomes']) -join ', ')" }
            'remover-ameacas' { 'Mandar o antivírus remover os vírus pendentes' }
            'restaurar-winlogon' { "Voltar o $($c['Valor']) do login do Windows ao original" }
            'desativar-inicio' { "Tirar da inicialização: $($c['Nome'])" }
            'desativar-tarefa' { "Desativar a tarefa agendada: $($c['Nome'])" }
            'processo' { if ($c['Encerrar']) { "Encerrar o processo suspeito e examinar: $($c['Arquivo'])" } else { "Examinar com o antivírus: $($c['Arquivo'])" } }
            'ligar-uac' { 'Religar o Controle de Conta de Usuário (UAC)' }
            'desligar-rdp' { 'Desligar a Área de Trabalho Remota' }
            'desligar-convidado' { 'Desativar a conta de Convidado' }
            'atualizar-windows' { 'Baixar e instalar as atualizações do Windows' }
            default { $a.Titulo }
        }
        [void]$plano.Add([pscustomobject]@{ Tipo = $tipo; Texto = $texto; Dados = $c; Achado = $a.Id; Nivel = $a.Nivel })
    }
    # Ordem: primeiro o que corta o vírus, depois o que tampa a porta, por último o que demora.
    $ordem = @{ 'processo' = 0; 'remover-ameacas' = 1; 'desativar-inicio' = 2; 'desativar-tarefa' = 2; 'restaurar-winlogon' = 2; 'remover-exclusao' = 3; 'limpar-hosts' = 3; 'reforco' = 4; 'ligar-uac' = 5; 'desligar-convidado' = 5; 'desligar-rdp' = 5; 'varredura' = 6; 'instalar-vigia' = 7; 'atualizar-windows' = 8 }
    return @($plano | Sort-Object @{ Expression = { if ($ordem.ContainsKey($_.Tipo)) { $ordem[$_.Tipo] } else { 9 } } })
}

function Get-EscudoOperacoes {
    <# As mudanças de verdade no Windows. Ficam num lugar só para os testes poderem trocar por simulação. #>
    $hostsArq = Join-Path $env:SystemRoot 'System32\drivers\etc\hosts'
    return @{
        RemoverExclusao   = { param($V, $T) switch ($T) { 'Caminho' { Remove-MpPreference -ExclusionPath $V -ErrorAction Stop } 'Extensao' { Remove-MpPreference -ExclusionExtension $V -ErrorAction Stop } 'Processo' { Remove-MpPreference -ExclusionProcess $V -ErrorAction Stop } } }
        AdicionarExclusao = { param($V, $T) switch ($T) { 'Caminho' { Add-MpPreference -ExclusionPath $V -ErrorAction Stop } 'Extensao' { Add-MpPreference -ExclusionExtension $V -ErrorAction Stop } 'Processo' { Add-MpPreference -ExclusionProcess $V -ErrorAction Stop } } }
        LerHosts          = { @(Get-Content -LiteralPath $hostsArq -ErrorAction Stop) }.GetNewClosure()
        GravarHosts       = {
            param([string[]]$Linhas)
            $f = Get-Item -LiteralPath $hostsArq -Force -ErrorAction Stop
            if ($f.IsReadOnly) { $f.IsReadOnly = $false }
            [System.IO.File]::WriteAllLines($hostsArq, $Linhas, (New-Object System.Text.UTF8Encoding($false)))
        }.GetNewClosure()
        LerValor          = { param($Chave, $Nome) $v = Get-ItemProperty -LiteralPath $Chave -Name $Nome -ErrorAction SilentlyContinue; if ($v) { $v.$Nome } else { $null } }
        GravarValor       = { param($Chave, $Nome, $Valor, $Tipo) if (-not (Test-Path -LiteralPath $Chave)) { New-Item -Path $Chave -Force | Out-Null }; New-ItemProperty -LiteralPath $Chave -Name $Nome -Value $Valor -PropertyType $Tipo -Force -ErrorAction Stop | Out-Null }
        RemoverValor      = { param($Chave, $Nome) Remove-ItemProperty -LiteralPath $Chave -Name $Nome -ErrorAction Stop }
        MoverArquivo      = { param($De, $Para) $d = Split-Path -Parent $Para; if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }; Move-Item -LiteralPath $De -Destination $Para -Force -ErrorAction Stop }
        ExisteArquivo     = { param($Caminho) [bool]($Caminho -and (Test-Path -LiteralPath $Caminho -PathType Leaf -ErrorAction SilentlyContinue)) }
        DesativarTarefa   = { param($Nome) $i = $Nome.LastIndexOf('\'); Disable-ScheduledTask -TaskPath $Nome.Substring(0, $i + 1) -TaskName $Nome.Substring($i + 1) -ErrorAction Stop | Out-Null }
        AtivarTarefa      = { param($Nome) $i = $Nome.LastIndexOf('\'); Enable-ScheduledTask -TaskPath $Nome.Substring(0, $i + 1) -TaskName $Nome.Substring($i + 1) -ErrorAction Stop | Out-Null }
        EncerrarProcesso  = { param($ProcId) Stop-Process -Id $ProcId -Force -ErrorAction Stop }
        VarrerArquivo     = { param($Caminho) Start-MpScan -ScanType CustomScan -ScanPath $Caminho -ErrorAction Stop }
        RemoverAmeacas    = { Remove-MpThreat -ErrorAction Stop }
        AtualizarVacinas  = { Update-MpSignature -ErrorAction Stop }
        VarreduraRapida   = { Start-MpScan -ScanType QuickScan -ErrorAction Stop }
        Convidado         = { param([bool]$Ligar) $g = Get-LocalUser -ErrorAction Stop | Where-Object { $_.SID.Value -like '*-501' }; if ($g) { if ($Ligar) { Enable-LocalUser -SID $g.SID } else { Disable-LocalUser -SID $g.SID } } }
        AtualizarWindows  = {
            $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $esc = Join-Path $script:Raiz 'Escudo.ps1'
            Start-Process -FilePath $ps -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$esc`"", '-Acao', 'AtualizarWindows') -WindowStyle Hidden
        }
        Reforcar          = { Invoke-EscudoReforco -Sim | Out-Null }
        VigiaInstalada    = { [bool](Get-ScheduledTask -TaskPath '\EscudoInfinityGuard\' -ErrorAction SilentlyContinue) }
        InstalarVigia     = { if (Get-ScheduledTask -TaskPath '\EscudoInfinityGuard\' -ErrorAction SilentlyContinue) { 'já estava instalada' } else { Install-Escudo -Sim | Out-Null; 'instalada' } }
    }
}

function Invoke-EscudoCorrecoes {
    <#
      Aplica o plano de correção. Cada passo é independente (um erro não para os outros).
      Devolve { Resultados, Desfazer } e grava o "Desfazer" em backup\correcoes-*.json.
    #>
    [CmdletBinding()]
    param([object[]]$Plano, [hashtable]$Ops, [string]$PastaDados)
    if (-not $Ops) { $Ops = Get-EscudoOperacoes }
    if (-not $PastaDados) { $PastaDados = Get-EscudoPastaDados }
    $carimbo = Get-Date -Format 'yyyy-MM-dd-HHmmss'
    $quarentena = Join-Path (Join-Path $PastaDados 'quarentena') $carimbo
    $desfazer = New-Object System.Collections.ArrayList
    $resultados = New-Object System.Collections.ArrayList
    $runChave = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'

    foreach ($p in @($Plano)) {
        if (-not $p) { continue }
        $c = $p.Dados
        $ok = $true; $erro = $null; $obs = $null
        try {
            switch ($p.Tipo) {
                'reforco' { & $Ops.Reforcar }
                'varredura' { try { & $Ops.AtualizarVacinas } catch { $obs = "vacinas: $($_.Exception.Message)" }; & $Ops.VarreduraRapida }
                'instalar-vigia' { $obs = & $Ops.InstalarVigia }
                'remover-ameacas' { & $Ops.RemoverAmeacas }
                'remover-exclusao' {
                    foreach ($x in @($c['Itens'])) {
                        & $Ops.RemoverExclusao $x['V'] $x['T']
                        [void]$desfazer.Add(@{ Tipo = 'remover-exclusao'; V = $x['V']; T = $x['T'] })
                    }
                }
                'limpar-hosts' {
                    $antes = @(& $Ops.LerHosts)
                    $copia = Join-Path (Join-Path $PastaDados 'backup') "hosts-$carimbo-$($desfazer.Count).txt"
                    [System.IO.File]::WriteAllLines($copia, [string[]]$antes, (New-Object System.Text.UTF8Encoding($false)))
                    & $Ops.GravarHosts (Get-EscudoHostsLimpo -Linhas $antes -Nomes @($c['Nomes']))
                    [void]$desfazer.Add(@{ Tipo = 'limpar-hosts'; Copia = $copia })
                }
                'restaurar-winlogon' {
                    $atual = & $Ops.LerValor $runChave $c['Valor']
                    & $Ops.GravarValor $runChave $c['Valor'] $c['Padrao'] 'String'
                    [void]$desfazer.Add(@{ Tipo = 'valor'; Chave = $runChave; Nome = $c['Valor']; Antes = $atual; TipoValor = 'String' })
                    if ($c['Valor'] -eq 'Userinit' -and $atual) {
                        foreach ($extra in @(([string]$atual -split ',') | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $_ -notmatch '(?i)\\system32\\userinit\.exe$' })) {
                            if (& $Ops.ExisteArquivo $extra) { try { & $Ops.VarrerArquivo $extra } catch { } }
                        }
                    }
                }
                'desativar-inicio' {
                    $origem = [string]$c['Origem']
                    if ($origem -match '^(HKLM|HKCU):') {
                        & $Ops.RemoverValor $origem $c['Nome']
                        [void]$desfazer.Add(@{ Tipo = 'valor'; Chave = $origem; Nome = $c['Nome']; Antes = $c['Comando']; TipoValor = 'String' })
                    } else {
                        $de = $origem.TrimEnd('\') + '\' + $c['Nome']
                        $para = Join-Path $quarentena ('inicializar-' + $c['Nome'])
                        & $Ops.MoverArquivo $de $para
                        [void]$desfazer.Add(@{ Tipo = 'arquivo'; De = $para; Para = $de })
                    }
                    if (& $Ops.ExisteArquivo $c['Arquivo']) { try { & $Ops.VarrerArquivo $c['Arquivo'] } catch { $obs = 'tirado da inicialização; o antivírus não conseguiu examinar o arquivo' } }
                }
                'desativar-tarefa' {
                    & $Ops.DesativarTarefa $c['Nome']
                    [void]$desfazer.Add(@{ Tipo = 'tarefa'; Nome = $c['Nome'] })
                    if (& $Ops.ExisteArquivo $c['Arquivo']) { try { & $Ops.VarrerArquivo $c['Arquivo'] } catch { } }
                }
                'processo' {
                    if ($c['Encerrar']) { try { & $Ops.EncerrarProcesso ([int]$c['Pid']) } catch { $obs = 'o processo já tinha fechado' } }
                    if (& $Ops.ExisteArquivo $c['Arquivo']) { & $Ops.VarrerArquivo $c['Arquivo'] }
                }
                'ligar-uac' {
                    $ch = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
                    foreach ($par in @(@('EnableLUA', 1), @('ConsentPromptBehaviorAdmin', 5))) {
                        $atual = & $Ops.LerValor $ch $par[0]
                        & $Ops.GravarValor $ch $par[0] $par[1] 'DWord'
                        [void]$desfazer.Add(@{ Tipo = 'valor'; Chave = $ch; Nome = $par[0]; Antes = $atual; TipoValor = 'DWord' })
                    }
                    $obs = 'vale depois de reiniciar o PC'
                }
                'desligar-rdp' {
                    $ch = 'HKLM:\System\CurrentControlSet\Control\Terminal Server'
                    $atual = & $Ops.LerValor $ch 'fDenyTSConnections'
                    & $Ops.GravarValor $ch 'fDenyTSConnections' 1 'DWord'
                    [void]$desfazer.Add(@{ Tipo = 'valor'; Chave = $ch; Nome = 'fDenyTSConnections'; Antes = $atual; TipoValor = 'DWord' })
                }
                'desligar-convidado' {
                    & $Ops.Convidado $false
                    [void]$desfazer.Add(@{ Tipo = 'convidado' })
                }
                'atualizar-windows' { & $Ops.AtualizarWindows; $obs = 'baixando e instalando em segundo plano; reinicie quando o Windows pedir' }
                default { $ok = $false; $erro = "não sei corrigir '$($p.Tipo)'" }
            }
        } catch { $ok = $false; $erro = $_.Exception.Message }
        [void]$resultados.Add([pscustomobject]@{ Texto = $p.Texto; Tipo = $p.Tipo; Ok = $ok; Erro = $erro; Obs = $obs })
    }

    $arqDesfazer = $null
    if ($desfazer.Count -gt 0) {
        $arqDesfazer = Join-Path (Join-Path $PastaDados 'backup') "correcoes-$carimbo.json"
        [System.IO.File]::WriteAllText($arqDesfazer, (ConvertTo-Json -InputObject @($desfazer) -Depth 5), (New-Object System.Text.UTF8Encoding($false)))
    }
    Write-EscudoLog ("Correções: " + (($resultados | ForEach-Object { "$($_.Tipo)=$(if ($_.Ok) { 'ok' } else { 'falhou' })" }) -join '; '))
    return [pscustomobject]@{ Resultados = @($resultados); Desfazer = $arqDesfazer }
}

function Undo-EscudoCorrecoes {
    <# Desfaz as correções gravadas num arquivo backup\correcoes-*.json (o mais novo, se não disser qual). #>
    param([string]$Arquivo, [hashtable]$Ops, [string]$PastaDados)
    if (-not $Ops) { $Ops = Get-EscudoOperacoes }
    if (-not $PastaDados) { $PastaDados = Get-EscudoPastaDados }
    if (-not $Arquivo) {
        $u = Get-ChildItem (Join-Path $PastaDados 'backup') -Filter 'correcoes-*.json' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
        if (-not $u) { return 0 }
        $Arquivo = $u.FullName
    }
    $itens = @([System.IO.File]::ReadAllText($Arquivo, [System.Text.Encoding]::UTF8) | ConvertFrom-Json | ForEach-Object { $_ })
    [array]::Reverse($itens)
    $n = 0
    foreach ($d in $itens) {
        try {
            switch ($d.Tipo) {
                'remover-exclusao' { & $Ops.AdicionarExclusao $d.V $d.T }
                'limpar-hosts' { & $Ops.GravarHosts ([System.IO.File]::ReadAllLines($d.Copia)) }
                'valor' { if ($null -eq $d.Antes) { try { & $Ops.RemoverValor $d.Chave $d.Nome } catch { } } else { & $Ops.GravarValor $d.Chave $d.Nome $d.Antes $d.TipoValor } }
                'arquivo' { & $Ops.MoverArquivo $d.De $d.Para }
                'tarefa' { & $Ops.AtivarTarefa $d.Nome }
                'convidado' { & $Ops.Convidado $true }
            }
            $n++
        } catch { Write-EscudoLog "Desfazer correção $($d.Tipo) falhou: $($_.Exception.Message)" }
    }
    Rename-Item -LiteralPath $Arquivo -NewName ((Split-Path -Leaf $Arquivo) -replace '\.json$', '.desfeito.json') -ErrorAction SilentlyContinue
    Write-EscudoLog "Correções desfeitas: $n item(ns) de $Arquivo"
    return $n
}

function Invoke-EscudoCorrigirTudo {
    <#
      Opção principal: varre o PC, mostra o que achou e tampa os buracos sozinho.
      1) lê o PC  2) vacinas + varredura rápida  3) corrige tudo o que dá  4) lê de novo e mostra antes/depois.
      -Sim não pergunta (usado pela vigia diária). -SoGraves corrige só o que é crítico ou alto.
    #>
    param([switch]$Sim, [switch]$NaoAbrir, [switch]$SoGraves)
    if (-not (Test-EscudoAdmin)) { throw 'Corrigir precisa ser rodado como administrador.' }
    $cfg = Get-EscudoConfig
    Write-Host 'Lendo o PC...' -ForegroundColor Cyan
    $antes = Invoke-EscudoDiagnostico -NaoAbrir
    $achados = @($antes.Achados)
    if ($SoGraves) { $achados = @($achados | Where-Object { $_.Nivel -in @('Critico', 'Alto') }) }
    $plano = @(Get-EscudoPlanoDeCorrecao -Achados $achados)
    if (-not ($plano | Where-Object Tipo -eq 'varredura')) { $plano += [pscustomobject]@{ Tipo = 'varredura'; Texto = 'Atualizar as vacinas e fazer varredura rápida'; Dados = @{ Tipo = 'varredura' }; Achado = $null; Nivel = 'Info' } }
    if (-not ($plano | Where-Object Tipo -eq 'instalar-vigia') -and -not (& (Get-EscudoOperacoes).VigiaInstalada)) { $plano += [pscustomobject]@{ Tipo = 'instalar-vigia'; Texto = 'Instalar a vigia diária (corrige sozinha) e a varredura completa semanal'; Dados = @{ Tipo = 'instalar-vigia' }; Achado = $null; Nivel = 'Info' } }
    $manuais = @($antes.Achados | Where-Object { -not $_.Correcao -and $_.Nivel -ne 'Info' })

    Write-Host ''
    Write-Host "Nota agora: $($antes.Nota)/100. O Escudo vai corrigir:" -ForegroundColor Cyan
    foreach ($p in $plano) { Write-Host "  - $($p.Texto)" }
    if ($manuais.Count) {
        Write-Host 'E vai te mostrar como fazer o que o Windows só deixa você mesmo mudar:' -ForegroundColor Gray
        foreach ($m in $manuais) { Write-Host "  - $($m.Titulo)" -ForegroundColor Gray }
    }
    if (-not $Sim) {
        if ((Read-Host 'Corrigir agora? Tudo pode ser desfeito depois. (S/N)') -notmatch '^(s|sim|y|yes)$') { Write-Host 'Nada foi mudado.'; return }
    }

    $r = Invoke-EscudoCorrecoes -Plano $plano
    foreach ($x in $r.Resultados) {
        if ($x.Ok) { Write-Host "  [corrigido] $($x.Texto)$(if ($x.Obs) { " ($($x.Obs))" })" -ForegroundColor Green }
        else { Write-Host "  [não deu] $($x.Texto): $($x.Erro)" -ForegroundColor Yellow }
    }

    Write-Host 'Conferindo de novo...' -ForegroundColor Cyan
    $depois = Invoke-EscudoDiagnostico -NaoAbrir
    $html = ConvertTo-EscudoHtml -Titulo 'Escudo Infinity Guard: varredura e correção' -Subtitulo (Get-Date -Format 'dd/MM/yyyy HH:mm') -Nota $depois.Nota -NotaAntes $antes.Nota -Corrigidos $r.Resultados -Achados $depois.Achados -Resumo @(
        "Antes: $($antes.Nota)/100 · Depois: $($depois.Nota)/100",
        "$(@($r.Resultados | Where-Object Ok).Count) correção(ões) aplicada(s), $(@($r.Resultados | Where-Object { -not $_.Ok }).Count) não deu",
        $(if ($r.Desfazer) { "Para voltar como estava: menu > Desfazer. Registro: $($r.Desfazer)" } else { 'Nenhuma mudança precisou de registro para desfazer.' })
    )
    $arq = Save-EscudoRelatorio -Html $html -Prefixo 'correcao'
    Copy-Item $arq (Join-Path (Split-Path -Parent $arq) 'ultimo-pc.html') -Force
    if (-not $NaoAbrir) { try { Start-Process $arq } catch { } }
    Write-Host ''
    Write-Host "Nota: $($antes.Nota) -> $($depois.Nota)/100. Relatório: $arq" -ForegroundColor Cyan
    $pendentes = @($depois.Achados | Where-Object { $_.Id -like 'ameaca-*' -and $_.Nivel -eq 'Critico' })
    if ($pendentes.Count -gt 0 -and -not $Sim) {
        Write-Host 'Ainda tem vírus que o antivírus não conseguiu tirar com o Windows ligado.' -ForegroundColor Red
        Invoke-EscudoVarreduraOffline
    }
    return [pscustomobject]@{ NotaAntes = $antes.Nota; NotaDepois = $depois.Nota; Resultados = $r.Resultados; Relatorio = $arq; Desfazer = $r.Desfazer; Restantes = $depois.Achados }
}

function Install-EscudoAtualizacoesWindows {
    <# Procura, baixa e instala as atualizações do Windows (as mesmas do Windows Update). Roda em segundo plano. #>
    try {
        $sessao = New-Object -ComObject Microsoft.Update.Session
        $busca = $sessao.CreateUpdateSearcher()
        $res = $busca.Search("IsInstalled=0 and IsHidden=0 and Type='Software'")
        $lista = New-Object -ComObject Microsoft.Update.UpdateColl
        foreach ($u in $res.Updates) { if (-not $u.EulaAccepted) { $u.AcceptEula() }; [void]$lista.Add($u) }
        if ($lista.Count -eq 0) { Write-EscudoLog 'Windows Update: nada pendente'; return 0 }
        $baixa = $sessao.CreateUpdateDownloader(); $baixa.Updates = $lista; [void]$baixa.Download()
        $inst = $sessao.CreateUpdateInstaller(); $inst.Updates = $lista; $fim = $inst.Install()
        Write-EscudoLog "Windows Update: $($lista.Count) atualização(ões), resultado $($fim.ResultCode), reiniciar=$($fim.RebootRequired)"
        if ($fim.RebootRequired) { Show-EscudoAviso -Titulo 'Escudo Infinity Guard' -Texto 'Atualizações do Windows instaladas. Reinicie o PC quando puder para elas valerem.' -Tipo 'Info' }
        return $lista.Count
    } catch {
        Write-EscudoLog "Windows Update falhou: $($_.Exception.Message). Abrindo a tela do Windows Update."
        try { Start-Process 'ms-settings:windowsupdate-action' } catch { }
        return -1
    }
}

# ---------------------------------------------------------------------------
# Instalação (tarefas agendadas)
# ---------------------------------------------------------------------------

function Install-Escudo {
    param([switch]$Sim)
    if (-not (Test-EscudoAdmin)) { throw 'A instalação precisa ser rodada como administrador.' }
    $cfg = Get-EscudoConfig
    $destino = Join-Path $env:ProgramFiles 'EscudoInfinityGuard'
    Write-Host "Instalando em $destino ..." -ForegroundColor Cyan
    if (-not (Test-Path $destino)) { New-Item -ItemType Directory -Path $destino -Force | Out-Null }
    foreach ($item in @('Escudo.ps1', 'Iniciar-Escudo.cmd', 'modulo', 'config', 'android', 'LEIA-ME.md')) {
        $origem = Join-Path $script:Raiz $item
        if (Test-Path $origem) { Copy-Item $origem -Destination $destino -Recurse -Force }
    }
    Get-ChildItem $destino -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
    $dados = Get-EscudoPastaDados

    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $script = Join-Path $destino 'Escudo.ps1'
    $config = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 4)

    # 1) Vigia diária + 5 min depois de entrar no Windows (roda como você, para poder avisar na tela)
    $acaoVigia = New-ScheduledTaskAction -Execute $ps -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$script`" -Acao Vigiar"
    $gatilhos = @(
        (New-ScheduledTaskTrigger -Daily -At $cfg.vigia_horario),
        (New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME")
    )
    $gatilhos[1].Delay = 'PT5M'
    $quem = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Highest
    Register-ScheduledTask -TaskName 'Escudo Infinity Guard - Vigia' -TaskPath '\EscudoInfinityGuard\' -Action $acaoVigia -Trigger $gatilhos -Principal $quem -Settings $config -Description 'Atualiza vacinas, varredura rápida, procura invasão e avisa se algo estiver errado.' -Force | Out-Null

    # 2) Varredura completa semanal (roda como SYSTEM, mesmo sem ninguém logado)
    $acaoCompleta = New-ScheduledTaskAction -Execute $ps -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$script`" -Acao Varrer -Tipo Completa"
    $gatilhoSemanal = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $cfg.varredura_completa_dia -At $cfg.varredura_completa_horario
    $sistema = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    Register-ScheduledTask -TaskName 'Escudo Infinity Guard - Varredura completa' -TaskPath '\EscudoInfinityGuard\' -Action $acaoCompleta -Trigger $gatilhoSemanal -Principal $sistema -Settings $config -Description 'Varredura completa semanal com o Microsoft Defender.' -Force | Out-Null

    # 3) Atalhos no Menu Iniciar
    try {
        $menu = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'Escudo Infinity Guard'
        if (-not (Test-Path $menu)) { New-Item -ItemType Directory -Path $menu -Force | Out-Null }
        $sh = New-Object -ComObject WScript.Shell
        $l1 = $sh.CreateShortcut((Join-Path $menu 'Escudo Infinity Guard.lnk'))
        $l1.TargetPath = Join-Path $destino 'Iniciar-Escudo.cmd'
        $l1.WorkingDirectory = $destino
        $l1.IconLocation = "$env:SystemRoot\System32\SecurityHealthAgent.dll,0"
        $l1.Save()
        $l2 = $sh.CreateShortcut((Join-Path $menu 'Último relatório do PC.lnk'))
        $l2.TargetPath = Join-Path (Join-Path $dados 'relatorios') 'ultimo-pc.html'
        $l2.Save()
    } catch { Write-Host "Não consegui criar atalhos no Menu Iniciar: $($_.Exception.Message)" -ForegroundColor Yellow }

    Write-EscudoLog "Instalado em $destino"
    Write-Host 'Fazendo a primeira verificação (cria a linha de base da vigia)...'
    try { $r = Invoke-EscudoDiagnostico -ComNovidades -NaoAbrir; Write-Host "Nota do PC hoje: $($r.Nota)/100" -ForegroundColor Cyan } catch { Write-Host "A primeira verificação falhou: $($_.Exception.Message)" -ForegroundColor Yellow }
    Write-Host ''
    Write-Host 'Instalado! A partir de agora:' -ForegroundColor Green
    Write-Host "  - Todo dia às $($cfg.vigia_horario) (e 5 min depois de ligar o PC): vacinas, varredura rápida e vigia de invasão."
    Write-Host "  - Toda semana ($($cfg.varredura_completa_dia) $($cfg.varredura_completa_horario)): varredura completa. Se o PC estiver desligado, roda quando ligar."
    Write-Host '  - Menu Iniciar > Escudo Infinity Guard: abre o painel e o último relatório.'
    Write-Host ''
    Write-Host 'Recomendado agora: opção 1 do menu (Varrer e corrigir tudo).' -ForegroundColor Cyan
}

function Uninstall-Escudo {
    param([switch]$Sim)
    if (-not (Test-EscudoAdmin)) { throw 'Desinstalar precisa ser rodado como administrador.' }
    if (-not $Sim) { if ((Read-Host 'Remover as tarefas e o programa do Escudo? As configurações do Defender continuam como estão. (S/N)') -notmatch '^(s|sim|y|yes)$') { return } }
    Get-ScheduledTask -TaskPath '\EscudoInfinityGuard\' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false
    $menu = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'Escudo Infinity Guard'
    if (Test-Path $menu) { Remove-Item $menu -Recurse -Force }
    $destino = Join-Path $env:ProgramFiles 'EscudoInfinityGuard'
    if ((Test-Path $destino) -and ($script:Raiz -ne $destino)) { Remove-Item $destino -Recurse -Force }
    Write-EscudoLog 'Desinstalado'
    Write-Host 'Escudo removido. Relatórios e backups ficaram em C:\ProgramData\EscudoInfinityGuard (pode apagar se quiser).' -ForegroundColor Green
    Write-Host 'Para voltar as configurações do Defender ao que eram, rode "Desfazer reforço" ANTES de desinstalar.'
}

# ---------------------------------------------------------------------------
# Android (pelo cabo USB, com o ADB oficial do Google)
# ---------------------------------------------------------------------------

function ConvertFrom-EscudoAdbPacotes {
    <# Lê a saída de "pm list packages -3 -i" -> lista de {Pacote, Instalador}. #>
    param([string[]]$Linhas)
    $saida = @()
    foreach ($l in @($Linhas)) {
        $m = [regex]::Match([string]$l, '^package:(\S+)(?:\s+installer=(\S+))?')
        if ($m.Success) {
            $inst = $m.Groups[2].Value
            if (-not $inst -or $inst -eq 'null') { $inst = $null }
            $saida += [pscustomobject]@{ Pacote = $m.Groups[1].Value; Instalador = $inst }
        }
    }
    return $saida
}

function ConvertFrom-EscudoAdbServicos {
    <# "com.a/.Servico:com.b/com.b.X" -> pacotes. #>
    param([string]$Texto)
    if (-not $Texto -or $Texto.Trim() -eq 'null') { return @() }
    return @($Texto.Trim() -split ':' | Where-Object { $_ } | ForEach-Object { ($_ -split '/')[0] } | Select-Object -Unique)
}

function ConvertFrom-EscudoAdbAdmins {
    <# Pacotes com poder de "administrador do dispositivo" (saída do dumpsys device_policy). #>
    param([string[]]$Linhas)
    $saida = @()
    foreach ($l in @($Linhas)) {
        foreach ($m in [regex]::Matches([string]$l, 'ComponentInfo\{([^/}]+)/')) { $saida += $m.Groups[1].Value }
    }
    return @($saida | Select-Object -Unique)
}

function Get-EscudoAndroidAchados {
    <#
      Recebe o que foi lido do celular e devolve os problemas.
      $Dados: Modelo, Versao, Patch (yyyy-MM-dd), Pacotes, Acessibilidade, Notificacoes,
              Admins, PodemInstalar, PlayProtect ('0'/'1'/null), Root (bool), TelaSemBloqueio (bool), DevAtivo
    #>
    param([Parameter(Mandatory)]$Dados, [string[]]$LojasConfiaveis, [datetime]$Hoje = (Get-Date))
    $A = New-Object System.Collections.ArrayList
    $lojas = @($LojasConfiaveis)
    $pacotes = @(Get-EscudoValor $Dados 'Pacotes')
    $porPacote = @{}
    foreach ($p in $pacotes) { $porPacote[$p.Pacote] = $p }
    $foraDaLoja = { param($nome) $p = $porPacote[$nome]; return ($p -and -not ($p.Instalador -and ($lojas -contains $p.Instalador))) }

    $patch = Get-EscudoValor $Dados 'Patch'
    if ($patch) {
        try {
            $dias = [int]($Hoje - [datetime]::ParseExact($patch, 'yyyy-MM-dd', $null)).TotalDays
            if ($dias -gt 180) {
                [void]$A.Add((New-EscudoAchado -Id 'and-patch' -Area 'Atualizações' -Nivel 'Alto' -Titulo "Celular sem atualização de segurança há $dias dias" -Detalhe "Último patch: $patch." -OQueFazer 'O Escudo abre a tela de atualização no celular. Se o fabricante não manda mais atualização, o celular já não é seguro para banco e Pix.' -Correcao @{ Tipo = 'and-abrir'; Tela = 'android.settings.SYSTEM_UPDATE_SETTINGS' }))
            } elseif ($dias -gt 90) {
                [void]$A.Add((New-EscudoAchado -Id 'and-patch' -Area 'Atualizações' -Nivel 'Medio' -Titulo "Atualização de segurança de $patch ($dias dias)" -OQueFazer 'Configurações > Sistema > Atualização de software.'))
            }
        } catch { }
    }
    $versao = Get-EscudoValor $Dados 'Versao'
    if ($versao -and ([int](([string]$versao -split '\.')[0])) -lt 12) {
        [void]$A.Add((New-EscudoAchado -Id 'and-versao' -Area 'Atualizações' -Nivel 'Medio' -Titulo "Android $versao (antigo)" -Detalhe 'Versões abaixo do 12 já não recebem a maior parte das correções.' -OQueFazer 'Atualize se houver; se não houver, evite usar banco neste aparelho.'))
    }
    if ([string](Get-EscudoValor $Dados 'PlayProtect') -eq '0') {
        [void]$A.Add((New-EscudoAchado -Id 'and-playprotect' -Area 'Antivírus' -Nivel 'Alto' -Titulo 'Google Play Protect (verificação de apps) desligado' -OQueFazer 'O Escudo religa a verificação de apps. Confira depois em Play Store > foto do perfil > Play Protect.' -Correcao @{ Tipo = 'and-playprotect' }))
    }
    if ((Get-EscudoValor $Dados 'Root') -eq $true) {
        [void]$A.Add((New-EscudoAchado -Id 'and-root' -Area 'Anti-hacker' -Nivel 'Alto' -Titulo 'Celular com root' -Detalhe 'Com root, um app malicioso consegue controle total.' -OQueFazer 'Se não foi você que fez o root de propósito, leve a uma assistência e restaure o sistema de fábrica.'))
    }
    if ((Get-EscudoValor $Dados 'TelaSemBloqueio') -eq $true) {
        [void]$A.Add((New-EscudoAchado -Id 'and-bloqueio' -Area 'Privacidade' -Nivel 'Alto' -Titulo 'Celular sem senha de tela' -OQueFazer 'O Escudo abre a tela de bloqueio no celular: escolha PIN de 6 dígitos ou senha, mais digital/rosto.' -Correcao @{ Tipo = 'and-abrir'; Tela = 'android.app.action.SET_NEW_PASSWORD' }))
    }

    foreach ($pac in @(Get-EscudoValor $Dados 'Acessibilidade')) {
        if (& $foraDaLoja $pac) {
            [void]$A.Add((New-EscudoAchado -Id "and-acess-$pac" -Area 'Golpe' -Nivel 'Critico' -Titulo "App de fora da loja controlando a tela (acessibilidade): $pac" -Detalhe 'É assim que os golpes de Pix e de banco no Brasil funcionam: o app lê a tela e digita por você.' -OQueFazer 'O Escudo desliga a acessibilidade desse app e desativa o app no celular (dá para desfazer). Depois troque a senha do banco por outro aparelho.' -Correcao @{ Tipo = 'and-acess'; Pacote = $pac }))
        } elseif ($pac -notmatch '^com\.(google|android|samsung|sec)\.') {
            [void]$A.Add((New-EscudoAchado -Id "and-acess-$pac" -Area 'Golpe' -Nivel 'Medio' -Titulo "App com acesso de acessibilidade: $pac" -OQueFazer 'Acessibilidade deixa o app ler e tocar na tela. Se não reconhece, desligue em Configurações > Acessibilidade.'))
        }
    }
    foreach ($pac in @(Get-EscudoValor $Dados 'Admins')) {
        if ($pac -match '^com\.google\.android\.(gms|apps\.work)') { continue }
        $fora = & $foraDaLoja $pac
        $nivel = if ($fora) { 'Critico' } else { 'Medio' }
        [void]$A.Add((New-EscudoAchado -Id "and-admin-$pac" -Area 'Golpe' -Nivel $nivel -Titulo "App com poder de administrador do celular: $pac" -Detalhe 'Administrador consegue travar a tela e impedir a própria desinstalação.' -OQueFazer $(if ($fora) { 'O Escudo tenta desativar o app. Se o celular não deixar, ele abre a tela de administradores para você desmarcar.' } else { 'Configurações > Segurança > Apps de administração do dispositivo: desmarque o que não reconhece.' }) -Correcao $(if ($fora) { @{ Tipo = 'and-admin'; Pacote = $pac } } else { $null })))
    }
    foreach ($pac in @(Get-EscudoValor $Dados 'Notificacoes')) {
        if (& $foraDaLoja $pac) {
            [void]$A.Add((New-EscudoAchado -Id "and-notif-$pac" -Area 'Golpe' -Nivel 'Alto' -Titulo "App de fora da loja lendo suas notificações: $pac" -Detalhe 'Ele consegue ler códigos de verificação por SMS e do banco.' -OQueFazer 'O Escudo corta o acesso às notificações e desativa o app (dá para desfazer).' -Correcao @{ Tipo = 'and-notif'; Pacote = $pac }))
        }
    }
    foreach ($pac in @(Get-EscudoValor $Dados 'PodemInstalar')) {
        if ($pac -match '^com\.(android\.vending|google\.android\.packageinstaller|android\.packageinstaller)$') { continue }
        [void]$A.Add((New-EscudoAchado -Id "and-instala-$pac" -Area 'Golpe' -Nivel 'Medio' -Titulo "App autorizado a instalar outros apps: $pac" -Detalhe 'Golpes chegam por aqui: o navegador ou o WhatsApp baixa um APK e instala.' -OQueFazer 'O Escudo tira essa permissão (fica "Não permitido").' -Correcao @{ Tipo = 'and-instala'; Pacote = $pac }))
    }
    $fora = @($pacotes | Where-Object { -not ($_.Instalador -and ($lojas -contains $_.Instalador)) })
    if ($fora.Count -gt 0) {
        [void]$A.Add((New-EscudoAchado -Id 'and-fora-da-loja' -Area 'Golpe' -Nivel 'Medio' -Titulo "$($fora.Count) app(s) instalados por fora da loja oficial" -Detalhe (($fora | ForEach-Object Pacote) -join ', ') -OQueFazer 'Confira se reconhece cada um. App baixado por link de WhatsApp ou SMS é o golpe mais comum.'))
    }
    if ([string](Get-EscudoValor $Dados 'DevAtivo') -eq '1') {
        [void]$A.Add((New-EscudoAchado -Id 'and-dev' -Area 'Anti-hacker' -Nivel 'Info' -Titulo 'Opções do desenvolvedor ligadas (necessário para esta checagem)' -OQueFazer 'O Escudo desliga a Depuração USB no fim da checagem.'))
    }
    return @($A | Sort-Object @{ Expression = { Get-EscudoOrdem $_.Nivel } }, Titulo)
}

function Remove-EscudoDaListaAndroid {
    <# Tira os pacotes de uma lista "pkg/.Servico:pkg2/x.Y" do Android. Devolve 'null' se ficar vazia. #>
    param([string]$Texto, [string[]]$Pacotes)
    if (-not $Texto -or $Texto.Trim() -eq 'null') { return 'null' }
    $fica = @($Texto.Trim() -split ':' | Where-Object { $_ -and (($_ -split '/')[0] -notin @($Pacotes)) })
    if ($fica.Count -eq 0) { return 'null' }
    return ($fica -join ':')
}

function Invoke-EscudoAndroidCorrecoes {
    <#
      Corrige o celular pelo cabo (ADB): desliga acessibilidade e leitura de notificações de app de golpe,
      desativa o app (pm disable-user, volta com pm enable), tira permissão de instalar apps, religa o Play Protect.
      Não desinstala nada sem perguntar. Devolve { Resultados, Desfazer }.
    #>
    param([object[]]$Achados, [scriptblock]$Shell, [string]$PastaDados, [scriptblock]$Perguntar)
    if (-not $PastaDados) { $PastaDados = Get-EscudoPastaDados }
    $res = New-Object System.Collections.ArrayList
    $desfazer = New-Object System.Collections.ArrayList
    $desativados = @{}
    $txt = { param($c) ((& $Shell $c) -join '').Trim() }
    $desativar = {
        param($pac)
        if ($desativados.ContainsKey($pac)) { return }
        $saida = & $txt "pm disable-user --user 0 $pac"
        if ($saida -notmatch '(?i)new state:\s*disabled') { throw "o celular não deixou desativar ($saida)" }
        $desativados[$pac] = $true
        [void]$desfazer.Add(@{ Tipo = 'cmd'; Cmd = "pm enable --user 0 $pac" })
    }
    foreach ($a in @($Achados)) {
        $c = Get-EscudoValor $a 'Correcao'
        if (-not $c) { continue }
        $texto = $a.Titulo; $ok = $true; $erro = $null; $obs = $null
        try {
            switch ([string]$c['Tipo']) {
                'and-acess' {
                    $antes = & $txt 'settings get secure enabled_accessibility_services'
                    & $Shell ("settings put secure enabled_accessibility_services '" + (Remove-EscudoDaListaAndroid -Texto $antes -Pacotes @($c['Pacote'])) + "'") | Out-Null
                    [void]$desfazer.Add(@{ Tipo = 'cmd'; Cmd = "settings put secure enabled_accessibility_services '$antes'" })
                    & $desativar $c['Pacote']
                    $texto = "Acessibilidade cortada e app desativado: $($c['Pacote'])"
                }
                'and-notif' {
                    $antes = & $txt 'settings get secure enabled_notification_listeners'
                    & $Shell ("settings put secure enabled_notification_listeners '" + (Remove-EscudoDaListaAndroid -Texto $antes -Pacotes @($c['Pacote'])) + "'") | Out-Null
                    [void]$desfazer.Add(@{ Tipo = 'cmd'; Cmd = "settings put secure enabled_notification_listeners '$antes'" })
                    & $desativar $c['Pacote']
                    $texto = "Leitura de notificações cortada e app desativado: $($c['Pacote'])"
                }
                'and-admin' {
                    try { & $desativar $c['Pacote']; $texto = "App administrador desativado: $($c['Pacote'])" }
                    catch {
                        & $Shell 'am start -a android.settings.SECURITY_SETTINGS' | Out-Null
                        throw 'o celular protege apps administradores; abri a tela de Segurança: entre em "Apps de administração do dispositivo" e desmarque'
                    }
                }
                'and-instala' {
                    & $Shell "appops set $($c['Pacote']) REQUEST_INSTALL_PACKAGES deny" | Out-Null
                    [void]$desfazer.Add(@{ Tipo = 'cmd'; Cmd = "appops set $($c['Pacote']) REQUEST_INSTALL_PACKAGES default" })
                    $texto = "Sem permissão para instalar apps: $($c['Pacote'])"
                }
                'and-playprotect' {
                    & $Shell 'settings put global package_verifier_enable 1' | Out-Null
                    & $Shell 'settings put global verifier_verify_adb_installs 1' | Out-Null
                    if ((& $txt 'settings get global package_verifier_enable') -ne '1') { throw 'o celular não aceitou; ligue em Play Store > Play Protect' }
                    $texto = 'Play Protect (verificação de apps) religado'
                }
                'and-abrir' {
                    & $Shell "am start -a $($c['Tela'])" | Out-Null
                    $texto = "$($a.Titulo): abri a tela certa no celular"
                    $obs = 'termine no celular'
                }
                default { $texto = $null }
            }
        } catch { $ok = $false; $erro = $_.Exception.Message }
        if ($null -eq $texto) { continue }
        [void]$res.Add([pscustomobject]@{ Texto = $texto; Tipo = [string]$c['Tipo']; Ok = $ok; Erro = $erro; Obs = $obs })
    }
    # Apps de golpe: desinstalar só com o "sim" da pessoa (apaga os dados do app)
    if ($Perguntar) {
        foreach ($pac in @($desativados.Keys)) {
            if (& $Perguntar "Desinstalar de vez o app $pac do celular? (S/N)") {
                $saida = & $txt "pm uninstall --user 0 $pac"
                [void]$res.Add([pscustomobject]@{ Texto = "Desinstalado: $pac"; Tipo = 'and-desinstalar'; Ok = ($saida -match '(?i)success'); Erro = $(if ($saida -notmatch '(?i)success') { $saida } else { $null }); Obs = $null })
            }
        }
    }
    $arq = $null
    if ($desfazer.Count) {
        $arq = Join-Path (Join-Path $PastaDados 'backup') ('android-correcoes-{0}.json' -f (Get-Date -Format 'yyyy-MM-dd-HHmmss'))
        [System.IO.File]::WriteAllText($arq, (ConvertTo-Json -InputObject @($desfazer) -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
    }
    return [pscustomobject]@{ Resultados = @($res); Desfazer = $arq }
}

function Get-EscudoAdb {
    $cmd = Get-Command adb -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $local = Join-Path (Join-Path (Get-EscudoPastaDados) 'platform-tools') 'adb.exe'
    if (Test-Path $local) { return $local }
    Write-Host 'Para conversar com o celular, o Escudo usa o ADB oficial do Google (platform-tools).' -ForegroundColor Cyan
    $r = Read-Host 'Baixar agora de dl.google.com (uns 7 MB)? (S/N)'
    if ($r -notmatch '^(s|sim|y|yes)$') { throw 'Sem o ADB não dá para checar o celular.' }
    $zip = Join-Path ([System.IO.Path]::GetTempPath()) 'platform-tools.zip'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile $zip -UseBasicParsing
    Expand-Archive -Path $zip -DestinationPath (Get-EscudoPastaDados) -Force
    Remove-Item $zip -Force
    if (-not (Test-Path $local)) { throw 'O download não trouxe o adb.exe.' }
    $assAdb = Get-EscudoAssinado $local
    if ($assAdb -ne $true) { Write-Host 'Aviso: não consegui confirmar a assinatura do adb.exe.' -ForegroundColor Yellow }
    return $local
}

function Invoke-EscudoAndroid {
    $cfg = Get-EscudoConfig
    $adb = Get-EscudoAdb
    Write-Host ''
    Write-Host 'No celular: Configurações > Sobre o telefone > toque 7x em "Número da versão".' -ForegroundColor Cyan
    Write-Host 'Depois: Configurações > Sistema > Opções do desenvolvedor > ligue "Depuração USB".'
    Write-Host 'Ligue o cabo e aceite o aviso "Permitir depuração USB" no celular.'
    Read-Host 'Aperte ENTER quando estiver pronto'
    $dev = @(& $adb devices | Select-String '\tdevice$')
    if ($dev.Count -eq 0) { throw 'Não encontrei o celular. Confira o cabo (tem que ser de dados) e se aceitou o aviso no celular.' }
    $sh = { param([string]$c) @(& $adb shell $c 2>$null) }
    $dados = [pscustomobject]@{
        Modelo          = ((& $sh 'getprop ro.product.manufacturer') -join '') + ' ' + ((& $sh 'getprop ro.product.model') -join '')
        Versao          = ((& $sh 'getprop ro.build.version.release') -join '').Trim()
        Patch           = ((& $sh 'getprop ro.build.version.security_patch') -join '').Trim()
        Pacotes         = @(ConvertFrom-EscudoAdbPacotes (& $sh 'pm list packages -3 -i'))
        Acessibilidade  = @(ConvertFrom-EscudoAdbServicos ((& $sh 'settings get secure enabled_accessibility_services') -join ''))
        Notificacoes    = @(ConvertFrom-EscudoAdbServicos ((& $sh 'settings get secure enabled_notification_listeners') -join ''))
        Admins          = @(ConvertFrom-EscudoAdbAdmins (& $sh 'dumpsys device_policy'))
        PodemInstalar   = @((& $sh 'appops query-op REQUEST_INSTALL_PACKAGES allow') | Where-Object { $_ -match '^\S+$' })
        PlayProtect     = ((& $sh 'settings get global package_verifier_enable') -join '').Trim()
        Root            = [bool](((& $sh 'which su') -join '').Trim())
        TelaSemBloqueio = (((& $sh 'locksettings get-disabled') -join '').Trim() -eq 'true')
        DevAtivo        = ((& $sh 'settings get global development_settings_enabled') -join '').Trim()
    }
    $achados = @(Get-EscudoAndroidAchados -Dados $dados -LojasConfiaveis $cfg.lojas_android_confiaveis)
    $notaAntes = Get-EscudoNota $achados
    $corrigiveis = @($achados | Where-Object { $_.Correcao })
    $feitos = @()
    $arqDesfazer = $null
    if ($corrigiveis.Count) {
        Write-Host "Nota do celular: $notaAntes/100. O Escudo vai corrigir:" -ForegroundColor Cyan
        foreach ($a in $corrigiveis) { Write-Host "  - $($a.Titulo)" }
        if ((Read-Host 'Corrigir agora? Dá para desfazer. (S/N)') -match '^(s|sim|y|yes)$') {
            $r = Invoke-EscudoAndroidCorrecoes -Achados $corrigiveis -Shell $sh -Perguntar { param($q) (Read-Host $q) -match '^(s|sim|y|yes)$' }
            $feitos = $r.Resultados; $arqDesfazer = $r.Desfazer
            foreach ($x in $feitos) { if ($x.Ok) { Write-Host "  [corrigido] $($x.Texto)" -ForegroundColor Green } else { Write-Host "  [não deu] $($x.Texto): $($x.Erro)" -ForegroundColor Yellow } }
            # Lê de novo para mostrar o depois
            $dados.Acessibilidade = @(ConvertFrom-EscudoAdbServicos ((& $sh 'settings get secure enabled_accessibility_services') -join ''))
            $dados.Notificacoes = @(ConvertFrom-EscudoAdbServicos ((& $sh 'settings get secure enabled_notification_listeners') -join ''))
            $dados.Admins = @(ConvertFrom-EscudoAdbAdmins (& $sh 'dumpsys device_policy'))
            $dados.PodemInstalar = @((& $sh 'appops query-op REQUEST_INSTALL_PACKAGES allow') | Where-Object { $_ -match '^\S+$' })
            $dados.PlayProtect = ((& $sh 'settings get global package_verifier_enable') -join '').Trim()
            $dados.Pacotes = @(ConvertFrom-EscudoAdbPacotes (& $sh 'pm list packages -3 -i -e'))
            $achados = @(Get-EscudoAndroidAchados -Dados $dados -LojasConfiaveis $cfg.lojas_android_confiaveis)
        }
    }
    $nota = Get-EscudoNota $achados
    $resumo = @("Aparelho: $($dados.Modelo) · Android $($dados.Versao) · patch $($dados.Patch)", "$(@($dados.Pacotes).Count) apps ativos instalados por você", $(if ($arqDesfazer) { "Para desfazer: .\Escudo.ps1 -Acao AndroidDesfazer (registro em $arqDesfazer)" } else { 'Nada foi mudado no celular.' }))
    $html = ConvertTo-EscudoHtml -Titulo 'Escudo Infinity Guard: celular Android' -Subtitulo (Get-Date -Format 'dd/MM/yyyy HH:mm') -Nota $nota -NotaAntes $notaAntes -Corrigidos $feitos -Achados $achados -Resumo $resumo
    $arq = Save-EscudoRelatorio -Html $html -Prefixo 'android'
    Write-EscudoLog "Android $($dados.Modelo): nota $nota"
    try { Start-Process $arq } catch { }
    Write-Host "Relatório: $arq"
    if ((Read-Host 'Desligar a Depuração USB do celular agora? Recomendado. (S/N)') -match '^(s|sim|y|yes)$') {
        & $sh 'settings put global adb_enabled 0' | Out-Null
        Write-Host 'Depuração USB desligada. Pode tirar o cabo.' -ForegroundColor Green
    } else { Write-Host 'Lembre de desligar a Depuração USB no celular quando terminar.' -ForegroundColor Cyan }
    return [pscustomobject]@{ Nota = $nota; Achados = $achados; Relatorio = $arq }
}

function Undo-EscudoAndroid {
    <# Desfaz as últimas correções feitas no celular (precisa do cabo e da Depuração USB ligada). #>
    param([string]$Arquivo)
    $adb = Get-EscudoAdb
    if (-not $Arquivo) {
        $u = Get-ChildItem (Join-Path (Get-EscudoPastaDados) 'backup') -Filter 'android-correcoes-*.json' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
        if (-not $u) { Write-Host 'Nada para desfazer no celular.'; return }
        $Arquivo = $u.FullName
    }
    $itens = @([System.IO.File]::ReadAllText($Arquivo, [System.Text.Encoding]::UTF8) | ConvertFrom-Json | ForEach-Object { $_ })
    [array]::Reverse($itens)
    foreach ($d in $itens) { & $adb shell $d.Cmd | Out-Null }
    Rename-Item -LiteralPath $Arquivo -NewName ((Split-Path -Leaf $Arquivo) -replace '\.json$', '.desfeito.json') -ErrorAction SilentlyContinue
    Write-Host "Desfeito no celular: $($itens.Count) mudança(s)." -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# Site (checagem de fora, como um visitante veria)
# ---------------------------------------------------------------------------

function Get-EscudoPhpStatus {
    <# Diz se a versão do PHP ainda recebe correção de segurança. #>
    param([string]$Versao, [string]$Minimo = '8.2', [string[]]$FimProximo = @('8.2'))
    $m = [regex]::Match([string]$Versao, '(\d+)\.(\d+)(?:\.(\d+))?')
    if (-not $m.Success) { return 'desconhecida' }
    $ramo = "$($m.Groups[1].Value).$($m.Groups[2].Value)"
    if ([version]"$ramo" -lt [version]$Minimo) { return 'sem-suporte' }
    if ($FimProximo -contains $ramo) { return 'fim-proximo' }
    return 'suportada'
}

function Get-EscudoSiteAchados {
    <#
      $Coleta: Url, Https (bool), CertErro, CertDias, RedirecionaHttps (bool/$null),
               Cabecalhos (hashtable nome->valor, minúsculo), Cookies (string[]), Html (string),
               Expostos (string[]), Plataforma (string)
    #>
    param([Parameter(Mandatory)]$Coleta, [string]$PhpMinimo = '8.2', [string[]]$PhpFimProximo = @('8.2'))
    $A = New-Object System.Collections.ArrayList
    $h = Get-EscudoValor $Coleta 'Cabecalhos'
    if (-not $h) { $h = @{} }
    $plat = Get-EscudoValor $Coleta 'Plataforma'
    $quem = if ($plat) { " (no seu caso, quem ajusta isso é a $plat)" } else { '' }

    if ((Get-EscudoValor $Coleta 'Inalcancavel') -eq $true) {
        [void]$A.Add((New-EscudoAchado -Id 'site-inalcancavel' -Area 'Site' -Nivel 'Alto' -Titulo 'Não consegui acessar o site' -Detalhe ([string](Get-EscudoValor $Coleta 'CertErro')) -OQueFazer 'Confira se o site está no ar e se a internet deste PC está funcionando, e rode de novo. Nenhuma outra checagem foi feita.'))
        return @($A)
    }
    if ((Get-EscudoValor $Coleta 'Https') -ne $true) {
        [void]$A.Add((New-EscudoAchado -Id 'site-https' -Area 'Site' -Nivel 'Critico' -Titulo 'Site sem HTTPS (cadeado)' -Detalhe 'Senhas e dados de cartão viajam abertos.' -OQueFazer 'Ative o certificado gratuito (Let''s Encrypt) na hospedagem.'))
    }
    $certErro = Get-EscudoValor $Coleta 'CertErro'
    if ($certErro) {
        [void]$A.Add((New-EscudoAchado -Id 'site-cert-invalido' -Area 'Site' -Nivel 'Critico' -Titulo 'Certificado do site com problema' -Detalhe $certErro -OQueFazer 'O navegador mostra aviso de "site não seguro". Renove o certificado na hospedagem.'))
    }
    $dias = Get-EscudoValor $Coleta 'CertDias'
    if ($null -ne $dias -and [int]$dias -lt 15) {
        [void]$A.Add((New-EscudoAchado -Id 'site-cert-vencendo' -Area 'Site' -Nivel 'Alto' -Titulo "Certificado vence em $dias dia(s)" -OQueFazer 'Confira se a renovação automática está ligada na hospedagem.'))
    }
    if ((Get-EscudoValor $Coleta 'RedirecionaHttps') -eq $false) {
        [void]$A.Add((New-EscudoAchado -Id 'site-redireciona' -Area 'Site' -Nivel 'Medio' -Titulo 'Endereço com http:// não leva para https://' -OQueFazer "Force o redirecionamento para HTTPS$quem."))
    }

    if ((Get-EscudoValor $Coleta 'Https') -ne $true) {
        # Sem página HTTPS não há cabeçalhos confiáveis para avaliar; os arquivos expostos ainda contam.
        foreach ($e in @(Get-EscudoValor $Coleta 'Expostos')) {
            if ($e) { [void]$A.Add((New-EscudoAchado -Id "site-exposto-$e" -Area 'Invasão' -Nivel 'Critico' -Titulo "Arquivo secreto aberto para qualquer um: $e" -OQueFazer 'Apague ou bloqueie esse arquivo HOJE e troque as senhas que estavam nele.')) }
        }
        return @($A | Sort-Object @{ Expression = { Get-EscudoOrdem $_.Nivel } }, Titulo)
    }
    $pw = [string]$h['x-powered-by']
    $server = [string]$h['server']
    $phpVer = $null
    foreach ($t in @($pw, $server)) { $m = [regex]::Match($t, '(?i)PHP/(\d+\.\d+(?:\.\d+)?)'); if ($m.Success) { $phpVer = $m.Groups[1].Value; break } }
    if ($phpVer) {
        $st = Get-EscudoPhpStatus -Versao $phpVer -Minimo $PhpMinimo -FimProximo $PhpFimProximo
        if ($st -eq 'sem-suporte') {
            [void]$A.Add((New-EscudoAchado -Id 'site-php-velho' -Area 'PHP' -Nivel 'Critico' -Titulo "PHP $phpVer sem correção de segurança" -Detalhe 'Esta versão não recebe mais correção. Falhas conhecidas ficam abertas para sempre.' -OQueFazer "Atualize o PHP para $PhpMinimo ou mais novo no painel da hospedagem (teste o site antes numa cópia)."))
        } elseif ($st -eq 'fim-proximo') {
            [void]$A.Add((New-EscudoAchado -Id 'site-php-fim' -Area 'PHP' -Nivel 'Medio' -Titulo "PHP $phpVer perto do fim do suporte" -OQueFazer 'Planeje a atualização para a versão mais nova suportada.'))
        }
        [void]$A.Add((New-EscudoAchado -Id 'site-php-exposto' -Area 'PHP' -Nivel 'Medio' -Titulo 'O site conta para todo mundo a versão do PHP' -Detalhe "Cabeçalho: X-Powered-By: $pw" -OQueFazer 'No php.ini, coloque expose_php = Off. O hacker usa isso para escolher o ataque.'))
    }
    if ($server -match '\d+\.\d+') {
        [void]$A.Add((New-EscudoAchado -Id 'site-server-versao' -Area 'Site' -Nivel 'Medio' -Titulo 'O servidor mostra a versão dele' -Detalhe "Server: $server" -OQueFazer "Esconda a versão (Apache: ServerTokens Prod; nginx: server_tokens off)$quem."))
    }

    if ((Get-EscudoValor $Coleta 'Https') -eq $true -and -not $h['strict-transport-security']) {
        [void]$A.Add((New-EscudoAchado -Id 'site-hsts' -Area 'Site' -Nivel 'Medio' -Titulo 'Falta o cabeçalho HSTS' -Detalhe 'Sem ele, dá para forçar o visitante a cair na versão sem cadeado em Wi-Fi público.' -OQueFazer "Adicione Strict-Transport-Security: max-age=31536000$quem."))
    }
    $csp = [string]$h['content-security-policy']
    if (-not $h['x-frame-options'] -and $csp -notmatch 'frame-ancestors') {
        [void]$A.Add((New-EscudoAchado -Id 'site-frame' -Area 'Site' -Nivel 'Medio' -Titulo 'Site pode ser embutido em página falsa (clickjacking)' -OQueFazer "Adicione X-Frame-Options: SAMEORIGIN$quem."))
    }
    if ([string]$h['x-content-type-options'] -notmatch '(?i)nosniff') {
        [void]$A.Add((New-EscudoAchado -Id 'site-nosniff' -Area 'Site' -Nivel 'Info' -Titulo 'Falta X-Content-Type-Options: nosniff' -OQueFazer "Adicione o cabeçalho$quem."))
    }
    if (-not $csp) {
        [void]$A.Add((New-EscudoAchado -Id 'site-csp' -Area 'Site' -Nivel 'Info' -Titulo 'Sem política de conteúdo (CSP)' -Detalhe 'A CSP limita de onde o site pode carregar scripts; ajuda contra roubo de dados por script injetado.' -OQueFazer "Comece com uma CSP em modo relatório$quem."))
    }
    foreach ($c in @(Get-EscudoValor $Coleta 'Cookies')) {
        if (-not $c) { continue }
        $nomeC = ($c -split '=')[0]
        $falta = @()
        if ($c -notmatch '(?i);\s*secure') { $falta += 'Secure' }
        if ($c -notmatch '(?i);\s*httponly' -and $nomeC -match '(?i)sess|token|auth|login|php') { $falta += 'HttpOnly' }
        if ($falta.Count -gt 0) {
            [void]$A.Add((New-EscudoAchado -Id "site-cookie-$nomeC" -Area 'Site' -Nivel 'Medio' -Titulo "Cookie '$nomeC' sem $($falta -join ' e ')" -OQueFazer 'No PHP: session.cookie_secure = 1 e session.cookie_httponly = 1. Em outros cookies, adicione os atributos ao criar.'))
        }
    }
    $html = [string](Get-EscudoValor $Coleta 'Html')
    $gen = [regex]::Match($html, '(?i)<meta[^>]+name=["'']generator["''][^>]+content=["'']([^"'']+)')
    if ($gen.Success -and $gen.Groups[1].Value -match '\d') {
        [void]$A.Add((New-EscudoAchado -Id 'site-generator' -Area 'Site' -Nivel 'Medio' -Titulo "O site mostra a versão do sistema: $($gen.Groups[1].Value)" -OQueFazer 'Esconda a meta "generator" e mantenha o sistema e os plugins sempre atualizados.'))
    }
    if ((Get-EscudoValor $Coleta 'Https') -eq $true -and $html -match '(?i)<(script|iframe)[^>]+src=["'']http://') {
        [void]$A.Add((New-EscudoAchado -Id 'site-misto' -Area 'Site' -Nivel 'Medio' -Titulo 'Página segura carregando script sem cadeado (http://)' -OQueFazer 'Troque os endereços http:// por https:// nos scripts.'))
    }
    if ($html -match '(?i)(eval\(function\(p,a,c,k,e|document\.write\(unescape\(|String\.fromCharCode\((\d+,\s*){20,}|<iframe[^>]+(width|height)=["'']?0["'']?)') {
        [void]$A.Add((New-EscudoAchado -Id 'site-injecao' -Area 'Invasão' -Nivel 'Alto' -Titulo 'A página tem código escondido típico de site invadido' -Detalhe 'Script ofuscado ou iframe invisível na página inicial.' -OQueFazer 'Rode o Escudo PHP no servidor e confira com quem fez o site se esse código é legítimo.'))
    }
    foreach ($e in @(Get-EscudoValor $Coleta 'Expostos')) {
        if (-not $e) { continue }
        [void]$A.Add((New-EscudoAchado -Id "site-exposto-$e" -Area 'Invasão' -Nivel 'Critico' -Titulo "Arquivo secreto aberto para qualquer um: $e" -Detalhe 'Pode conter senha do banco de dados, código-fonte ou configuração do servidor.' -OQueFazer 'Apague ou bloqueie esse arquivo HOJE e troque as senhas que estavam nele.'))
    }
    if ($plat) {
        [void]$A.Add((New-EscudoAchado -Id 'site-plataforma' -Area 'Site' -Nivel 'Info' -Titulo "Site hospedado em plataforma: $plat" -Detalhe 'Servidor, PHP e cabeçalhos são de responsabilidade da plataforma; o que é seu é senha forte com verificação em 2 etapas e apps/integrações que você instala.' -OQueFazer 'Ligue a verificação em 2 etapas no painel da loja.'))
    }
    return @($A | Sort-Object @{ Expression = { Get-EscudoOrdem $_.Nivel } }, Titulo)
}

function Invoke-EscudoHttp {
    param([string]$Url, [int]$Limite = 262144)
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.AllowAutoRedirect = $false
    $req.Timeout = 15000
    $req.UserAgent = 'EscudoInfinityGuard/1.0 (verificacao de seguranca autorizada pelo dono)'
    $resp = $null
    try { $resp = $req.GetResponse() } catch [System.Net.WebException] { $resp = $_.Exception.Response; if (-not $resp) { throw } }
    try {
        $cab = @{}
        foreach ($k in $resp.Headers.AllKeys) { $cab[$k.ToLower()] = $resp.Headers[$k] }
        $cookies = @()
        $vals = $resp.Headers.GetValues('Set-Cookie')
        if ($vals) { $cookies = @($vals) }
        $leitor = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $buf = New-Object char[] $Limite
        $n = $leitor.ReadBlock($buf, 0, $Limite)
        $corpo = New-Object string($buf, 0, $n)
        return [pscustomobject]@{ Status = [int]$resp.StatusCode; Cabecalhos = $cab; Cookies = $cookies; Corpo = $corpo; Local = $cab['location'] }
    } finally { $resp.Close() }
}

function Get-EscudoCertificado {
    param([string]$Servidor, [int]$Porta = 443)
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $tcp.Connect($Servidor, $Porta)
        $ssl = New-Object System.Net.Security.SslStream($tcp.GetStream(), $false)
        try {
            $ssl.AuthenticateAsClient($Servidor)
            $c = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
            return [pscustomobject]@{ Dias = [int]($c.NotAfter - (Get-Date)).TotalDays; Erro = $null; Emissor = $c.Issuer }
        } catch {
            $msg = $_.Exception.Message
            if ($_.Exception.InnerException) { $msg = $_.Exception.InnerException.Message + ' ' + $msg }
            return [pscustomobject]@{ Dias = $null; Erro = $msg; Emissor = $null }
        } finally { $ssl.Dispose() }
    } finally { $tcp.Close() }
}

$script:ArquivosSensiveis = @(
    @{ Caminho = '/.env'; Prova = '(?m)^\s*[A-Z_]{3,}\s*=' },
    @{ Caminho = '/.git/HEAD'; Prova = '^ref:\s*refs/' },
    @{ Caminho = '/.git/config'; Prova = '\[core\]' },
    @{ Caminho = '/phpinfo.php'; Prova = '(?i)phpinfo\(\)|PHP Version \d' },
    @{ Caminho = '/info.php'; Prova = '(?i)phpinfo\(\)|PHP Version \d' },
    @{ Caminho = '/wp-config.php.bak'; Prova = 'DB_PASSWORD' },
    @{ Caminho = '/wp-config.php~'; Prova = 'DB_PASSWORD' },
    @{ Caminho = '/config.php.bak'; Prova = '(?i)\$(db|database)?_?pass' },
    @{ Caminho = '/.htpasswd'; Prova = '^\S+:\$(apr1|2y|2a)\$' },
    @{ Caminho = '/backup.sql'; Prova = '(?i)(CREATE TABLE|INSERT INTO)' },
    @{ Caminho = '/dump.sql'; Prova = '(?i)(CREATE TABLE|INSERT INTO)' },
    @{ Caminho = '/composer.lock'; Prova = '"packages"\s*:' },
    @{ Caminho = '/server-status'; Prova = '(?i)Apache Server Status' },
    @{ Caminho = '/wp-content/debug.log'; Prova = '(?i)PHP (Fatal|Warning|Notice)' }
)

function Get-EscudoArquivosExpostos {
    <# Pede arquivos que nunca deveriam estar públicos. Só conta se o conteúdo provar que é o arquivo real. #>
    param([Parameter(Mandatory)][string]$Base)
    $achados = @()
    foreach ($s in $script:ArquivosSensiveis) {
        try {
            $x = Invoke-EscudoHttp ($Base.TrimEnd('/') + $s.Caminho) -Limite 8192
            if ($x.Status -ne 200) { continue }
            $paginaHtml = $x.Corpo -match '(?i)<html'
            $podeSerHtml = $s.Caminho -match 'phpinfo|info\.php|server-status'
            if ((-not $paginaHtml -or $podeSerHtml) -and $x.Corpo -match $s.Prova) { $achados += $s.Caminho }
        } catch { }
    }
    return $achados
}

function Test-EscudoSitePermitido {
    param([string]$Url, $Config, [switch]$EuSouDono)
    if ($EuSouDono) { return $true }
    $hostAlvo = ([uri]$Url).Host.ToLower()
    foreach ($s in @($Config.sites)) { if (([uri]$s).Host.ToLower() -eq $hostAlvo) { return $true } }
    return $false
}

function Invoke-EscudoSite {
    <# Checa um site de fora, como um visitante. Só sites da lista do config ou com -EuSouDono. #>
    param([string]$Url, [switch]$EuSouDono, [switch]$NaoAbrir)
    $cfg = Get-EscudoConfig
    $urls = if ($Url) { @($Url) } else { @($cfg.sites) }
    $resultados = @()
    foreach ($u in $urls) {
        if ($u -notmatch '^https?://') { $u = "https://$u" }
        if (-not (Test-EscudoSitePermitido -Url $u -Config $cfg -EuSouDono:$EuSouDono)) {
            Write-Host "Pulando $u : só verifico sites seus. Se este site é seu (ou você tem autorização por escrito do dono), rode de novo com -EuSouDono." -ForegroundColor Yellow
            continue
        }
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $hostAlvo = ([uri]$u).Host
        Write-Host "Verificando $hostAlvo ..."
        $col = [ordered]@{ Url = $u; Inalcancavel = $false; Https = $false; CertErro = $null; CertDias = $null; RedirecionaHttps = $null; Cabecalhos = @{}; Cookies = @(); Html = ''; Expostos = @(); Plataforma = $null }
        try {
            $r = Invoke-EscudoHttp "https://$hostAlvo/"
            $saltos = 0
            while ($r.Status -ge 300 -and $r.Status -lt 400 -and $r.Local -and $saltos -lt 5) {
                $prox = [uri]::new([uri]"https://$hostAlvo/", $r.Local).AbsoluteUri
                if (([uri]$prox).Scheme -ne 'https') { break }
                $r = Invoke-EscudoHttp $prox; $saltos++
            }
            $col.Https = $true
            $col.Cabecalhos = $r.Cabecalhos
            $col.Cookies = $r.Cookies
            $col.Html = $r.Corpo
        } catch { $col.CertErro = "Não abriu em HTTPS: $($_.Exception.Message)" }
        $httpOk = $false
        try {
            $rh = Invoke-EscudoHttp "http://$hostAlvo/"
            $httpOk = $true
            $col.RedirecionaHttps = ($rh.Status -ge 300 -and $rh.Status -lt 400 -and [string]$rh.Local -match '^https://')
        } catch { }
        if (-not $col.Https -and -not $httpOk) { $col.Inalcancavel = $true }
        if (-not $col.Inalcancavel) {
            try { $c = Get-EscudoCertificado $hostAlvo; $col.CertDias = $c.Dias; if ($c.Erro) { $col.CertErro = $c.Erro } } catch { }
        }
        $tudo = ($col.Html + ' ' + (($col.Cabecalhos.GetEnumerator() | ForEach-Object { "$($_.Key): $($_.Value)" }) -join ' '))
        if ($tudo -match '(?i)nuvemshop|tiendanube|d26lpennugtm8s\.cloudfront') { $col.Plataforma = 'Nuvemshop' }
        elseif ($tudo -match '(?i)github\.io|GitHub\.com') { $col.Plataforma = 'GitHub Pages (site estático, sem PHP)' }
        elseif ($tudo -match '(?i)cdn\.shopify|shopify') { $col.Plataforma = 'Shopify' }
        elseif ($tudo -match '(?i)wix\.com|wixstatic') { $col.Plataforma = 'Wix' }
        if ($col.Https) { $col.Expostos = @(Get-EscudoArquivosExpostos -Base "https://$hostAlvo") }
        elseif ($httpOk) { $col.Expostos = @(Get-EscudoArquivosExpostos -Base "http://$hostAlvo") }
        $coleta = [pscustomobject]$col
        $achados = @(Get-EscudoSiteAchados -Coleta $coleta -PhpMinimo $cfg.php_minimo_suportado -PhpFimProximo $cfg.php_fim_de_suporte_proximo)
        $nota = if ($coleta.Inalcancavel) { $null } else { Get-EscudoNota $achados }
        $resumo = @("Site: $u", $(if ($coleta.Plataforma) { "Plataforma: $($coleta.Plataforma)" } else { 'Plataforma: própria/hospedagem' }), 'Checagem de fora (como um visitante). Para olhar os arquivos do servidor, use o Escudo PHP.')
        $html = ConvertTo-EscudoHtml -Titulo "Escudo Infinity Guard: site $hostAlvo" -Subtitulo (Get-Date -Format 'dd/MM/yyyy HH:mm') -Nota $nota -Achados $achados -Resumo $resumo
        $arq = Save-EscudoRelatorio -Html $html -Prefixo ('site-' + ($hostAlvo -replace '[^a-zA-Z0-9.-]', '_'))
        Write-EscudoLog "Site $hostAlvo : nota $nota"
        Write-Host "  $(if ($null -eq $nota) { 'sem nota (site não abriu)' } else { "nota $nota/100" }) -> $arq"
        if (-not $NaoAbrir) { try { Start-Process $arq } catch { } }
        $resultados += [pscustomobject]@{ Site = $u; Nota = $nota; Achados = $achados; Relatorio = $arq; Coleta = $coleta }
    }
    return $resultados
}

Export-ModuleMember -Function *
