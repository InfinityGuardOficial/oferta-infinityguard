# Escudo Infinity Guard para Android (app)

**Segurança onde você estiver.** O app varre o próprio celular, mostra a nota de 0 a 100 e leva você direto a cada correção.

## O que ele varre

- App de **fora da Play Store** com **acessibilidade** ligada (é como os golpes do Pix leem a tela e mexem no celular sozinhos): crítico.
- App de fora da loja que virou **administrador do aparelho** (assim ele impede a própria desinstalação): crítico.
- App de fora da loja que **lê as notificações** (pega o código do SMS do banco).
- App de fora da loja que pede vários poderes de golpe ao mesmo tempo (SMS, ligações, desenhar por cima de outros apps, instalar apps).
- Celular **sem senha de tela**, **sem atualização de segurança** há mais de 3 meses, Android antigo, **Play Protect desligado**, **root** e Depuração USB ligada.

## Corrigir

O botão **Corrigir tudo** passa por cada problema, um de cada vez: abre a tela de desinstalar o app perigoso, a tela de acessibilidade, a de administradores, a do Play Protect, a de criar senha. Quando você volta, ele confere de novo e mostra **a nota antes e depois**.

O Android não deixa nenhum app desinstalar outro ou mudar ajustes de segurança sozinho: **cada correção precisa do seu toque**. Esse limite é do sistema, vale para qualquer antivírus. Para correção sem toque, use o Escudo do Windows pelo cabo USB (menu 7): pelo cabo ele tira os poderes dos apps perigosos sozinho.

## Vigia

A cada 15 minutos (e depois de ligar o celular) o app confere de novo e **avisa na notificação** se aparecer um problema grave novo.

## É golpe?

Na aba "É golpe?", cole a mensagem, ou no WhatsApp toque em **Compartilhar → Escudo**: ele aponta os sinais de golpe (Pix urgente, link encurtado, parente com número novo, falso funcionário do banco).

## Privacidade

O app **não tem permissão de internet**: nada sai do celular.

## Instalar

1. Baixe `escudo-android.apk` em https://oferta.infinityguard.com.br/escudo/ (confira o SHA-256 que está na página).
2. Toque no arquivo. O Android pede para permitir "instalar apps desconhecidos" para o navegador: permita só para essa instalação.
3. Depois de instalar, **volte em Ajustes e desligue de novo** essa permissão do navegador (no Escudo, aba "Mais proteção", tem o atalho direto para essa tela).

## Para quem desenvolve

- Montar: `bash montar-apk.sh CHAVE.jks SENHA [saida.apk]` (precisa de `aapt`, `dx`/`d8`, `zipalign`, `apksigner` e o `android.jar` da API 23 ou mais nova). A chave tem que ser sempre a mesma, senão o celular recusa a atualização.
- Testes da tela: `node testes/testar-tela.js` (Playwright).
- Testes no Android simulado (Robolectric 3.8, Android 8.1, JDK 8): `cd testes/robolectric && gradle test`. O `gen/R.java` vem do `aapt` com os recursos de `res/`.
