@echo off
rem Escudo Infinity Guard - abre o menu com permissao de administrador
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Escudo.ps1"
